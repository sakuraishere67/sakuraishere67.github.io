const PATTERNS = {
  grid: (c) => `background-image: linear-gradient(${c} 1.5px, transparent 1.5px), linear-gradient(90deg, ${c} 1.5px, transparent 1.5px) !important; background-size: 28px 28px !important; background-attachment: fixed !important;`,
  stripes: (c) => `background-image: repeating-linear-gradient(45deg, transparent, transparent 14px, ${c} 14px, ${c} 28px) !important; background-attachment: fixed !important;`,
  dots: (c) => `background-image: radial-gradient(${c} 2.5px, transparent 2.5px) !important; background-size: 24px 24px !important; background-attachment: fixed !important;`,
  polka: (c) => `background-image: radial-gradient(${c} 3px, transparent 3px), radial-gradient(${c} 3px, transparent 3px) !important; background-size: 32px 32px !important; background-position: 0 0, 16px 16px !important; background-attachment: fixed !important;`,
  checker: (c) => `background-image: linear-gradient(45deg, ${c} 25%, transparent 25%), linear-gradient(-45deg, ${c} 25%, transparent 25%), linear-gradient(45deg, transparent 75%, ${c} 75%), linear-gradient(-45deg, transparent 75%, ${c} 75%) !important; background-size: 32px 32px !important; background-position: 0 0, 0 16px, 16px -16px, -16px 0 !important; background-attachment: fixed !important;`,
  zigzag: (c) => `background-image: linear-gradient(135deg, ${c} 25%, transparent 25%), linear-gradient(225deg, ${c} 25%, transparent 25%), linear-gradient(45deg, ${c} 25%, transparent 25%), linear-gradient(315deg, ${c} 25%, transparent 25%) !important; background-position: 14px 0, 14px 0, 0 0, 0 0 !important; background-size: 28px 28px !important; background-attachment: fixed !important;`,
  scanlines: (c) => `background-image: repeating-linear-gradient(0deg, transparent, transparent 4px, ${c} 4px, ${c} 7px) !important; background-attachment: fixed !important;`,
  crosshatch: (c) => `background-image: repeating-linear-gradient(45deg, ${c} 0, ${c} 1.5px, transparent 0, transparent 50%), repeating-linear-gradient(-45deg, ${c} 0, ${c} 1.5px, transparent 0, transparent 50%) !important; background-size: 22px 22px !important; background-attachment: fixed !important;`,
  carbon: (c) => `background-image: radial-gradient(${c} 22%, transparent 23%), radial-gradient(${c} 22%, transparent 23%) !important; background-size: 16px 16px !important; background-position: 0 0, 8px 8px !important; background-attachment: fixed !important;`,
  waves: (c) => `background-image: radial-gradient(circle at 100% 50%, transparent 20%, ${c} 21%, ${c} 26%, transparent 27%), radial-gradient(circle at 0% 50%, transparent 20%, ${c} 21%, ${c} 26%, transparent 27%) !important; background-size: 36px 36px !important; background-attachment: fixed !important;`
};

const W_LIGHT = "rgba(255, 255, 255, 0.25)";
const D_LIGHT = "rgba(0, 0, 0, 0.24)";

const THEME_CONFIGS = {
  // 51 Animated Themes (Including Deep Space Cosmos & 9 Enhanced Sakura Varieties)
  deepspace:    { bg: "#02030a", panel: "rgba(12, 16, 42, 0.78)", button: "#0b102b", buttonHover: "#182254", border: "#a855f7", text: "#f3e8ff", mutedText: "#c4b5fd", pattern: "", animType: "deepspace" },
  starfield:    { bg: "#040712", panel: "rgba(13, 21, 48, 0.78)", button: "#080e24", buttonHover: "#13204d", border: "#60a5fa", text: "#f0f9ff", mutedText: "#93c5fd", pattern: "", animType: "starfield" },
  sakura:       { bg: "#1f0814", panel: "rgba(64, 18, 42, 0.78)", button: "#4a122f", buttonHover: "#701b47", border: "#f9a8d4", text: "#fce7f3", mutedText: "#fbcfe8", pattern: "", animType: "sakura" },
  sakuraglow:   { bg: "#240a20", panel: "rgba(74, 16, 55, 0.78)", button: "#52123d", buttonHover: "#7a1a5b", border: "#ff77a9", text: "#fff0f5", mutedText: "#ffb6c1", pattern: "", animType: "sakuraglow" },
  sakurastorm:  { bg: "#1c0410", panel: "rgba(61, 10, 36, 0.78)", button: "#450c27", buttonHover: "#6e153d", border: "#ff69b4", text: "#fff0f5", mutedText: "#db7093", pattern: "", animType: "sakurastorm" },
  sakuranight:  { bg: "#120822", panel: "rgba(36, 20, 64, 0.78)", button: "#2b144d", buttonHover: "#432078", border: "#ffb6c1", text: "#f3e8ff", mutedText: "#d8b4fe", pattern: "", animType: "sakuranight" },
  sakurafest:   { bg: "#26060c", panel: "rgba(77, 18, 30, 0.78)", button: "#571320", buttonHover: "#851d32", border: "#ff4500", text: "#fff5ee", mutedText: "#ff69b4", pattern: "", animType: "sakurafest" },
  sakuracircle: { bg: "#1b0a24", panel: "rgba(59, 21, 79, 0.78)", button: "#431559", buttonHover: "#662287", border: "#ba55d3", text: "#f8f0ff", mutedText: "#ffb6c1", pattern: "", animType: "sakuracircle" },
  sakurapond:   { bg: "#04191c", panel: "rgba(10, 51, 56, 0.78)", button: "#0c3b40", buttonHover: "#155c63", border: "#008080", text: "#e0ffff", mutedText: "#ffb6c1", pattern: "", animType: "sakurapond" },
  sakurarain:   { bg: "#0c1824", panel: "rgba(20, 48, 77, 0.78)", button: "#153554", buttonHover: "#225282", border: "#4682b4", text: "#f0f8ff", mutedText: "#ffb6c1", pattern: "", animType: "sakurarain" },
  sakuragold:   { bg: "#211504", panel: "rgba(71, 49, 10, 0.78)", button: "#4d3507", buttonHover: "#7a560b", border: "#ffd700", text: "#fffacd", mutedText: "#ff69b4", pattern: "", animType: "sakuragold" },

  matrix:     { bg: "#020a03", panel: "rgba(6, 28, 10, 0.78)", button: "#010502", buttonHover: "#041407", border: "#00ff41", text: "#00ff41", mutedText: "#00cc33", pattern: "", animType: "matrix" },
  synthwave:  { bg: "#130421", panel: "rgba(38, 10, 64, 0.76)", button: "#24073d", buttonHover: "#3b0c63", border: "#ff2a85", text: "#ff71ce", mutedText: "#05d9e8", pattern: "", animType: "synthwave" },
  cyberpunk:  { bg: "#031014", panel: "rgba(8, 33, 41, 0.78)", button: "#051920", buttonHover: "#0b3542", border: "#00f0ff", text: "#e0fbfc", mutedText: "#fcee0a", pattern: "", animType: "cyberpunk" },
  fireflies:  { bg: "#09140a", panel: "rgba(18, 43, 22, 0.76)", button: "#0e2614", buttonHover: "#183b20", border: "#facc15", text: "#fef08a", mutedText: "#bef264", pattern: "", animType: "fireflies" },
  particles:  { bg: "#050b1a", panel: "rgba(12, 24, 56, 0.78)", button: "#0b193d", buttonHover: "#152a61", border: "#38bdf8", text: "#e0f2fe", mutedText: "#93c5fd", pattern: "", animType: "particles" },
  portal:     { bg: "#160524", panel: "rgba(51, 13, 79, 0.78)", button: "#3b0a5e", buttonHover: "#541285", border: "#a855f7", text: "#f3e8ff", mutedText: "#d8b4fe", pattern: "", animType: "portal" },
  aurora:     { bg: "#041416", panel: "rgba(10, 46, 51, 0.76)", button: "#0a2f33", buttonHover: "#12494f", border: "#10b981", text: "#a7f3d0", mutedText: "#6ee7b7", pattern: "", animType: "aurora" },
  bubbles:    { bg: "#06152b", panel: "rgba(15, 43, 84, 0.78)", button: "#102d57", buttonHover: "#19437d", border: "#3b82f6", text: "#eff6ff", mutedText: "#bfdbfe", pattern: "", animType: "bubbles" },
  laser:      { bg: "#1a0606", panel: "rgba(59, 14, 14, 0.78)", button: "#471212", buttonHover: "#6e1d1d", border: "#ef4444", text: "#fee2e2", mutedText: "#fca5a5", pattern: "", animType: "laser" },
  snowfall:   { bg: "#0f172a", panel: "rgba(30, 41, 59, 0.78)", button: "#334155", buttonHover: "#475569", border: "#94a3b8", text: "#f8fafc", mutedText: "#cbd5e1", pattern: "", animType: "snowfall" },
  plasma:     { bg: "#1f0426", panel: "rgba(66, 12, 82, 0.78)", button: "#4d0d61", buttonHover: "#6b1487", border: "#d946ef", text: "#fdf4ff", mutedText: "#f0abfc", pattern: "", animType: "plasma" },
  comet:      { bg: "#1c0d06", panel: "rgba(61, 31, 15, 0.78)", button: "#4d230e", buttonHover: "#733618", border: "#fdba74", text: "#fff7ed", mutedText: "#fed7aa", pattern: "", animType: "comet" },
  matrix3d:   { bg: "#011205", panel: "rgba(4, 38, 12, 0.78)", button: "#04240a", buttonHover: "#0a4515", border: "#00ff41", text: "#00ff41", mutedText: "#00cc33", pattern: "", animType: "matrix3d" },
  nebula:     { bg: "#0f0524", panel: "rgba(45, 13, 79, 0.78)", button: "#310959", buttonHover: "#4d0d8a", border: "#ec4899", text: "#fbcfe8", mutedText: "#f472b6", pattern: "", animType: "nebula" },
  electric:   { bg: "#040d1a", panel: "rgba(12, 35, 74, 0.78)", button: "#102a5c", buttonHover: "#1b438f", border: "#38bdf8", text: "#e0f2fe", mutedText: "#fef08a", pattern: "", animType: "electric" },
  neonrings:  { bg: "#04141c", panel: "rgba(10, 43, 59, 0.78)", button: "#0c3245", buttonHover: "#14506e", border: "#06b6d4", text: "#cffafe", mutedText: "#38bdf8", pattern: "", animType: "neonrings" },
  fireworks:  { bg: "#14040d", panel: "rgba(54, 12, 38, 0.78)", button: "#3b0c29", buttonHover: "#5e1342", border: "#f43f5e", text: "#ffe4e6", mutedText: "#a855f7", pattern: "", animType: "fireworks" },
  goldmatrix: { bg: "#170f02", panel: "rgba(51, 34, 4, 0.78)", button: "#3d2703", buttonHover: "#5e3c05", border: "#eab308", text: "#fef08a", mutedText: "#d97706", pattern: "", animType: "goldmatrix" },
  sonar:      { bg: "#02120a", panel: "rgba(6, 43, 26, 0.78)", button: "#08301c", buttonHover: "#0e522f", border: "#10b981", text: "#a7f3d0", mutedText: "#34d399", pattern: "", animType: "sonar" },
  warp:       { bg: "#011a0c", panel: "rgba(4, 54, 25, 0.78)", button: "#063d1c", buttonHover: "#0a5c2b", border: "#22c55e", text: "#dcfce7", mutedText: "#86efac", pattern: "", animType: "warp" },
  solar:      { bg: "#1c0b02", panel: "rgba(61, 24, 4, 0.78)", button: "#471c03", buttonHover: "#6e2c05", border: "#ea580c", text: "#ffedd5", mutedText: "#fdba74", pattern: "", animType: "solar" },
  biolum:     { bg: "#021a17", panel: "rgba(4, 54, 49, 0.78)", button: "#063d37", buttonHover: "#0a5c53", border: "#14b8a6", text: "#ccfbf1", mutedText: "#5eead4", pattern: "", animType: "biolum" },
  quantum:    { bg: "#0c0421", panel: "rgba(31, 10, 71, 0.78)", button: "#22084f", buttonHover: "#380e7a", border: "#8b5cf6", text: "#f5f3ff", mutedText: "#c4b5fd", pattern: "", animType: "quantum" },
  hearts:     { bg: "#1f0510", panel: "rgba(66, 13, 35, 0.78)", button: "#4d0d27", buttonHover: "#75143b", border: "#fb7185", text: "#ffe4e6", mutedText: "#fda4af", pattern: "", animType: "hearts" },
  confetti:   { bg: "#0f172a", panel: "rgba(30, 41, 59, 0.78)", button: "#1e293b", buttonHover: "#334155", border: "#facc15", text: "#f8fafc", mutedText: "#fde047", pattern: "", animType: "confetti" },
  dna:        { bg: "#061121", panel: "rgba(15, 38, 71, 0.78)", button: "#10284d", buttonHover: "#193e75", border: "#06b6d4", text: "#e0f2fe", mutedText: "#c084fc", pattern: "", animType: "dna" },
  hexgrid:    { bg: "#050d1f", panel: "rgba(13, 31, 71, 0.78)", button: "#0d214d", buttonHover: "#16367d", border: "#3b82f6", text: "#dbeafe", mutedText: "#93c5fd", pattern: "", animType: "hexgrid" },
  ocean:      { bg: "#031524", panel: "rgba(8, 46, 77, 0.78)", button: "#083459", buttonHover: "#0e518a", border: "#38bdf8", text: "#e0f2fe", mutedText: "#7dd3fc", pattern: "", animType: "ocean" },
  equalizer:  { bg: "#04140e", panel: "rgba(10, 46, 33, 0.78)", button: "#0b3324", buttonHover: "#12523a", border: "#10b981", text: "#d1fae5", mutedText: "#fde047", pattern: "", animType: "equalizer" },
  meteors:    { bg: "#110424", panel: "rgba(38, 11, 77, 0.78)", button: "#280954", buttonHover: "#3f0f82", border: "#c084fc", text: "#f3e8ff", mutedText: "#e9d5ff", pattern: "", animType: "meteors" },
  leaves:     { bg: "#1c0e04", panel: "rgba(61, 32, 10, 0.78)", button: "#452208", buttonHover: "#6b360d", border: "#f59e0b", text: "#fef3c7", mutedText: "#fcd34d", pattern: "", animType: "leaves" },
  prism:      { bg: "#0d091f", panel: "rgba(31, 22, 71, 0.78)", button: "#221852", buttonHover: "#35267d", border: "#f472b6", text: "#fdf2f8", mutedText: "#c7d2fe", pattern: "", animType: "prism" },
  blackhole:  { bg: "#050507", panel: "rgba(20, 20, 26, 0.80)", button: "#121217", buttonHover: "#22222b", border: "#f97316", text: "#fff7ed", mutedText: "#fdba74", pattern: "", animType: "blackhole" },
  cybergrid:  { bg: "#020e14", panel: "rgba(6, 34, 48, 0.78)", button: "#072636", buttonHover: "#0d4059", border: "#00f0ff", text: "#cffafe", mutedText: "#67e8f9", pattern: "", animType: "cybergrid" },
  pixelrain:  { bg: "#031407", panel: "rgba(9, 43, 17, 0.78)", button: "#0a3013", buttonHover: "#114d1f", border: "#4ade80", text: "#dcfce7", mutedText: "#86efac", pattern: "", animType: "pixelrain" },
  starwarp:   { bg: "#030614", panel: "rgba(10, 19, 56, 0.78)", button: "#0a143d", buttonHover: "#13246b", border: "#93c5fd", text: "#ffffff", mutedText: "#bfdbfe", pattern: "", animType: "starwarp" },
  toxic:      { bg: "#0b1704", panel: "rgba(27, 54, 10, 0.78)", button: "#1c380a", buttonHover: "#2c5710", border: "#a3e635", text: "#ecfccb", mutedText: "#bef264", pattern: "", animType: "toxic" },
  bloodmoon:  { bg: "#1c0303", panel: "rgba(61, 8, 8, 0.78)", button: "#450808", buttonHover: "#6b0d0d", border: "#ef4444", text: "#fee2e2", mutedText: "#fca5a5", pattern: "", animType: "bloodmoon" },

  // 60 Patterned Color Themes
  blue:       { bg: "#2563eb", panel: "rgba(59, 130, 246, 0.84)", button: "#1d4ed8", buttonHover: "#1e40af", border: "#93c5fd", text: "#ffffff", mutedText: "#dbeafe", pattern: PATTERNS.grid(W_LIGHT) },
  red:        { bg: "#dc2626", panel: "rgba(239, 68, 68, 0.84)", button: "#b91c1c", buttonHover: "#991b1b", border: "#fca5a5", text: "#ffffff", mutedText: "#fee2e2", pattern: PATTERNS.stripes(W_LIGHT) },
  purple:     { bg: "#7c3aed", panel: "rgba(139, 92, 246, 0.84)", button: "#6d28d9", buttonHover: "#5b21b6", border: "#c4b5fd", text: "#ffffff", mutedText: "#ede9fe", pattern: PATTERNS.polka(W_LIGHT) },
  green:      { bg: "#16a34a", panel: "rgba(34, 197, 94, 0.84)", button: "#15803d", buttonHover: "#166534", border: "#86efac", text: "#ffffff", mutedText: "#dcfce7", pattern: PATTERNS.grid(W_LIGHT) },
  orange:     { bg: "#ea580c", panel: "rgba(249, 115, 22, 0.84)", button: "#c2410c", buttonHover: "#9a3412", border: "#fdba74", text: "#ffffff", mutedText: "#ffedd5", pattern: PATTERNS.zigzag(W_LIGHT) },
  pink:       { bg: "#db2777", panel: "rgba(236, 72, 153, 0.84)", button: "#be185d", buttonHover: "#9d174d", border: "#f9a8d4", text: "#ffffff", mutedText: "#fce7f3", pattern: PATTERNS.checker(W_LIGHT) },
  yellow:     { bg: "#eab308", panel: "rgba(250, 204, 21, 0.84)", button: "#ca8a04", buttonHover: "#a16207", border: "#fef08a", text: "#111827", mutedText: "#1f2937", pattern: PATTERNS.polka(D_LIGHT) },
  teal:       { bg: "#0d9488", panel: "rgba(20, 184, 166, 0.84)", button: "#0f766e", buttonHover: "#115e59", border: "#5eead4", text: "#ffffff", mutedText: "#ccfbf1", pattern: PATTERNS.waves(W_LIGHT) },
  cyan:       { bg: "#0891b2", panel: "rgba(6, 182, 212, 0.84)", button: "#0e7490", buttonHover: "#155e75", border: "#67e8f9", text: "#ffffff", mutedText: "#cffafe", pattern: PATTERNS.scanlines(W_LIGHT) },
  indigo:     { bg: "#4f46e5", panel: "rgba(99, 102, 241, 0.84)", button: "#4338ca", buttonHover: "#3730a3", border: "#a5b4fc", text: "#ffffff", mutedText: "#e0e7ff", pattern: PATTERNS.dots(W_LIGHT) },
  brown:      { bg: "#78350f", panel: "rgba(146, 64, 14, 0.84)", button: "#5c280b", buttonHover: "#451a03", border: "#d97706", text: "#ffffff", mutedText: "#fef3c7", pattern: PATTERNS.crosshatch(W_LIGHT) },
  gray:       { bg: "#4b5563", panel: "rgba(107, 114, 128, 0.84)", button: "#374151", buttonHover: "#1f2937", border: "#d1d5db", text: "#ffffff", mutedText: "#f3f4f6", pattern: PATTERNS.carbon(D_LIGHT) },
  black:      { bg: "#09090b", panel: "rgba(24, 24, 27, 0.84)", button: "#000000", buttonHover: "#121214", border: "#3f3f46", text: "#fafafa", mutedText: "#a1a1aa", pattern: PATTERNS.crosshatch("rgba(255,255,255,0.14)") },
  rose:       { bg: "#f43f5e", panel: "rgba(251, 113, 133, 0.84)", button: "#e11d48", buttonHover: "#be123c", border: "#fecdd3", text: "#ffffff", mutedText: "#fff1f2", pattern: PATTERNS.polka(W_LIGHT) },
  emerald:    { bg: "#059669", panel: "rgba(16, 185, 129, 0.84)", button: "#047857", buttonHover: "#065f46", border: "#6ee7b7", text: "#ffffff", mutedText: "#ecfdf5", pattern: PATTERNS.crosshatch(W_LIGHT) },
  amber:      { bg: "#d97706", panel: "rgba(245, 158, 11, 0.84)", button: "#b45309", buttonHover: "#92400e", border: "#fcd34d", text: "#ffffff", mutedText: "#fffbeb", pattern: PATTERNS.stripes(W_LIGHT) },
  violet:     { bg: "#8b5cf6", panel: "rgba(167, 139, 250, 0.84)", button: "#7c3aed", buttonHover: "#6d28d9", border: "#ddd6fe", text: "#ffffff", mutedText: "#f5f3ff", pattern: PATTERNS.grid(W_LIGHT) },
  lime:       { bg: "#65a30d", panel: "rgba(132, 204, 22, 0.84)", button: "#4d7c0f", buttonHover: "#3f6212", border: "#bef264", text: "#111827", mutedText: "#1f2937", pattern: PATTERNS.checker(D_LIGHT) },
  sky:        { bg: "#0284c7", panel: "rgba(14, 165, 233, 0.84)", button: "#0369a1", buttonHover: "#075985", border: "#7dd3fc", text: "#ffffff", mutedText: "#f0f9ff", pattern: PATTERNS.polka(W_LIGHT) },
  fuchsia:    { bg: "#c026d3", panel: "rgba(217, 70, 239, 0.84)", button: "#a21caf", buttonHover: "#86198f", border: "#f0abfc", text: "#ffffff", mutedText: "#fdf4ff", pattern: PATTERNS.grid(W_LIGHT) },
  slate:      { bg: "#475569", panel: "rgba(100, 116, 139, 0.84)", button: "#334155", buttonHover: "#1e293b", border: "#cbd5e1", text: "#ffffff", mutedText: "#f1f5f9", pattern: PATTERNS.carbon(D_LIGHT) },
  crimson:    { bg: "#991b1b", panel: "rgba(185, 28, 28, 0.84)", button: "#7f1d1d", buttonHover: "#450a0a", border: "#f87171", text: "#ffffff", mutedText: "#fee2e2", pattern: PATTERNS.stripes(D_LIGHT) },
  mint:       { bg: "#10b981", panel: "rgba(52, 211, 153, 0.84)", button: "#059669", buttonHover: "#047857", border: "#a7f3d0", text: "#064e3b", mutedText: "#065f46", pattern: PATTERNS.dots(D_LIGHT) },
  coral:      { bg: "#f97316", panel: "rgba(251, 146, 60, 0.84)", button: "#ea580c", buttonHover: "#c2410c", border: "#fed7aa", text: "#ffffff", mutedText: "#fff7ed", pattern: PATTERNS.stripes(W_LIGHT) },
  lavender:   { bg: "#9333ea", panel: "rgba(168, 85, 247, 0.84)", button: "#7e22ce", buttonHover: "#6b21a8", border: "#e9d5ff", text: "#ffffff", mutedText: "#faf5ff", pattern: PATTERNS.polka(W_LIGHT) },
  gold:       { bg: "#b45309", panel: "rgba(217, 119, 6, 0.84)", button: "#92400e", buttonHover: "#78350f", border: "#fde68a", text: "#ffffff", mutedText: "#fef3c7", pattern: PATTERNS.zigzag(W_LIGHT) },
  midnight:   { bg: "#1e1b4b", panel: "rgba(49, 46, 129, 0.84)", button: "#17143b", buttonHover: "#0f0d29", border: "#818cf8", text: "#e0e7ff", mutedText: "#c7d2fe", pattern: PATTERNS.grid(W_LIGHT) },
  turquoise:  { bg: "#0f766e", panel: "rgba(20, 184, 166, 0.84)", button: "#115e59", buttonHover: "#134e4a", border: "#99f6e4", text: "#ffffff", mutedText: "#f0fdfa", pattern: PATTERNS.waves(W_LIGHT) },
  magenta:    { bg: "#a21caf", panel: "rgba(192, 38, 211, 0.84)", button: "#86198f", buttonHover: "#701a75", border: "#f5d0fe", text: "#ffffff", mutedText: "#fdf4ff", pattern: PATTERNS.scanlines(W_LIGHT) },
  cherry:     { bg: "#ec4899", panel: "rgba(244, 114, 182, 0.84)", button: "#db2777", buttonHover: "#be185d", border: "#fbcfe8", text: "#ffffff", mutedText: "#fdf2f8", pattern: PATTERNS.polka(W_LIGHT) },
  sapphire:   { bg: "#1e40af", panel: "rgba(37, 99, 235, 0.84)", button: "#1e3a8a", buttonHover: "#172554", border: "#93c5fd", text: "#ffffff", mutedText: "#dbeafe", pattern: PATTERNS.grid(W_LIGHT) },
  ruby:       { bg: "#9f1239", panel: "rgba(225, 29, 72, 0.84)", button: "#881337", buttonHover: "#4c0519", border: "#fda4af", text: "#ffffff", mutedText: "#ffe4e6", pattern: PATTERNS.crosshatch(W_LIGHT) },
  jade:       { bg: "#065f46", panel: "rgba(16, 185, 129, 0.84)", button: "#064e3b", buttonHover: "#022c22", border: "#6ee7b7", text: "#ffffff", mutedText: "#d1fae5", pattern: PATTERNS.waves(W_LIGHT) },
  peach:      { bg: "#fb923c", panel: "rgba(253, 186, 116, 0.86)", button: "#f97316", buttonHover: "#ea580c", border: "#ffedd5", text: "#1f2937", mutedText: "#374151", pattern: PATTERNS.dots(D_LIGHT) },
  plum:       { bg: "#581c87", panel: "rgba(126, 34, 206, 0.84)", button: "#4c1d95", buttonHover: "#3b0764", border: "#d8b4fe", text: "#ffffff", mutedText: "#f3e8ff", pattern: PATTERNS.carbon(W_LIGHT) },
  charcoal:   { bg: "#18181b", panel: "rgba(39, 39, 42, 0.86)", button: "#09090b", buttonHover: "#27272a", border: "#71717a", text: "#f4f4f5", mutedText: "#d4d4d8", pattern: PATTERNS.carbon("rgba(255,255,255,0.12)") },
  bronze:     { bg: "#713f12", panel: "rgba(161, 98, 7, 0.84)", button: "#5c330e", buttonHover: "#422006", border: "#fde047", text: "#ffffff", mutedText: "#fef9c3", pattern: PATTERNS.stripes(W_LIGHT) },
  arctic:     { bg: "#0369a1", panel: "rgba(14, 165, 233, 0.84)", button: "#075985", buttonHover: "#0c4a6e", border: "#bae6fd", text: "#ffffff", mutedText: "#e0f2fe", pattern: PATTERNS.grid(W_LIGHT) },
  orchid:     { bg: "#a21caf", panel: "rgba(217, 70, 239, 0.84)", button: "#86198f", buttonHover: "#701a75", border: "#f5d0fe", text: "#ffffff", mutedText: "#fdf4ff", pattern: PATTERNS.polka(W_LIGHT) },
  mustard:    { bg: "#a16207", panel: "rgba(202, 138, 4, 0.84)", button: "#854d0e", buttonHover: "#713f12", border: "#fef08a", text: "#ffffff", mutedText: "#fef9c3", pattern: PATTERNS.checker(D_LIGHT) },
  olive:      { bg: "#3f6212", panel: "rgba(101, 163, 13, 0.84)", button: "#365314", buttonHover: "#1a2e05", border: "#bef264", text: "#ffffff", mutedText: "#ecfccb", pattern: PATTERNS.crosshatch(W_LIGHT) },
  maroon:     { bg: "#7f1d1d", panel: "rgba(153, 27, 27, 0.84)", button: "#631717", buttonHover: "#450a0a", border: "#fca5a5", text: "#ffffff", mutedText: "#fee2e2", pattern: PATTERNS.stripes(W_LIGHT) },
  aqua:       { bg: "#0891b2", panel: "rgba(34, 211, 238, 0.84)", button: "#0e7490", buttonHover: "#155e75", border: "#cffafe", text: "#083344", mutedText: "#164e63", pattern: PATTERNS.waves(D_LIGHT) },
  periwinkle: { bg: "#4338ca", panel: "rgba(99, 102, 241, 0.84)", button: "#3730a3", buttonHover: "#312e81", border: "#c7d2fe", text: "#ffffff", mutedText: "#e0e7ff", pattern: PATTERNS.dots(W_LIGHT) },
  copper:     { bg: "#9a3412", panel: "rgba(234, 88, 12, 0.84)", button: "#7c2d12", buttonHover: "#431407", border: "#fed7aa", text: "#ffffff", mutedText: "#ffedd5", pattern: PATTERNS.grid(W_LIGHT) },
  steel:      { bg: "#334155", panel: "rgba(71, 85, 105, 0.84)", button: "#1e293b", buttonHover: "#0f172a", border: "#cbd5e1", text: "#f8fafc", mutedText: "#e2e8f0", pattern: PATTERNS.grid(W_LIGHT) },
  bubblegum:  { bg: "#db2777", panel: "rgba(244, 114, 182, 0.84)", button: "#be185d", buttonHover: "#9d174d", border: "#fbcfe8", text: "#ffffff", mutedText: "#fdf2f8", pattern: PATTERNS.polka(W_LIGHT) },
  lemon:      { bg: "#ca8a04", panel: "rgba(250, 204, 21, 0.86)", button: "#a16207", buttonHover: "#854d0e", border: "#fef9c3", text: "#111827", mutedText: "#1f2937", pattern: PATTERNS.stripes(D_LIGHT) },
  seafoam:    { bg: "#0f766e", panel: "rgba(45, 212, 191, 0.84)", button: "#115e59", buttonHover: "#134e4a", border: "#ccfbf1", text: "#ffffff", mutedText: "#f0fdfa", pattern: PATTERNS.waves(W_LIGHT) },
  grape:      { bg: "#6b21a8", panel: "rgba(147, 51, 234, 0.84)", button: "#581c87", buttonHover: "#3b0764", border: "#e9d5ff", text: "#ffffff", mutedText: "#faf5ff", pattern: PATTERNS.dots(W_LIGHT) },
  rust:       { bg: "#7c2d12", panel: "rgba(194, 65, 12, 0.84)", button: "#63240e", buttonHover: "#431407", border: "#fdba74", text: "#ffffff", mutedText: "#ffedd5", pattern: PATTERNS.zigzag(W_LIGHT) },
  ash:        { bg: "#27272a", panel: "rgba(63, 63, 70, 0.84)", button: "#18181b", buttonHover: "#09090b", border: "#a1a1aa", text: "#fafafa", mutedText: "#e4e4e7", pattern: PATTERNS.crosshatch(W_LIGHT) },
  watermelon: { bg: "#e11d48", panel: "rgba(244, 63, 94, 0.84)", button: "#be123c", buttonHover: "#881337", border: "#86efac", text: "#ffffff", mutedText: "#dcfce7", pattern: PATTERNS.checker(W_LIGHT) },
  cobalt:     { bg: "#1d4ed8", panel: "rgba(59, 130, 246, 0.84)", button: "#1e40af", buttonHover: "#1e3a8a", border: "#7dd3fc", text: "#ffffff", mutedText: "#e0f2fe", pattern: PATTERNS.scanlines(W_LIGHT) },
  moss:       { bg: "#14532d", panel: "rgba(22, 163, 74, 0.84)", button: "#14532d", buttonHover: "#052e16", border: "#86efac", text: "#ffffff", mutedText: "#dcfce7", pattern: PATTERNS.dots(W_LIGHT) },
  apricot:    { bg: "#ea580c", panel: "rgba(251, 146, 60, 0.86)", button: "#c2410c", buttonHover: "#9a3412", border: "#ffedd5", text: "#ffffff", mutedText: "#fff7ed", pattern: PATTERNS.stripes(W_LIGHT) },
  lilac:      { bg: "#7e22ce", panel: "rgba(192, 132, 252, 0.84)", button: "#6b21a8", buttonHover: "#581c87", border: "#f3e8ff", text: "#ffffff", mutedText: "#faf5ff", pattern: PATTERNS.grid(W_LIGHT) },
  onyx:       { bg: "#000000", panel: "rgba(18, 18, 22, 0.88)", button: "#09090b", buttonHover: "#18181b", border: "#52525b", text: "#ffffff", mutedText: "#a1a1aa", pattern: PATTERNS.scanlines("rgba(255,255,255,0.1)") },
  cerulean:   { bg: "#0284c7", panel: "rgba(56, 189, 248, 0.84)", button: "#0369a1", buttonHover: "#075985", border: "#e0f2fe", text: "#ffffff", mutedText: "#f0f9ff", pattern: PATTERNS.waves(W_LIGHT) },
  scarlet:    { bg: "#b91c1c", panel: "rgba(239, 68, 68, 0.84)", button: "#991b1b", buttonHover: "#7f1d1d", border: "#fecaca", text: "#ffffff", mutedText: "#fef2f2", pattern: PATTERNS.zigzag(W_LIGHT) }
};

// Centralized Animation Lifecycle Manager (Zero listener leaks!)
let animFrameId = null;
let animIntervalId = null;
let activeResizeHandler = null;
let activeClickHandler = null;
let mouseX = -999;
let mouseY = -999;
let prevMouseX = -999;
let prevMouseY = -999;
let mouseVx = 0;
let mouseVy = 0;

window.addEventListener("mousemove", (e) => {
  if (prevMouseX !== -999) {
    mouseVx = Math.max(-25, Math.min(25, e.clientX - prevMouseX));
    mouseVy = Math.max(-25, Math.min(25, e.clientY - prevMouseY));
  }
  prevMouseX = e.clientX;
  prevMouseY = e.clientY;
  mouseX = e.clientX;
  mouseY = e.clientY;
}, { passive: true });

function stopCanvasAnimation() {
  if (animFrameId !== null) {
    cancelAnimationFrame(animFrameId);
    animFrameId = null;
  }
  if (animIntervalId !== null) {
    clearInterval(animIntervalId);
    animIntervalId = null;
  }
  if (activeResizeHandler !== null) {
    window.removeEventListener("resize", activeResizeHandler);
    activeResizeHandler = null;
  }
  if (activeClickHandler !== null) {
    window.removeEventListener("click", activeClickHandler);
    activeClickHandler = null;
  }
  const existingCanvas = document.getElementById("mikeybox-anim-canvas");
  if (existingCanvas) existingCanvas.remove();
}

function createOverlayCanvas(opacity = "0.55") {
  stopCanvasAnimation();
  const canvas = document.createElement("canvas");
  canvas.id = "mikeybox-anim-canvas";
  Object.assign(canvas.style, {
    position: "fixed",
    top: "0",
    left: "0",
    width: "100vw",
    height: "100vh",
    pointerEvents: "none",
    zIndex: "999999",
    opacity: opacity
  });
  document.documentElement.appendChild(canvas);

  const resize = () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  };
  resize();
  activeResizeHandler = resize;
  window.addEventListener("resize", activeResizeHandler, { passive: true });

  return canvas;
}

function registerClick(fn) {
  if (activeClickHandler) {
    window.removeEventListener("click", activeClickHandler);
  }
  activeClickHandler = fn;
  window.addEventListener("click", activeClickHandler, { passive: true });
}

// ==========================================
// HIGH-PERFORMANCE OFFSCREEN SPRITE CACHES (ZERO-LAG GPU BLITTING)
// ==========================================
const spriteCache = new Map();

function getSnowflakeSprite(radius, variant = 0) {
  const bucket = Math.round(radius * 2) / 2;
  const key = `snow_${bucket}_${variant}`;
  if (spriteCache.has(key)) return spriteCache.get(key);

  const pad = Math.ceil(bucket * 2.4);
  const off = document.createElement("canvas");
  off.width = pad * 2;
  off.height = pad * 2;
  const c = off.getContext("2d");
  c.translate(pad, pad);

  // Soft ice halo (baked once into offscreen sprite—zero per-frame shadowBlur cost!)
  const halo = c.createRadialGradient(0, 0, bucket * 0.1, 0, 0, bucket * 1.45);
  halo.addColorStop(0, "rgba(255, 255, 255, 0.55)");
  halo.addColorStop(0.55, "rgba(186, 230, 253, 0.18)");
  halo.addColorStop(1, "rgba(186, 230, 253, 0)");
  c.fillStyle = halo;
  c.beginPath();
  c.arc(0, 0, bucket * 1.45, 0, Math.PI * 2);
  c.fill();

  c.strokeStyle = "#ffffff";
  c.lineCap = "round";
  c.lineWidth = Math.max(1.1, bucket * 0.13);

  for (let i = 0; i < 6; i++) {
    c.rotate(Math.PI / 3);
    c.beginPath();
    c.moveTo(0, 0);
    c.lineTo(0, -bucket);
    c.stroke();

    // Outer V-branches
    const b1 = bucket * 0.62;
    const b1Len = bucket * 0.34;
    c.beginPath();
    c.moveTo(0, -b1);
    c.lineTo(-b1Len * 0.72, -b1 - b1Len * 0.72);
    c.moveTo(0, -b1);
    c.lineTo(b1Len * 0.72, -b1 - b1Len * 0.72);
    c.stroke();

    // Inner V-branches or crystalline ring
    if (bucket >= 5.5) {
      const b2 = bucket * 0.34;
      const b2Len = bucket * 0.22;
      c.beginPath();
      c.moveTo(0, -b2);
      c.lineTo(-b2Len * 0.72, -b2 - b2Len * 0.72);
      c.moveTo(0, -b2);
      c.lineTo(b2Len * 0.72, -b2 - b2Len * 0.72);
      c.stroke();
    }
    if (variant === 1 && bucket >= 7) {
      c.beginPath();
      c.moveTo(0, -bucket * 0.48);
      c.lineTo(Math.sin(Math.PI / 3) * bucket * 0.48, -Math.cos(Math.PI / 3) * bucket * 0.48);
      c.stroke();
    }
  }

  // Hexagonal ice core
  c.fillStyle = "#e0f2fe";
  c.beginPath();
  c.arc(0, 0, Math.max(1.2, bucket * 0.16), 0, Math.PI * 2);
  c.fill();

  spriteCache.set(key, off);
  return off;
}

function getSakuraPetalSprite(primary, secondary, veinColor, glowColor = null) {
  const key = `petal_${primary}_${secondary}_${glowColor || "none"}`;
  if (spriteCache.has(key)) return spriteCache.get(key);

  const size = 24;
  const pad = glowColor ? 44 : 30;
  const off = document.createElement("canvas");
  off.width = pad * 2;
  off.height = pad * 2;
  const c = off.getContext("2d");
  c.translate(pad, pad);

  if (glowColor) {
    c.shadowBlur = 14;
    c.shadowColor = glowColor;
  }

  const grad = c.createRadialGradient(-size * 0.35, 0, size * 0.08, 0, 0, size * 1.15);
  grad.addColorStop(0, primary);
  grad.addColorStop(0.65, secondary);
  grad.addColorStop(1, primary);
  c.fillStyle = grad;

  // Botanical notched cherry blossom petal silhouette
  c.beginPath();
  c.moveTo(-size, 0);
  c.bezierCurveTo(-size * 0.55, -size * 0.82, size * 0.45, -size * 0.88, size, -size * 0.25);
  c.lineTo(size * 0.72, 0);
  c.lineTo(size, size * 0.25);
  c.bezierCurveTo(size * 0.45, size * 0.88, -size * 0.55, size * 0.82, -size, 0);
  c.closePath();
  c.fill();

  c.shadowBlur = 0;

  // Delicate center vein & side creases
  c.strokeStyle = veinColor;
  c.lineWidth = 1.2;
  c.beginPath();
  c.moveTo(-size * 0.78, 0);
  c.lineTo(size * 0.56, 0);
  c.moveTo(-size * 0.25, 0);
  c.quadraticCurveTo(size * 0.15, -size * 0.28, size * 0.5, -size * 0.36);
  c.moveTo(-size * 0.25, 0);
  c.quadraticCurveTo(size * 0.15, size * 0.28, size * 0.5, size * 0.36);
  c.stroke();

  // Base stem blush dot
  c.fillStyle = "rgba(190, 24, 93, 0.35)";
  c.beginPath();
  c.arc(-size * 0.82, 0, 2.2, 0, Math.PI * 2);
  c.fill();

  spriteCache.set(key, off);
  return off;
}

function getSakuraBlossomSprite(primary, secondary) {
  const key = `blossom_${primary}_${secondary}`;
  if (spriteCache.has(key)) return spriteCache.get(key);

  const pad = 42;
  const off = document.createElement("canvas");
  off.width = pad * 2;
  off.height = pad * 2;
  const c = off.getContext("2d");
  c.translate(pad, pad);

  const petalSprite = getSakuraPetalSprite(primary, secondary, "rgba(255,255,255,0.3)", secondary);
  for (let i = 0; i < 5; i++) {
    c.save();
    c.rotate((Math.PI * 2 * i) / 5);
    c.drawImage(petalSprite, 10 - petalSprite.width / 2, -petalSprite.height / 2, petalSprite.width * 0.55, petalSprite.height * 0.55);
    c.restore();
  }

  // Golden stamen filaments & anthers in center
  c.strokeStyle = "rgba(254, 240, 138, 0.85)";
  c.lineWidth = 1;
  for (let s = 0; s < 10; s++) {
    const a = (Math.PI * 2 * s) / 10;
    const len = 7 + (s % 2) * 3;
    c.beginPath();
    c.moveTo(0, 0);
    c.lineTo(Math.cos(a) * len, Math.sin(a) * len);
    c.stroke();
    c.fillStyle = "#fde047";
    c.beginPath();
    c.arc(Math.cos(a) * len, Math.sin(a) * len, 1.4, 0, Math.PI * 2);
    c.fill();
  }
  c.fillStyle = "#be185d";
  c.beginPath();
  c.arc(0, 0, 3, 0, Math.PI * 2);
  c.fill();

  spriteCache.set(key, off);
  return off;
}

function drawBlittedPetal(ctx, sprite, x, y, size, rot, flip, alpha = 0.95) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(x, y);
  ctx.rotate(rot);
  const scaleX = size / 24;
  const scaleY = scaleX * (0.42 + 0.58 * Math.abs(Math.cos(flip)));
  ctx.scale(scaleX, scaleY);
  ctx.drawImage(sprite, -sprite.width / 2, -sprite.height / 2);
  ctx.restore();
}

function drawSakuraBranch(ctx, startX, startY, angle, length, depth, blossomSprite, time) {
  const sway = Math.sin(time * 0.0012 + depth) * 0.025 * (5 - depth);
  const a = angle + sway;
  const endX = startX + Math.cos(a) * length;
  const endY = startY + Math.sin(a) * length;

  ctx.strokeStyle = depth > 2 ? "#3b1d2a" : "#58283d";
  ctx.lineWidth = Math.max(1.4, depth * 2.1);
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(startX, startY);
  ctx.quadraticCurveTo(
    (startX + endX) * 0.5 + Math.sin(a) * 6,
    (startY + endY) * 0.5 - Math.cos(a) * 6,
    endX,
    endY
  );
  ctx.stroke();

  if (depth <= 2) {
    ctx.drawImage(blossomSprite, endX - blossomSprite.width * 0.35, endY - blossomSprite.height * 0.35, blossomSprite.width * 0.7, blossomSprite.height * 0.7);
  }
  if (depth > 1) {
    drawSakuraBranch(ctx, endX, endY, a - 0.38, length * 0.74, depth - 1, blossomSprite, time);
    drawSakuraBranch(ctx, endX, endY, a + 0.34, length * 0.72, depth - 1, blossomSprite, time);
  }
}

function applyCursorWind(p, radius = 145, strength = 1.5) {
  if (mouseX === -999 || mouseY === -999) return;
  const dx = p.x - mouseX;
  const dy = p.y - mouseY;
  const distSq = dx * dx + dy * dy;
  if (distSq > 1 && distSq < radius * radius) {
    const dist = Math.sqrt(distSq);
    const force = (1 - dist / radius) * strength;
    p.vx += (dx / dist) * force + (-dy / dist) * (force * 0.35) + mouseVx * 0.03 * force;
    p.vy += (dy / dist) * force + mouseVy * 0.03 * force;
  }
}

function drawStarShape(ctx, cx, cy, spikes, outerR, innerR, rotation) {
  let rot = (Math.PI / 2) * 3 + rotation;
  const step = Math.PI / spikes;
  ctx.beginPath();
  ctx.moveTo(cx + Math.cos(rot) * outerR, cy + Math.sin(rot) * outerR);
  for (let i = 0; i < spikes; i++) {
    ctx.lineTo(cx + Math.cos(rot) * outerR, cy + Math.sin(rot) * outerR);
    rot += step;
    ctx.lineTo(cx + Math.cos(rot) * innerR, cy + Math.sin(rot) * innerR);
    rot += step;
  }
  ctx.closePath();
  ctx.fill();
}

// ==========================================
// 0. NEW DETAILED SPACE THEME: DEEP SPACE COSMOS
// ==========================================
function startDeepSpace() {
  const canvas = createOverlayCanvas("0.78");
  const ctx = canvas.getContext("2d");

  const starColors = ["#ffffff", "#bae6fd", "#fef08a", "#f5d0fe", "#93c5fd"];
  const stars = Array.from({ length: 160 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    z: 0.2 + Math.random() * 0.8,
    r: 0.7 + Math.random() * 1.9,
    twinkle: Math.random() * Math.PI * 2,
    color: starColors[Math.floor(Math.random() * starColors.length)]
  }));

  // Spiral galaxy arm particles
  const galaxyArms = Array.from({ length: 140 }, (_, idx) => {
    const arm = idx % 3;
    const dist = 12 + Math.random() * 155;
    return {
      arm,
      dist,
      angleOffset: (arm * Math.PI * 2) / 3 + dist * 0.028 + (Math.random() - 0.5) * 0.45,
      size: 1.1 + Math.random() * 2.1,
      color: dist < 45 ? "#fef08a" : dist < 95 ? "#d8b4fe" : "#7dd3fc"
    };
  });

  // Orbiting asteroids & comets
  const shootingStars = [];
  let galaxyAngle = 0;
  let planetAngle = 0;

  registerClick((e) => {
    // Supernova burst at cursor click!
    for (let i = 0; i < 24; i++) {
      const a = (Math.PI * 2 * i) / 24 + Math.random() * 0.2;
      const spd = 2.5 + Math.random() * 5.5;
      shootingStars.push({
        x: e.clientX,
        y: e.clientY,
        vx: Math.cos(a) * spd,
        vy: Math.sin(a) * spd,
        life: 1,
        color: i % 2 === 0 ? "#c084fc" : "#38bdf8"
      });
    }
  });

  function draw(now) {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const parallaxX = mouseX !== -999 ? (mouseX - w / 2) * 0.04 : 0;
    const parallaxY = mouseY !== -999 ? (mouseY - h / 2) * 0.04 : 0;

    // 1. Multi-layered cosmic nebula clouds
    const neb1 = ctx.createRadialGradient(w * 0.28 + parallaxX * 0.4, h * 0.35 + parallaxY * 0.4, 20, w * 0.28 + parallaxX * 0.4, h * 0.35 + parallaxY * 0.4, Math.max(w, h) * 0.42);
    neb1.addColorStop(0, "rgba(147, 51, 234, 0.22)");
    neb1.addColorStop(0.5, "rgba(59, 130, 246, 0.1)");
    neb1.addColorStop(1, "rgba(2, 3, 10, 0)");
    ctx.fillStyle = neb1;
    ctx.fillRect(0, 0, w, h);

    const neb2 = ctx.createRadialGradient(w * 0.76 - parallaxX * 0.3, h * 0.68 - parallaxY * 0.3, 15, w * 0.76 - parallaxX * 0.3, h * 0.68 - parallaxY * 0.3, Math.max(w, h) * 0.36);
    neb2.addColorStop(0, "rgba(236, 72, 153, 0.18)");
    neb2.addColorStop(0.55, "rgba(14, 165, 233, 0.08)");
    neb2.addColorStop(1, "rgba(2, 3, 10, 0)");
    ctx.fillStyle = neb2;
    ctx.fillRect(0, 0, w, h);

    // 2. Parallax Starfield
    for (let i = 0; i < stars.length; i++) {
      const s = stars[i];
      s.twinkle += 0.03 + s.z * 0.03;
      const sx = (s.x + parallaxX * s.z + w) % w;
      const sy = (s.y + parallaxY * s.z + h) % h;
      const alpha = 0.35 + 0.65 * ((Math.sin(s.twinkle) + 1) * 0.5);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = s.color;
      ctx.beginPath();
      ctx.arc(sx, sy, s.r * s.z, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // 3. Rotating Spiral Galaxy (top-left/center-left)
    const gx = w * 0.24 + parallaxX * 0.7;
    const gy = h * 0.3 + parallaxY * 0.7;
    galaxyAngle += 0.004;
    const gCore = ctx.createRadialGradient(gx, gy, 2, gx, gy, 42);
    gCore.addColorStop(0, "rgba(255, 251, 235, 0.9)");
    gCore.addColorStop(0.4, "rgba(216, 180, 254, 0.45)");
    gCore.addColorStop(1, "rgba(147, 51, 234, 0)");
    ctx.fillStyle = gCore;
    ctx.beginPath();
    ctx.arc(gx, gy, 42, 0, Math.PI * 2);
    ctx.fill();

    for (let i = 0; i < galaxyArms.length; i++) {
      const gp = galaxyArms[i];
      const a = galaxyAngle + gp.angleOffset;
      const px = gx + Math.cos(a) * gp.dist;
      const py = gy + Math.sin(a) * (gp.dist * 0.52);
      ctx.fillStyle = gp.color;
      ctx.globalAlpha = Math.max(0.15, 1 - gp.dist / 170);
      ctx.beginPath();
      ctx.arc(px, py, gp.size, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // 4. Ringed Gas Giant Planet + Orbiting Moon (bottom-right)
    const px = w * 0.78 + parallaxX * 1.1;
    const py = h * 0.72 + parallaxY * 1.1;
    const pRad = Math.min(w, h) * 0.068;

    // Back half of planetary rings
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(-0.34);
    ctx.strokeStyle = "rgba(196, 181, 253, 0.42)";
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.ellipse(0, 0, pRad * 2.15, pRad * 0.52, 0, Math.PI, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = "rgba(56, 189, 248, 0.35)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(0, 0, pRad * 2.45, pRad * 0.62, 0, Math.PI, Math.PI * 2);
    ctx.stroke();
    ctx.restore();

    // Planet sphere with atmospheric shading
    const pGrad = ctx.createRadialGradient(px - pRad * 0.35, py - pRad * 0.35, pRad * 0.1, px, py, pRad);
    pGrad.addColorStop(0, "#e9d5ff");
    pGrad.addColorStop(0.45, "#7e22ce");
    pGrad.addColorStop(0.85, "#1e1b4b");
    pGrad.addColorStop(1, "#090d16");
    ctx.fillStyle = pGrad;
    ctx.beginPath();
    ctx.arc(px, py, pRad, 0, Math.PI * 2);
    ctx.fill();

    // Front half of planetary rings
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(-0.34);
    ctx.strokeStyle = "rgba(216, 180, 254, 0.68)";
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.ellipse(0, 0, pRad * 2.15, pRad * 0.52, 0, 0, Math.PI);
    ctx.stroke();
    ctx.strokeStyle = "rgba(125, 211, 252, 0.5)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(0, 0, pRad * 2.45, pRad * 0.62, 0, 0, Math.PI);
    ctx.stroke();
    ctx.restore();

    // Orbiting moon
    planetAngle += 0.015;
    const moonX = px + Math.cos(planetAngle) * (pRad * 2.8);
    const moonY = py + Math.sin(planetAngle) * (pRad * 0.95);
    ctx.fillStyle = "#e2e8f0";
    ctx.beginPath();
    ctx.arc(moonX, moonY, Math.max(4, pRad * 0.16), 0, Math.PI * 2);
    ctx.fill();

    // 5. Occasional Shooting Stars & Click Supernova Sparks
    if (Math.random() < 0.025) {
      shootingStars.push({
        x: Math.random() * w,
        y: Math.random() * h * 0.4,
        vx: -7 - Math.random() * 5,
        vy: 3.5 + Math.random() * 3,
        life: 1,
        color: "#bae6fd"
      });
    }
    for (let i = shootingStars.length - 1; i >= 0; i--) {
      const st = shootingStars[i];
      st.x += st.vx;
      st.y += st.vy;
      st.life -= 0.022;
      if (st.life <= 0) { shootingStars.splice(i, 1); continue; }
      ctx.strokeStyle = st.color;
      ctx.globalAlpha = st.life;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(st.x, st.y);
      ctx.lineTo(st.x - st.vx * 4, st.y - st.vy * 4);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    animFrameId = requestAnimationFrame(draw);
  }
  draw(0);
}

// ==========================================
// 1. Falling Stars (Enhanced with Constellations & Comet Trails)
// ==========================================
function startStarfield() {
  const canvas = createOverlayCanvas("0.65");
  const ctx = canvas.getContext("2d");
  const starColors = ["#ffffff", "#fde047", "#93c5fd", "#bae6fd", "#fef08a"];
  const stars = Array.from({ length: 95 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    outerR: 3.5 + Math.random() * 5.5,
    speedY: 1.4 + Math.random() * 2.8,
    speedX: -0.5 - Math.random() * 1.0,
    rot: Math.random() * Math.PI * 2,
    rotSpeed: (Math.random() - 0.5) * 0.05,
    twinkle: Math.random() * Math.PI * 2,
    color: starColors[Math.floor(Math.random() * starColors.length)]
  }));

  registerClick((e) => {
    for (let i = 0; i < 12; i++) {
      stars.push({
        x: e.clientX + (Math.random() - 0.5) * 30,
        y: e.clientY + (Math.random() - 0.5) * 30,
        outerR: 5 + Math.random() * 5,
        speedY: 2 + Math.random() * 3,
        speedX: (Math.random() - 0.5) * 4,
        rot: Math.random() * Math.PI,
        rotSpeed: 0.08,
        twinkle: 0,
        color: "#fde047"
      });
    }
    if (stars.length > 150) stars.splice(0, stars.length - 150);
  });

  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < stars.length; i++) {
      const s = stars[i];
      if (mouseX !== -999) {
        const dx = mouseX - s.x, dy = mouseY - s.y;
        const dSq = dx * dx + dy * dy;
        if (dSq < 32400) {
          s.x += dx * 0.025; s.y += dy * 0.025;
          ctx.strokeStyle = "rgba(147, 197, 253, 0.25)";
          ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(mouseX, mouseY); ctx.stroke();
        }
      }
      s.y += s.speedY; s.x += s.speedX; s.rot += s.rotSpeed; s.twinkle += 0.06;
      if (s.y > h + 15) { s.y = -15; s.x = Math.random() * w; }
      if (s.x < -15) s.x = w + 15; if (s.x > w + 15) s.x = -15;
      const alpha = 0.45 + 0.55 * ((Math.sin(s.twinkle) + 1) * 0.5);
      ctx.save(); ctx.globalAlpha = alpha;
      const trailGrad = ctx.createLinearGradient(s.x, s.y, s.x - s.speedX * 10, s.y - s.speedY * 10);
      trailGrad.addColorStop(0, s.color);
      trailGrad.addColorStop(1, "rgba(255,255,255,0)");
      ctx.strokeStyle = trailGrad; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(s.x - s.speedX * 10, s.y - s.speedY * 10); ctx.stroke();
      ctx.fillStyle = s.color; drawStarShape(ctx, s.x, s.y, 5, s.outerR, s.outerR * 0.42, s.rot);
      ctx.restore();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

// ==========================================
// 2-10. EXTRA-DETAILED SAKURA THEMES (Cached Botanical Petals, Full 5-Petal Blossoms & Swaying Branches)
// ==========================================

// 2. Sakura Petals (Classic Drifting + Corner Blossom Branches + Full 5-Petal Blooms + Wind & Click Burst)
function startSakura() {
  const canvas = createOverlayCanvas("0.75");
  const ctx = canvas.getContext("2d");
  const sprites = [
    getSakuraPetalSprite("#fff0f6", "#f472b6", "rgba(255,255,255,0.35)"),
    getSakuraPetalSprite("#fce7f3", "#f9a8d4", "rgba(255,255,255,0.35)"),
    getSakuraPetalSprite("#fbcfe8", "#ec4899", "rgba(255,255,255,0.35)")
  ];
  const blossomSprite = getSakuraBlossomSprite("#fff0f6", "#f472b6");

  const makePetal = (x, y, burst = false) => {
    const angle = Math.random() * Math.PI * 2;
    const speed = burst ? 2.5 + Math.random() * 4.5 : 0;
    return {
      x: x ?? Math.random() * window.innerWidth,
      y: y ?? Math.random() * window.innerHeight,
      size: 6 + Math.random() * 6,
      baseVx: 0.4 + Math.random() * 0.9,
      baseVy: 0.9 + Math.random() * 1.4,
      vx: burst ? Math.cos(angle) * speed : 0,
      vy: burst ? Math.sin(angle) * speed : 0,
      rot: Math.random() * Math.PI * 2,
      rotSpeed: (Math.random() - 0.5) * 0.04,
      flip: Math.random() * Math.PI * 2,
      flipSpeed: 0.03 + Math.random() * 0.04,
      swayOffset: Math.random() * Math.PI * 2,
      isFullBlossom: Math.random() < 0.12,
      sprite: sprites[Math.floor(Math.random() * sprites.length)]
    };
  };

  const petals = Array.from({ length: 65 }, () => makePetal());
  registerClick((e) => {
    for (let i = 0; i < 14; i++) petals.push(makePetal(e.clientX, e.clientY, true));
    if (petals.length > 150) petals.splice(0, petals.length - 150);
  });

  function draw(now) {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Subtle corner cherry blossom branches framing top-left & top-right
    drawSakuraBranch(ctx, -10, 45, 0.32, 85, 4, blossomSprite, now);
    drawSakuraBranch(ctx, w + 10, 65, Math.PI - 0.35, 80, 4, blossomSprite, now);

    for (let i = 0; i < petals.length; i++) {
      const p = petals[i];
      applyCursorWind(p, 145, 1.4);
      p.vx *= 0.94; p.vy *= 0.94;
      p.swayOffset += 0.025;
      p.x += p.baseVx + p.vx + Math.sin(p.swayOffset) * 0.85;
      p.y += p.baseVy + p.vy;
      p.rot += p.rotSpeed;
      p.flip += p.flipSpeed;

      if (p.y > h + 20) { p.y = -20; p.x = Math.random() * w; }
      if (p.x > w + 20) p.x = -20;
      if (p.x < -20) p.x = w + 20;

      if (p.isFullBlossom) {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        const s = (p.size / 10) * 0.55;
        ctx.drawImage(blossomSprite, -blossomSprite.width * 0.5 * s, -blossomSprite.height * 0.5 * s, blossomSprite.width * s, blossomSprite.height * s);
        ctx.restore();
      } else {
        drawBlittedPetal(ctx, p.sprite, p.x, p.y, p.size, p.rot, p.flip);
      }
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw(0);
}

// 3. Glow Sakura (Luminescent Neon Blossoms + Trailing Pollen Sparks)
function startSakuraglow() {
  const canvas = createOverlayCanvas("0.78");
  const ctx = canvas.getContext("2d");
  const sprite = getSakuraPetalSprite("#ffffff", "#ff5c9e", "rgba(255,255,255,0.45)", "#ff77a9");
  const blossomSprite = getSakuraBlossomSprite("#ffffff", "#ff5c9e");

  const petals = Array.from({ length: 60 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    size: 7 + Math.random() * 6,
    baseVy: 0.7 + Math.random() * 1.4,
    vx: 0, vy: 0,
    rot: Math.random() * Math.PI * 2,
    flip: Math.random() * Math.PI * 2,
    phase: Math.random() * Math.PI * 2
  }));

  registerClick((e) => {
    for (let i = 0; i < 14; i++) {
      const a = (Math.PI * 2 * i) / 14;
      petals.push({
        x: e.clientX, y: e.clientY, size: 7 + Math.random() * 5,
        baseVy: 0.8 + Math.random() * 1.2,
        vx: Math.cos(a) * (2.5 + Math.random() * 3),
        vy: Math.sin(a) * (2.5 + Math.random() * 3),
        rot: a, flip: Math.random() * Math.PI, phase: Math.random() * Math.PI * 2
      });
    }
    if (petals.length > 145) petals.splice(0, petals.length - 145);
  });

  function draw(now) {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    drawSakuraBranch(ctx, -10, 50, 0.28, 78, 3, blossomSprite, now);

    for (let i = 0; i < petals.length; i++) {
      const p = petals[i];
      applyCursorWind(p, 150, 1.3);
      p.vx *= 0.94; p.vy *= 0.94;
      p.phase += 0.04; p.flip += 0.045; p.rot += 0.025;
      p.x += Math.sin(p.phase) * 1.1 + p.vx;
      p.y += p.baseVy + p.vy;

      if (p.y > h + 22) { p.y = -22; p.x = Math.random() * w; }
      if (p.x > w + 22) p.x = -22;
      if (p.x < -22) p.x = w + 22;

      const pulse = 0.65 + 0.35 * Math.sin(p.phase * 1.5);
      drawBlittedPetal(ctx, sprite, p.x, p.y, p.size, p.rot, p.flip, pulse);
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw(0);
}

// 4. Sakura Blizzard (Heavy Spring Storm + Wind Streaks + Gust Clicks)
function startSakurastorm() {
  const canvas = createOverlayCanvas("0.78");
  const ctx = canvas.getContext("2d");
  const sprite1 = getSakuraPetalSprite("#ffe4e6", "#ff4d94", "rgba(255,255,255,0.35)");
  const sprite2 = getSakuraPetalSprite("#fff0f6", "#f43f5e", "rgba(255,255,255,0.35)");
  let gustBoost = 0;

  const petals = Array.from({ length: 100 }, () => ({
    x: Math.random() * window.innerWidth * 1.3,
    y: Math.random() * window.innerHeight,
    size: 5 + Math.random() * 5.5,
    speedY: 2.8 + Math.random() * 3.2,
    speedX: -2.2 - Math.random() * 2.2,
    vx: 0, vy: 0,
    rot: Math.random() * Math.PI * 2,
    flip: Math.random() * Math.PI * 2,
    sprite: Math.random() > 0.5 ? sprite1 : sprite2
  }));

  registerClick(() => { gustBoost = 7; });

  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    gustBoost *= 0.94;

    // Subtle wind air lines
    ctx.strokeStyle = "rgba(255, 182, 193, 0.16)";
    ctx.lineWidth = 1;
    for (let k = 0; k < 8; k++) {
      const wy = ((performance.now() * 0.25 + k * 140) % h);
      const wx = w - ((performance.now() * 0.9 + k * 230) % (w + 200));
      ctx.beginPath(); ctx.moveTo(wx, wy); ctx.lineTo(wx + 90, wy - 45); ctx.stroke();
    }

    for (let i = 0; i < petals.length; i++) {
      const p = petals[i];
      applyCursorWind(p, 160, 1.8);
      p.vx *= 0.92; p.vy *= 0.92;
      p.x += p.speedX - gustBoost + p.vx;
      p.y += p.speedY + gustBoost * 0.4 + p.vy;
      p.rot += 0.07; p.flip += 0.08;

      if (p.y > h + 20 || p.x < -20) {
        p.y = Math.random() > 0.3 ? -20 : Math.random() * h * 0.6;
        p.x = w + Math.random() * 80;
      }
      drawBlittedPetal(ctx, p.sprite, p.x, p.y, p.size, p.rot, p.flip);
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

// 5. Midnight Sakura (Yozakura Moonlit Tree & Glowing Petals)
function startSakuranight() {
  const canvas = createOverlayCanvas("0.72");
  const ctx = canvas.getContext("2d");
  const sprite = getSakuraPetalSprite("#fdf2f8", "#f472b6", "rgba(255,255,255,0.35)", "#f9a8d4");
  const blossomSprite = getSakuraBlossomSprite("#fdf2f8", "#f472b6");

  const petals = Array.from({ length: 65 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    size: 6 + Math.random() * 5,
    baseVy: 0.9 + Math.random() * 1.4,
    baseVx: (Math.random() - 0.5) * 0.8,
    vx: 0, vy: 0,
    rot: Math.random() * Math.PI * 2,
    flip: Math.random() * Math.PI * 2
  }));

  registerClick((e) => {
    for (let i = 0; i < 12; i++) {
      const a = Math.random() * Math.PI * 2;
      petals.push({
        x: e.clientX, y: e.clientY, size: 6 + Math.random() * 5,
        baseVy: 1 + Math.random(), baseVx: 0,
        vx: Math.cos(a) * 3.5, vy: Math.sin(a) * 3.5,
        rot: a, flip: Math.random() * Math.PI
      });
    }
    if (petals.length > 140) petals.splice(0, petals.length - 140);
  });

  function draw(now) {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Full Yozakura Moon & Halo
    const mx = w * 0.82, my = h * 0.18;
    const moonGrad = ctx.createRadialGradient(mx, my, 18, mx, my, 130);
    moonGrad.addColorStop(0, "rgba(255, 250, 240, 0.65)");
    moonGrad.addColorStop(0.25, "rgba(249, 168, 212, 0.22)");
    moonGrad.addColorStop(1, "rgba(44, 22, 58, 0)");
    ctx.fillStyle = moonGrad;
    ctx.fillRect(0, 0, w, h);

    ctx.fillStyle = "rgba(255, 251, 235, 0.85)";
    ctx.beginPath(); ctx.arc(mx, my, 26, 0, Math.PI * 2); ctx.fill();

    // Moonlit silhouette branch across the moon
    drawSakuraBranch(ctx, w + 10, my + 70, Math.PI + 0.28, 95, 4, blossomSprite, now);

    for (let i = 0; i < petals.length; i++) {
      const p = petals[i];
      applyCursorWind(p, 140, 1.3);
      p.vx *= 0.94; p.vy *= 0.94;
      p.y += p.baseVy + p.vy;
      p.x += p.baseVx + p.vx + Math.sin(p.y * 0.02) * 0.7;
      p.rot += 0.025; p.flip += 0.04;
      if (p.y > h + 20) { p.y = -20; p.x = Math.random() * w; }
      drawBlittedPetal(ctx, sprite, p.x, p.y, p.size, p.rot, p.flip);
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw(0);
}

// 6. Hanami Festival (Detailed Chōchin Paper Lanterns + Falling Sakura Petals)
function startSakurafest() {
  const canvas = createOverlayCanvas("0.72");
  const ctx = canvas.getContext("2d");
  const sprite = getSakuraPetalSprite("#fff1f2", "#fb7185", "rgba(255,255,255,0.35)");

  const petals = Array.from({ length: 60 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    size: 6 + Math.random() * 5,
    baseVy: 1.1 + Math.random() * 1.5,
    vx: 0, vy: 0,
    rot: Math.random() * Math.PI * 2,
    flip: Math.random() * Math.PI * 2
  }));

  registerClick((e) => {
    for (let i = 0; i < 12; i++) {
      const a = Math.random() * Math.PI * 2;
      petals.push({
        x: e.clientX, y: e.clientY, size: 6 + Math.random() * 5,
        baseVy: 1.1 + Math.random(), vx: Math.cos(a) * 3.2, vy: Math.sin(a) * 3.2,
        rot: a, flip: Math.random() * Math.PI
      });
    }
    if (petals.length > 140) petals.splice(0, petals.length - 140);
  });

  function draw(now) {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Festival festoon cord
    ctx.strokeStyle = "rgba(120, 53, 15, 0.7)";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, 12); ctx.quadraticCurveTo(w / 2, 26, w, 12); ctx.stroke();

    // Detailed Japanese Chōchin Paper Lanterns
    for (let k = 0; k < 5; k++) {
      const lx = (w / 6) * (k + 1);
      const ly = 38 + Math.sin(now * 0.002 + k) * 6;
      const glow = ctx.createRadialGradient(lx, ly, 4, lx, ly, 46);
      glow.addColorStop(0, "rgba(251, 146, 60, 0.55)");
      glow.addColorStop(1, "rgba(255, 69, 0, 0)");
      ctx.fillStyle = glow;
      ctx.beginPath(); ctx.arc(lx, ly, 46, 0, Math.PI * 2); ctx.fill();

      // Lantern body
      ctx.fillStyle = "#ef4444";
      ctx.beginPath(); ctx.ellipse(lx, ly, 12, 16, 0, 0, Math.PI * 2); ctx.fill();
      // Ribbed bands & caps
      ctx.strokeStyle = "rgba(127, 29, 29, 0.65)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(lx - 11, ly - 5); ctx.lineTo(lx + 11, ly - 5);
      ctx.moveTo(lx - 11, ly + 5); ctx.lineTo(lx + 11, ly + 5);
      ctx.stroke();
      ctx.fillStyle = "#1f2937";
      ctx.fillRect(lx - 7, ly - 18, 14, 3);
      ctx.fillRect(lx - 7, ly + 15, 14, 3);
    }

    for (let i = 0; i < petals.length; i++) {
      const p = petals[i];
      applyCursorWind(p, 140, 1.3);
      p.vx *= 0.94; p.vy *= 0.94;
      p.y += p.baseVy + p.vy;
      p.x += Math.sin(p.y * 0.025) * 1.2 + p.vx;
      p.rot += 0.03; p.flip += 0.04;
      if (p.y > h + 20) { p.y = -20; p.x = Math.random() * w; }
      drawBlittedPetal(ctx, sprite, p.x, p.y, p.size, p.rot, p.flip);
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw(0);
}

// 7. Sakura Whirlpool (Cursor-Centered Blossom Vortex + Luminous Spiral Trails)
function startSakuracircle() {
  const canvas = createOverlayCanvas("0.72");
  const ctx = canvas.getContext("2d");
  const sprite = getSakuraPetalSprite("#fdf4ff", "#e879f9", "rgba(255,255,255,0.35)");
  let angle = 0;
  let spinBoost = 0;

  const petals = Array.from({ length: 70 }, () => ({
    dist: 25 + Math.random() * 290,
    speed: 0.008 + Math.random() * 0.018,
    offset: Math.random() * Math.PI * 2,
    size: 5.5 + Math.random() * 5,
    flip: Math.random() * Math.PI * 2
  }));

  registerClick(() => { spinBoost = 0.095; });

  function draw() {
    const w = canvas.width, h = canvas.height;
    const cx = mouseX !== -999 ? mouseX : w / 2, cy = mouseY !== -999 ? mouseY : h / 2;
    ctx.clearRect(0, 0, w, h);
    spinBoost *= 0.95;
    angle += 0.015 + spinBoost;

    // Subtle vortex ring guides
    ctx.strokeStyle = "rgba(232, 121, 249, 0.14)";
    ctx.lineWidth = 1.2;
    for (let r = 80; r <= 260; r += 90) {
      ctx.beginPath(); ctx.ellipse(cx, cy, r, r * 0.68, 0, 0, Math.PI * 2); ctx.stroke();
    }

    for (let i = 0; i < petals.length; i++) {
      const p = petals[i];
      p.dist += 0.25;
      if (p.dist > 330) p.dist = 25;
      p.flip += 0.04;
      const a = angle + p.offset + p.speed * 15;
      const px = cx + Math.cos(a) * p.dist;
      const py = cy + Math.sin(a) * (p.dist * 0.68);
      drawBlittedPetal(ctx, sprite, px, py, p.size, a + Math.PI / 2, p.flip);
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

// 8. Sakura Water Ripple (Floating Petals, Koi Shadows & Concentric Pond Ripples)
function startSakurapond() {
  const canvas = createOverlayCanvas("0.72");
  const ctx = canvas.getContext("2d");
  const sprite = getSakuraPetalSprite("#fff0f6", "#f472b6", "rgba(255,255,255,0.35)");
  const ripples = [];
  const petals = Array.from({ length: 55 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    size: 6 + Math.random() * 5,
    vx: (Math.random() - 0.5) * 0.6,
    vy: (Math.random() - 0.5) * 0.6,
    rot: Math.random() * Math.PI * 2
  }));

  registerClick((e) => {
    ripples.push({ x: e.clientX, y: e.clientY, r: 6, alpha: 0.95 });
    ripples.push({ x: e.clientX, y: e.clientY, r: 1, alpha: 0.65 });
    for (let i = 0; i < petals.length; i++) {
      const p = petals[i];
      const dx = p.x - e.clientX, dy = p.y - e.clientY;
      const d = Math.hypot(dx, dy);
      if (d > 1 && d < 230) {
        p.vx += (dx / d) * 2.5;
        p.vy += (dy / d) * 2.5;
      }
    }
  });

  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    if (Math.random() < 0.03) {
      ripples.push({ x: Math.random() * w, y: Math.random() * h, r: 4, alpha: 0.55 });
    }

    for (let i = ripples.length - 1; i >= 0; i--) {
      const rip = ripples[i];
      rip.r += 2.2;
      rip.alpha -= 0.018;
      if (rip.alpha <= 0) { ripples.splice(i, 1); continue; }
      ctx.strokeStyle = `rgba(94, 234, 212, ${rip.alpha})`;
      ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.arc(rip.x, rip.y, rip.r, 0, Math.PI * 2); ctx.stroke();
    }

    for (let i = 0; i < petals.length; i++) {
      const p = petals[i];
      applyCursorWind(p, 115, 0.75);
      p.vx *= 0.97; p.vy *= 0.97;
      p.x += p.vx; p.y += p.vy;
      p.rot += 0.008;
      if (p.x < 10 || p.x > w - 10) p.vx *= -1;
      if (p.y < 10 || p.y > h - 10) p.vy *= -1;
      drawBlittedPetal(ctx, sprite, p.x, p.y, p.size, p.rot, 0.2);
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

// 9. Spring Sakura Rain (Raindrops, Splash Rings & Drifting Petals)
function startSakurarain() {
  const canvas = createOverlayCanvas("0.72");
  const ctx = canvas.getContext("2d");
  const sprite = getSakuraPetalSprite("#fff0f6", "#f472b6", "rgba(255,255,255,0.35)");
  const splashes = [];
  const drops = Array.from({ length: 90 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    len: 14 + Math.random() * 18,
    speed: 6.5 + Math.random() * 4.5,
    isPetal: Math.random() > 0.52,
    size: 5.5 + Math.random() * 4.5,
    rot: Math.random() * Math.PI * 2,
    flip: Math.random() * Math.PI * 2,
    vx: 0, vy: 0
  }));

  registerClick((e) => {
    for (let i = 0; i < 10; i++) {
      const a = Math.random() * Math.PI * 2;
      drops.push({
        x: e.clientX, y: e.clientY, len: 14, speed: 1.8, isPetal: true,
        size: 6 + Math.random() * 4, rot: a, flip: Math.random() * Math.PI,
        vx: Math.cos(a) * 3, vy: Math.sin(a) * 3
      });
    }
    if (drops.length > 145) drops.splice(0, drops.length - 145);
  });

  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < drops.length; i++) {
      const d = drops[i];
      if (d.isPetal) {
        applyCursorWind(d, 130, 1.2);
        d.vx *= 0.94; d.vy *= 0.94;
        d.y += d.speed * 0.35 + d.vy;
        d.x += Math.sin(d.y * 0.025) * 0.9 + d.vx;
        d.rot += 0.03; d.flip += 0.04;
        if (d.y > h + 20) { d.y = -20; d.x = Math.random() * w; }
        drawBlittedPetal(ctx, sprite, d.x, d.y, d.size, d.rot, d.flip);
      } else {
        d.y += d.speed; d.x -= 0.8;
        if (d.y > h - 10) {
          if (splashes.length < 30 && Math.random() < 0.35) splashes.push({ x: d.x, y: h - 8, r: 2, alpha: 0.6 });
          d.y = -20; d.x = Math.random() * w;
        }
        ctx.strokeStyle = "rgba(125, 211, 252, 0.55)";
        ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.moveTo(d.x, d.y); ctx.lineTo(d.x - 2, d.y + d.len); ctx.stroke();
      }
    }
    for (let i = splashes.length - 1; i >= 0; i--) {
      const sp = splashes[i];
      sp.r += 1.4; sp.alpha -= 0.04;
      if (sp.alpha <= 0) { splashes.splice(i, 1); continue; }
      ctx.strokeStyle = `rgba(186, 230, 253, ${sp.alpha})`;
      ctx.beginPath(); ctx.ellipse(sp.x, sp.y, sp.r * 2, sp.r * 0.6, 0, 0, Math.PI * 2); ctx.stroke();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

// 10. Golden Sakura (Imperial Golden Blossoms + Gold Leaf Sparkles)
function startSakuragold() {
  const canvas = createOverlayCanvas("0.75");
  const ctx = canvas.getContext("2d");
  const sprite = getSakuraPetalSprite("#fef9c3", "#f59e0b", "rgba(255,255,255,0.45)", "#fbbf24");
  const blossomSprite = getSakuraBlossomSprite("#fef9c3", "#f59e0b");

  const petals = Array.from({ length: 65 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    size: 6 + Math.random() * 5.5,
    baseVy: 1 + Math.random() * 1.5,
    baseVx: 0.4 + Math.random() * 0.8,
    vx: 0, vy: 0,
    rot: Math.random() * Math.PI * 2,
    flip: Math.random() * Math.PI * 2
  }));

  registerClick((e) => {
    for (let i = 0; i < 14; i++) {
      const a = (Math.PI * 2 * i) / 14;
      petals.push({
        x: e.clientX, y: e.clientY, size: 6.5 + Math.random() * 4.5,
        baseVy: 1 + Math.random(), baseVx: 0.4,
        vx: Math.cos(a) * 3.5, vy: Math.sin(a) * 3.5,
        rot: a, flip: Math.random() * Math.PI
      });
    }
    if (petals.length > 145) petals.splice(0, petals.length - 145);
  });

  function draw(now) {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    drawSakuraBranch(ctx, -10, 48, 0.3, 82, 4, blossomSprite, now);

    for (let i = 0; i < petals.length; i++) {
      const p = petals[i];
      applyCursorWind(p, 140, 1.4);
      p.vx *= 0.94; p.vy *= 0.94;
      p.y += p.baseVy + p.vy;
      p.x += p.baseVx + p.vx + Math.sin(p.y * 0.02) * 0.8;
      p.rot += 0.03; p.flip += 0.04;
      if (p.y > h + 20) { p.y = -20; p.x = Math.random() * w; }
      if (p.x > w + 20) p.x = -20;
      drawBlittedPetal(ctx, sprite, p.x, p.y, p.size, p.rot, p.flip);
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw(0);
}

// ==========================================
// HIGH-DETAIL INTERACTIVE ANIMATIONS (ALL 40 REMAINING MODES UPGRADED)
// ==========================================

function startMatrixRain(tint = "#00ff41", bgFade = "rgba(2, 10, 3, 0.14)") {
  const canvas = createOverlayCanvas("0.38");
  const ctx = canvas.getContext("2d");
  const chars = "01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲンABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const fontSize = 14;
  let columns = Math.floor(canvas.width / fontSize);
  let drops = Array(columns).fill(1);
  let lastTime = 0;
  registerClick((e) => {
    const colCenter = Math.floor(e.clientX / fontSize);
    for (let c = colCenter - 4; c <= colCenter + 4; c++) {
      if (c >= 0 && c < drops.length) drops[c] = Math.floor(e.clientY / fontSize);
    }
  });
  function draw(now) {
    animFrameId = requestAnimationFrame(draw);
    if (now - lastTime < 38) return;
    lastTime = now;
    if (columns !== Math.floor(canvas.width / fontSize)) { columns = Math.floor(canvas.width / fontSize); drops = Array(columns).fill(1); }
    ctx.fillStyle = bgFade; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.font = fontSize + "px monospace";
    for (let i = 0; i < drops.length; i++) {
      const x = i * fontSize, y = drops[i] * fontSize;
      const text = chars[Math.floor(Math.random() * chars.length)];
      ctx.fillStyle = "#ffffff";
      ctx.fillText(text, x, y);
      ctx.fillStyle = tint;
      ctx.fillText(chars[Math.floor(Math.random() * chars.length)], x, y - fontSize);
      if (y > canvas.height && Math.random() > 0.975) drops[i] = 0;
      drops[i]++;
    }
  }
  animFrameId = requestAnimationFrame(draw);
}

function startSynthwaveGrid() {
  const canvas = createOverlayCanvas("0.45");
  const ctx = canvas.getContext("2d");
  let offset = 0;
  function draw() {
    const w = canvas.width, h = canvas.height;
    const mouseOffsetFactor = (mouseX !== -999) ? (mouseX - w / 2) * 0.2 : 0;
    const horizon = h * 0.52;
    ctx.clearRect(0, 0, w, h);
    const sunRadius = Math.min(w, h) * 0.17;
    const sunX = w / 2 + mouseOffsetFactor * 0.35;
    const sunGrad = ctx.createLinearGradient(0, horizon - sunRadius, 0, horizon);
    sunGrad.addColorStop(0, "rgba(255, 211, 25, 0.95)"); sunGrad.addColorStop(1, "rgba(255, 41, 117, 0.25)");
    ctx.beginPath(); ctx.arc(sunX, horizon, sunRadius, Math.PI, 0); ctx.fillStyle = sunGrad; ctx.fill();

    // Retro sun scanline cutouts
    ctx.fillStyle = "rgba(19, 4, 33, 0.75)";
    for (let band = 1; band <= 5; band++) {
      const by = horizon - (sunRadius * 0.15 * band);
      ctx.fillRect(sunX - sunRadius, by, sunRadius * 2, band * 1.4);
    }

    // Horizon glow line
    ctx.strokeStyle = "#ff2a85"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, horizon); ctx.lineTo(w, horizon); ctx.stroke();

    // Perspective vertical grid lines
    ctx.strokeStyle = "rgba(5, 217, 232, 0.55)"; ctx.lineWidth = 1.2;
    const vpX = w / 2 + mouseOffsetFactor * 0.5;
    for (let i = -12; i <= 12; i++) {
      ctx.beginPath();
      ctx.moveTo(vpX + i * 28, horizon);
      ctx.lineTo(vpX + i * 165, h);
      ctx.stroke();
    }

    // Moving horizontal perspective lines
    offset = (offset + 1.5) % 40;
    for (let y = 0; y < h - horizon; y += 20) {
      const progress = (y + offset) / (h - horizon);
      const screenY = horizon + Math.pow(progress, 1.85) * (h - horizon);
      ctx.beginPath(); ctx.moveTo(0, screenY); ctx.lineTo(w, screenY); ctx.stroke();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startCyberpunkRain() {
  const canvas = createOverlayCanvas("0.48");
  const ctx = canvas.getContext("2d");
  const ripples = [];
  const drops = Array.from({ length: 120 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    len: 16 + Math.random() * 18,
    speed: 8 + Math.random() * 6,
    color: Math.random() > 0.25 ? "rgba(0, 240, 255, 0.78)" : "rgba(252, 238, 10, 0.75)"
  }));
  registerClick((e) => ripples.push({ x: e.clientX, y: e.clientY, r: 4, alpha: 0.95 }));
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < drops.length; i++) {
      const d = drops[i]; d.y += d.speed; d.x -= 1.1;
      if (d.y > h) {
        if (ripples.length < 25 && Math.random() < 0.25) ripples.push({ x: d.x, y: h - 6, r: 2, alpha: 0.65 });
        d.y = -20; d.x = Math.random() * w;
      }
      ctx.strokeStyle = d.color; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.moveTo(d.x, d.y); ctx.lineTo(d.x - 2.5, d.y + d.len); ctx.stroke();
    }
    for (let i = ripples.length - 1; i >= 0; i--) {
      const rip = ripples[i]; rip.r += 2.2; rip.alpha -= 0.035;
      if (rip.alpha <= 0) { ripples.splice(i, 1); continue; }
      ctx.strokeStyle = `rgba(0, 240, 255, ${rip.alpha})`;
      ctx.beginPath(); ctx.ellipse(rip.x, rip.y, rip.r * 2.2, rip.r * 0.7, 0, 0, Math.PI * 2); ctx.stroke();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startFireflies(primary = "#facc15", halo = "rgba(190, 242, 100, 0.25)") {
  const canvas = createOverlayCanvas("0.58");
  const ctx = canvas.getContext("2d");
  const flies = Array.from({ length: 65 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    vx: (Math.random() - 0.5) * 0.8,
    vy: (Math.random() - 0.5) * 0.8,
    r: 2.2 + Math.random() * 2.2,
    phase: Math.random() * Math.PI * 2
  }));
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < flies.length; i++) {
      const f = flies[i];
      f.phase += 0.045;
      f.vx += (Math.random() - 0.5) * 0.06;
      f.vy += (Math.random() - 0.5) * 0.06;
      if (mouseX !== -999) {
        const dx = mouseX - f.x, dy = mouseY - f.y;
        const dSq = dx * dx + dy * dy;
        if (dSq < 40000 && dSq > 400) { f.vx += dx * 0.0004; f.vy += dy * 0.0004; }
      }
      f.vx *= 0.96; f.vy *= 0.96;
      f.x += f.vx; f.y += f.vy;
      if (f.x < 0) f.x = w; if (f.x > w) f.x = 0;
      if (f.y < 0) f.y = h; if (f.y > h) f.y = 0;

      const glow = 0.35 + 0.65 * ((Math.sin(f.phase) + 1) * 0.5);
      ctx.globalAlpha = glow;
      ctx.fillStyle = halo;
      ctx.beginPath(); ctx.arc(f.x, f.y, f.r * 4.5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = primary;
      ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startParticles(nodeColor = "#38bdf8", lineRgb = "56, 189, 248") {
  const canvas = createOverlayCanvas("0.52");
  const ctx = canvas.getContext("2d");
  const pts = Array.from({ length: 65 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    vx: (Math.random() - 0.5) * 1.1,
    vy: (Math.random() - 0.5) * 1.1
  }));
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < pts.length; i++) {
      const p = pts[i];
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > w) p.vx *= -1;
      if (p.y < 0 || p.y > h) p.vy *= -1;

      for (let j = i + 1; j < pts.length; j++) {
        const q = pts[j];
        const dx = p.x - q.x, dy = p.y - q.y;
        const dSq = dx * dx + dy * dy;
        if (dSq < 14400) {
          ctx.strokeStyle = `rgba(${lineRgb}, ${(1 - Math.sqrt(dSq) / 120) * 0.45})`;
          ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke();
        }
      }
      if (mouseX !== -999) {
        const mdx = p.x - mouseX, mdy = p.y - mouseY;
        const mdSq = mdx * mdx + mdy * mdy;
        if (mdSq < 25600) {
          ctx.strokeStyle = `rgba(${lineRgb}, ${(1 - Math.sqrt(mdSq) / 160) * 0.75})`;
          ctx.lineWidth = 1.3;
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(mouseX, mouseY); ctx.stroke();
        }
      }
      ctx.fillStyle = nodeColor;
      ctx.beginPath(); ctx.arc(p.x, p.y, 2.4, 0, Math.PI * 2); ctx.fill();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startPortal() {
  const canvas = createOverlayCanvas("0.55");
  const ctx = canvas.getContext("2d");
  let angle = 0;
  function draw() {
    const w = canvas.width, h = canvas.height;
    const cx = mouseX !== -999 ? w / 2 + (mouseX - w / 2) * 0.15 : w / 2;
    const cy = mouseY !== -999 ? h / 2 + (mouseY - h / 2) * 0.15 : h / 2;
    ctx.clearRect(0, 0, w, h);
    angle += 0.025;
    for (let ring = 0; ring < 7; ring++) {
      const rx = 50 + ring * 32;
      const ry = 30 + ring * 19;
      ctx.strokeStyle = ring % 2 === 0 ? "rgba(168, 85, 247, 0.65)" : "rgba(236, 72, 153, 0.55)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx, ry, angle * (ring % 2 === 0 ? 1 : -0.8) + ring * 0.4, 0, Math.PI * 2);
      ctx.stroke();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startAurora(c1 = "rgba(16, 185, 129, 0.24)", c2 = "rgba(6, 182, 212, 0.18)") {
  const canvas = createOverlayCanvas("0.52");
  const ctx = canvas.getContext("2d");
  let step = 0;
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h); step += 0.018;
    for (let layer = 0; layer < 3; layer++) {
      ctx.fillStyle = layer % 2 === 0 ? c1 : c2;
      ctx.beginPath();
      ctx.moveTo(0, h * (0.25 + layer * 0.12));
      for (let x = 0; x <= w; x += 35) {
        const y = h * (0.25 + layer * 0.12) + Math.sin(x * 0.0035 + step + layer * 1.4) * 75 + Math.cos(x * 0.007 - step) * 30;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(w, h); ctx.lineTo(0, h); ctx.closePath(); ctx.fill();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startBubbles() {
  const canvas = createOverlayCanvas("0.55");
  const ctx = canvas.getContext("2d");
  const pops = [];
  const bubbles = Array.from({ length: 45 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    r: 8 + Math.random() * 14,
    speed: 0.8 + Math.random() * 1.4,
    wobble: Math.random() * Math.PI * 2
  }));
  registerClick((e) => {
    for (let i = bubbles.length - 1; i >= 0; i--) {
      const b = bubbles[i];
      if (Math.hypot(b.x - e.clientX, b.y - e.clientY) < b.r + 25) {
        pops.push({ x: b.x, y: b.y, r: b.r, alpha: 1 });
        b.y = window.innerHeight + 30;
        b.x = Math.random() * window.innerWidth;
      }
    }
  });
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < bubbles.length; i++) {
      const b = bubbles[i]; b.wobble += 0.03;
      b.y -= b.speed; b.x += Math.sin(b.wobble) * 0.6;
      if (b.y < -30) { b.y = h + 30; b.x = Math.random() * w; }
      ctx.strokeStyle = "rgba(110, 231, 183, 0.72)"; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2); ctx.stroke();
      // Specular highlight arc
      ctx.strokeStyle = "rgba(255, 255, 255, 0.65)";
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 0.68, -Math.PI * 0.75, -Math.PI * 0.35); ctx.stroke();
    }
    for (let i = pops.length - 1; i >= 0; i--) {
      const p = pops[i]; p.r += 2.5; p.alpha -= 0.06;
      if (p.alpha <= 0) { pops.splice(i, 1); continue; }
      ctx.strokeStyle = `rgba(186, 230, 253, ${p.alpha})`;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.stroke();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startLaser() {
  const canvas = createOverlayCanvas("0.48");
  const ctx = canvas.getContext("2d");
  let pulse = 0;
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    pulse += 0.06;
    const tx = mouseX !== -999 ? mouseX : w / 2, ty = mouseY !== -999 ? mouseY : h / 2;
    ctx.strokeStyle = "rgba(239, 68, 68, 0.45)"; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(tx, 0); ctx.lineTo(tx, h); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, ty); ctx.lineTo(w, ty); ctx.stroke();
    // Corner emitter beams
    ctx.strokeStyle = "rgba(245, 158, 11, 0.25)";
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(tx, ty); ctx.moveTo(w, 0); ctx.lineTo(tx, ty); ctx.stroke();
    // Reticle rings
    ctx.strokeStyle = "#ef4444"; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(tx, ty, 16 + Math.sin(pulse) * 4, 0, Math.PI * 2); ctx.stroke();
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

// ==========================================
// ZERO-LAG BLIZZARD SNOW (Cached 6-Branched Crystalline Snowflakes + Wind & Click Burst)
// ==========================================
function startSnowfall() {
  const canvas = createOverlayCanvas("0.82");
  const ctx = canvas.getContext("2d");

  // Pre-render 6 distinct snowflake sizes/variants ONCE into offscreen GPU sprites -> 60 FPS with 0 lag!
  const snowSprites = [
    getSnowflakeSprite(4.5, 0),
    getSnowflakeSprite(6.0, 0),
    getSnowflakeSprite(7.5, 1),
    getSnowflakeSprite(9.0, 0),
    getSnowflakeSprite(11.0, 1),
    getSnowflakeSprite(13.0, 1)
  ];

  const makeFlake = (x, y, burst = false) => {
    const angle = Math.random() * Math.PI * 2;
    const speed = burst ? 2.2 + Math.random() * 4 : 0;
    const sprite = snowSprites[Math.floor(Math.random() * snowSprites.length)];
    return {
      x: x ?? Math.random() * window.innerWidth,
      y: y ?? Math.random() * window.innerHeight,
      sprite,
      baseVy: 0.75 + Math.random() * 1.35,
      vx: burst ? Math.cos(angle) * speed : 0,
      vy: burst ? Math.sin(angle) * speed : 0,
      rot: Math.random() * Math.PI * 2,
      rotSpeed: (Math.random() - 0.5) * 0.025,
      sway: Math.random() * Math.PI * 2,
      alpha: 0.65 + Math.random() * 0.35
    };
  };

  const flakes = Array.from({ length: 70 }, () => makeFlake());

  registerClick((e) => {
    for (let i = 0; i < 14; i++) flakes.push(makeFlake(e.clientX, e.clientY, true));
    if (flakes.length > 140) flakes.splice(0, flakes.length - 140);
  });

  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < flakes.length; i++) {
      const f = flakes[i];
      applyCursorWind(f, 150, 1.5);
      f.vx *= 0.94; f.vy *= 0.94;
      f.sway += 0.02;
      f.x += Math.sin(f.sway) * 0.65 + f.vx;
      f.y += f.baseVy + f.vy;
      f.rot += f.rotSpeed;

      if (f.y > h + 22) { f.y = -22; f.x = Math.random() * w; }
      if (f.x > w + 22) f.x = -22;
      if (f.x < -22) f.x = w + 22;

      ctx.save();
      ctx.globalAlpha = f.alpha;
      ctx.translate(f.x, f.y);
      ctx.rotate(f.rot);
      ctx.drawImage(f.sprite, -f.sprite.width / 2, -f.sprite.height / 2);
      ctx.restore();
    }
    ctx.globalAlpha = 1;
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startPlasma() {
  const canvas = createOverlayCanvas("0.45");
  const ctx = canvas.getContext("2d");
  let t = 0;
  function draw() {
    const w = canvas.width, h = canvas.height;
    const cx = mouseX !== -999 ? w / 2 + (mouseX - w / 2) * 0.2 : w / 2;
    const cy = mouseY !== -999 ? h / 2 + (mouseY - h / 2) * 0.2 : h / 2;
    ctx.clearRect(0, 0, w, h); t += 0.035;
    for (let k = 0; k < 4; k++) {
      const ox = cx + Math.cos(t + k * 1.5) * 90;
      const oy = cy + Math.sin(t * 1.2 + k) * 60;
      const r = 80 + Math.sin(t * 2 + k) * 35;
      const grad = ctx.createRadialGradient(ox, oy, 5, ox, oy, r);
      grad.addColorStop(0, "rgba(217, 70, 239, 0.45)");
      grad.addColorStop(1, "rgba(139, 92, 246, 0)");
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.arc(ox, oy, r, 0, Math.PI * 2); ctx.fill();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startComet(color = "253, 186, 116") {
  const canvas = createOverlayCanvas("0.55");
  const ctx = canvas.getContext("2d");
  const comets = Array.from({ length: 22 }, () => ({
    x: Math.random() * window.innerWidth * 1.5,
    y: Math.random() * window.innerHeight - window.innerHeight,
    speed: 5 + Math.random() * 4,
    len: 70 + Math.random() * 60
  }));
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < comets.length; i++) {
      const c = comets[i]; c.x -= c.speed * 1.4; c.y += c.speed;
      if (c.y > h + 60 || c.x < -60) { c.x = w + Math.random() * 200; c.y = -40; }
      const grad = ctx.createLinearGradient(c.x, c.y, c.x + c.len * 1.4, c.y - c.len);
      grad.addColorStop(0, `rgba(${color}, 0.95)`);
      grad.addColorStop(1, `rgba(${color}, 0)`);
      ctx.strokeStyle = grad; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.moveTo(c.x, c.y); ctx.lineTo(c.x + c.len * 1.4, c.y - c.len); ctx.stroke();
      ctx.fillStyle = "#ffffff";
      ctx.beginPath(); ctx.arc(c.x, c.y, 2.2, 0, Math.PI * 2); ctx.fill();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startMatrix3D() {
  const canvas = createOverlayCanvas("0.48");
  const ctx = canvas.getContext("2d");
  let angle = 0;
  const ringChars = "0101100101011100101001101010";
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h); angle += 0.02;
    ctx.font = "bold 13px monospace";
    for (let layer = -1; layer <= 1; layer++) {
      const rx = 220 + layer * 45, ry = 75 + layer * 15;
      for (let i = 0; i < ringChars.length; i++) {
        const a = angle * (layer === 0 ? -1 : 1) + (i / ringChars.length) * Math.PI * 2;
        const x = w / 2 + Math.cos(a) * rx;
        const y = h / 2 + layer * 55 + Math.sin(a) * ry;
        const depth = (Math.sin(a) + 1) * 0.5;
        ctx.fillStyle = `rgba(0, 255, 65, ${0.25 + depth * 0.75})`;
        ctx.fillText(ringChars[i], x, y);
      }
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startNebula() { startDeepSpace(); }

function startElectric() {
  const canvas = createOverlayCanvas("0.55");
  const ctx = canvas.getContext("2d");
  function drawBolt(x1, y1, x2, y2, displace) {
    if (displace < 4) {
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      return;
    }
    const midX = (x1 + x2) / 2 + (Math.random() - 0.5) * displace;
    const midY = (y1 + y2) / 2 + (Math.random() - 0.5) * displace;
    drawBolt(x1, y1, midX, midY, displace / 2);
    drawBolt(midX, midY, x2, y2, displace / 2);
  }
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    if (Math.random() > 0.72) {
      const startX = Math.random() * w;
      const targetX = mouseX !== -999 ? mouseX : startX + (Math.random() - 0.5) * 200;
      const targetY = mouseY !== -999 ? mouseY : h;
      ctx.strokeStyle = "rgba(56, 189, 248, 0.85)"; ctx.lineWidth = 2;
      drawBolt(startX, 0, targetX, targetY, 90);
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startNeonRings() {
  const canvas = createOverlayCanvas("0.48");
  const ctx = canvas.getContext("2d");
  const rings = [{ r: 20 }, { r: 120 }, { r: 220 }];
  registerClick((e) => rings.push({ r: 5, x: e.clientX, y: e.clientY }));
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = rings.length - 1; i >= 0; i--) {
      const ring = rings[i]; ring.r += 2.2;
      if (ring.r > 360) {
        if (rings.length > 3) { rings.splice(i, 1); continue; }
        ring.r = 10;
      }
      const alpha = Math.max(0, 1 - ring.r / 360);
      ctx.strokeStyle = `rgba(6, 182, 212, ${alpha})`; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(ring.x ?? w / 2, ring.y ?? h / 2, ring.r, 0, Math.PI * 2); ctx.stroke();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startFireworks() {
  const canvas = createOverlayCanvas("0.62");
  const ctx = canvas.getContext("2d");
  const sparks = [];
  const colors = ["#f43f5e", "#a855f7", "#38bdf8", "#facc15", "#4ade80"];
  function spawnBurst(bx, by) {
    const col = colors[Math.floor(Math.random() * colors.length)];
    for (let i = 0; i < 28; i++) {
      const a = (Math.PI * 2 * i) / 28 + Math.random() * 0.2;
      const spd = 1.5 + Math.random() * 4.5;
      sparks.push({ x: bx, y: by, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, life: 1, color: col });
    }
  }
  registerClick((e) => spawnBurst(e.clientX, e.clientY));
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    if (Math.random() < 0.03) spawnBurst(w * 0.2 + Math.random() * w * 0.6, h * 0.15 + Math.random() * h * 0.45);
    for (let i = sparks.length - 1; i >= 0; i--) {
      const s = sparks[i];
      s.x += s.vx; s.y += s.vy; s.vy += 0.05; s.vx *= 0.97; s.life -= 0.018;
      if (s.life <= 0) { sparks.splice(i, 1); continue; }
      ctx.globalAlpha = s.life;
      ctx.fillStyle = s.color;
      ctx.beginPath(); ctx.arc(s.x, s.y, 2.4, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}

function startGoldMatrix() { startMatrixRain("#eab308", "rgba(23, 15, 2, 0.14)"); }
function startSonar() {
  const canvas = createOverlayCanvas("0.48");
  const ctx = canvas.getContext("2d");
  let sweep = 0;
  function draw() {
    const w = canvas.width, h = canvas.height, cx = w / 2, cy = h / 2;
    const maxR = Math.min(w, h) * 0.42;
    ctx.clearRect(0, 0, w, h); sweep += 0.025;
    ctx.strokeStyle = "rgba(16, 185, 129, 0.28)"; ctx.lineWidth = 1.2;
    for (let r = maxR * 0.25; r <= maxR; r += maxR * 0.25) {
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.strokeStyle = "rgba(52, 211, 153, 0.85)"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(sweep) * maxR, cy + Math.sin(sweep) * maxR); ctx.stroke();
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}
function startWarp() {
  const canvas = createOverlayCanvas("0.52");
  const ctx = canvas.getContext("2d");
  const stars = Array.from({ length: 120 }, () => ({ x: (Math.random() - 0.5) * 1600, y: (Math.random() - 0.5) * 1600, z: Math.random() * 1000 }));
  function draw() {
    const w = canvas.width, h = canvas.height, cx = w / 2, cy = h / 2;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < stars.length; i++) {
      const s = stars[i]; s.z -= 14;
      if (s.z <= 1) { s.z = 1000; s.x = (Math.random() - 0.5) * 1600; s.y = (Math.random() - 0.5) * 1600; }
      const sx = cx + (s.x / s.z) * 300, sy = cy + (s.y / s.z) * 300;
      const px = cx + (s.x / (s.z + 35)) * 300, py = cy + (s.y / (s.z + 35)) * 300;
      ctx.strokeStyle = "#86efac"; ctx.lineWidth = Math.max(1, (1 - s.z / 1000) * 3);
      ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(sx, sy); ctx.stroke();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}
function startSolar() {
  const canvas = createOverlayCanvas("0.55");
  const ctx = canvas.getContext("2d");
  const embers = Array.from({ length: 75 }, () => ({ x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight, r: 1.5 + Math.random() * 3, vy: 1.2 + Math.random() * 2.5, sway: Math.random() * Math.PI * 2 }));
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < embers.length; i++) {
      const e = embers[i]; e.sway += 0.04; e.y -= e.vy; e.x += Math.sin(e.sway) * 0.9;
      if (e.y < -15) { e.y = h + 15; e.x = Math.random() * w; }
      ctx.fillStyle = e.r > 3 ? "#fdba74" : "#ea580c";
      ctx.beginPath(); ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2); ctx.fill();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}
function startBiolum() { startFireflies("#5eead4", "rgba(20, 184, 166, 0.25)"); }
function startQuantum() { startParticles("#c4b5fd", "139, 92, 246"); }
function startHearts() {
  const canvas = createOverlayCanvas("0.55");
  const ctx = canvas.getContext("2d");
  const hearts = Array.from({ length: 42 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    size: 12 + Math.random() * 10,
    vy: 0.8 + Math.random() * 1.2,
    sway: Math.random() * Math.PI * 2
  }));
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < hearts.length; i++) {
      const ht = hearts[i]; ht.sway += 0.03; ht.y -= ht.vy; ht.x += Math.sin(ht.sway) * 0.7;
      if (ht.y < -25) { ht.y = h + 25; ht.x = Math.random() * w; }
      ctx.fillStyle = i % 2 === 0 ? "rgba(251, 113, 133, 0.82)" : "rgba(244, 114, 182, 0.82)";
      ctx.font = `${Math.round(ht.size)}px sans-serif`; ctx.fillText("♥", ht.x, ht.y);
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}
function startConfetti() {
  const canvas = createOverlayCanvas("0.62");
  const ctx = canvas.getContext("2d");
  const cols = ["#facc15", "#38bdf8", "#f43f5e", "#4ade80", "#a855f7"];
  const pieces = Array.from({ length: 85 }, () => ({
    x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight,
    w: 7 + Math.random() * 5, h: 4 + Math.random() * 4,
    vy: 1.5 + Math.random() * 2.2, rot: Math.random() * Math.PI, col: cols[Math.floor(Math.random() * cols.length)]
  }));
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < pieces.length; i++) {
      const p = pieces[i]; p.y += p.vy; p.x += Math.sin(p.y * 0.03) * 1.1; p.rot += 0.06;
      if (p.y > h + 15) { p.y = -15; p.x = Math.random() * w; }
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
      ctx.fillStyle = p.col; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      ctx.restore();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}
function startDna() {
  const canvas = createOverlayCanvas("0.52");
  const ctx = canvas.getContext("2d");
  let phase = 0;
  function draw() {
    const w = canvas.width, h = canvas.height, cx = w * 0.5;
    ctx.clearRect(0, 0, w, h); phase += 0.035;
    for (let y = 20; y < h - 20; y += 22) {
      const a = y * 0.025 + phase;
      const x1 = cx + Math.sin(a) * 110;
      const x2 = cx + Math.sin(a + Math.PI) * 110;
      ctx.strokeStyle = "rgba(192, 132, 252, 0.35)"; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(x1, y); ctx.lineTo(x2, y); ctx.stroke();
      ctx.fillStyle = "#06b6d4"; ctx.beginPath(); ctx.arc(x1, y, 4.5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#c084fc"; ctx.beginPath(); ctx.arc(x2, y, 4.5, 0, Math.PI * 2); ctx.fill();
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}
function startHexgrid() { startParticles("#60a5fa", "59, 130, 246"); }
function startOcean() { startAurora("rgba(2, 132, 199, 0.25)", "rgba(56, 189, 248, 0.2)"); }
function startEqualizer() {
  const canvas = createOverlayCanvas("0.48");
  const ctx = canvas.getContext("2d");
  let t = 0;
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h); t += 0.08;
    const bars = 36, bw = w / bars;
    for (let i = 0; i < bars; i++) {
      const bh = 30 + Math.abs(Math.sin(t + i * 0.45) * Math.cos(t * 0.5 - i * 0.2)) * (h * 0.32);
      const grad = ctx.createLinearGradient(0, h - bh, 0, h);
      grad.addColorStop(0, "#fde047"); grad.addColorStop(1, "#10b981");
      ctx.fillStyle = grad;
      ctx.fillRect(i * bw + 3, h - bh, bw - 6, bh);
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}
function startMeteors() { startComet("192, 132, 252"); }
function startLeaves() {
  const canvas = createOverlayCanvas("0.65");
  const ctx = canvas.getContext("2d");
  const leafSprites = [
    getSakuraPetalSprite("#fef3c7", "#d97706", "rgba(120,53,15,0.4)"),
    getSakuraPetalSprite("#ffedd5", "#ea580c", "rgba(120,53,15,0.4)"),
    getSakuraPetalSprite("#fee2e2", "#b91c1c", "rgba(120,53,15,0.4)")
  ];
  const leaves = Array.from({ length: 55 }, () => ({
    x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight,
    size: 8 + Math.random() * 6, vy: 1 + Math.random() * 1.5, vx: 0.5 + Math.random(),
    rot: Math.random() * Math.PI * 2, flip: Math.random() * Math.PI * 2,
    sprite: leafSprites[Math.floor(Math.random() * leafSprites.length)]
  }));
  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < leaves.length; i++) {
      const l = leaves[i];
      applyCursorWind(l, 140, 1.3);
      l.vx *= 0.96; l.vy *= 0.96;
      l.y += l.vy + Math.sin(l.x * 0.02) * 0.4; l.x += l.vx + Math.sin(l.y * 0.02) * 1.1;
      l.rot += 0.03; l.flip += 0.035;
      if (l.y > h + 20) { l.y = -20; l.x = Math.random() * w; }
      if (l.x > w + 20) l.x = -20;
      drawBlittedPetal(ctx, l.sprite, l.x, l.y, l.size, l.rot, l.flip);
    }
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}
function startPrism() { startParticles("#f472b6", "244, 114, 182"); }
function startBlackhole() {
  const canvas = createOverlayCanvas("0.62");
  const ctx = canvas.getContext("2d");
  let a = 0;
  function draw() {
    const w = canvas.width, h = canvas.height, cx = w / 2, cy = h / 2;
    ctx.clearRect(0, 0, w, h); a += 0.02;
    // Accretion disk glow
    const glow = ctx.createRadialGradient(cx, cy, 35, cx, cy, 190);
    glow.addColorStop(0, "rgba(249, 115, 22, 0.7)");
    glow.addColorStop(0.5, "rgba(234, 88, 12, 0.25)");
    glow.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = glow;
    ctx.beginPath(); ctx.ellipse(cx, cy, 190, 65, -0.2, 0, Math.PI * 2); ctx.fill();
    // Event horizon black core
    ctx.fillStyle = "#000000";
    ctx.beginPath(); ctx.arc(cx, cy, 42, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "#fdba74"; ctx.lineWidth = 2; ctx.stroke();
    animFrameId = requestAnimationFrame(draw);
  }
  draw();
}
function startCybergrid() { startSynthwaveGrid(); }
function startPixelrain() { startMatrixRain("#4ade80", "rgba(3, 20, 7, 0.16)"); }
function startStarwarp() { startWarp(); }
function startToxic() { startFireflies("#a3e635", "rgba(163, 230, 53, 0.25)"); }
function startBloodmoon() { startComet("239, 68, 68"); }

const ANIMATION_RUNNERS = {
  deepspace: startDeepSpace,
  starfield: startStarfield,
  sakura: startSakura,
  sakuraglow: startSakuraglow,
  sakurastorm: startSakurastorm,
  sakuranight: startSakuranight,
  sakurafest: startSakurafest,
  sakuracircle: startSakuracircle,
  sakurapond: startSakurapond,
  sakurarain: startSakurarain,
  sakuragold: startSakuragold,
  matrix: startMatrixRain,
  synthwave: startSynthwaveGrid,
  cyberpunk: startCyberpunkRain,
  fireflies: startFireflies,
  particles: startParticles,
  portal: startPortal,
  aurora: startAurora,
  bubbles: startBubbles,
  laser: startLaser,
  snowfall: startSnowfall,
  plasma: startPlasma,
  comet: startComet,
  matrix3d: startMatrix3D,
  nebula: startNebula,
  electric: startElectric,
  neonrings: startNeonRings,
  fireworks: startFireworks,
  goldmatrix: startGoldMatrix,
  sonar: startSonar,
  warp: startWarp,
  solar: startSolar,
  biolum: startBiolum,
  quantum: startQuantum,
  hearts: startHearts,
  confetti: startConfetti,
  dna: startDna,
  hexgrid: startHexgrid,
  ocean: startOcean,
  equalizer: startEqualizer,
  meteors: startMeteors,
  leaves: startLeaves,
  prism: startPrism,
  blackhole: startBlackhole,
  cybergrid: startCybergrid,
  pixelrain: startPixelrain,
  starwarp: startStarwarp,
  toxic: startToxic,
  bloodmoon: startBloodmoon
};

function launchAnimation(animType) {
  const run = () => {
    const fn = ANIMATION_RUNNERS[animType];
    if (fn) fn(); else stopCanvasAnimation();
  };
  if (document.body) run(); else window.addEventListener("DOMContentLoaded", run, { once: true });
}

function applyTheme(themeId, enablePatterns = true) {
  let styleTag = document.getElementById("mikeybox-custom-theme-style");
  if (!themeId || !THEME_CONFIGS[themeId]) {
    if (styleTag) styleTag.remove();
    stopCanvasAnimation();
    return;
  }
  const t = THEME_CONFIGS[themeId];
  if (!styleTag) {
    styleTag = document.createElement("style");
    styleTag.id = "mikeybox-custom-theme-style";
    (document.head || document.documentElement).appendChild(styleTag);
  }
  const activePattern = enablePatterns ? t.pattern : "background-image: none !important;";
  styleTag.textContent = `
    :root {
      --mb-bg: ${t.bg};
      --mb-panel: ${t.panel};
      --mb-btn: ${t.button};
      --mb-btn-hover: ${t.buttonHover};
      --mb-border: ${t.border};
      --mb-text: ${t.text};
      --mb-muted: ${t.mutedText};
    }
    html, body, #root, #app, main, [class*="app"], [class*="layout"], [class*="wrapper"] {
      background-color: var(--mb-bg) !important;
      ${activePattern}
      color: var(--mb-text) !important;
    }
    nav, aside, header, footer, section, article, dialog, div,
    [role="menu"], [role="dialog"], [role="navigation"], [role="region"],
    [class*="panel"], [class*="Panel"], [class*="menu"], [class*="Menu"],
    [class*="sidebar"], [class*="Sidebar"], [class*="card"], [class*="Card"],
    [class*="modal"], [class*="Modal"], [class*="drawer"], [class*="Drawer"],
    [class*="dropdown"], [class*="Dropdown"], [class*="popover"], [class*="Popover"],
    [class*="toolbar"], [class*="Toolbar"], [class*="navbar"], [class*="Navbar"],
    [class*="container"], [class*="box"], [class*="Box"], [class*="workspace"], [class*="Workspace"] {
      background-color: var(--mb-panel) !important;
      border-color: var(--mb-border) !important;
      color: var(--mb-text) !important;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.16) !important;
    }
    button, [role="button"], input[type="button"], input[type="submit"], a[class*="btn"], [class*="button"], [class*="Button"] {
      background-color: var(--mb-btn) !important;
      border: 1px solid var(--mb-border) !important;
      color: var(--mb-text) !important;
      transition: background-color 0.15s ease, transform 0.1s ease !important;
    }
    button:hover, [role="button"]:hover, input[type="button"]:hover, input[type="submit"]:hover, a[class*="btn"]:hover {
      background-color: var(--mb-btn-hover) !important;
    }
    input:not([type="button"]):not([type="submit"]), textarea, select {
      background-color: var(--mb-panel) !important;
      border: 1px solid var(--mb-border) !important;
      color: var(--mb-text) !important;
    }
    input::placeholder, textarea::placeholder {
      color: var(--mb-muted) !important;
      opacity: 0.85 !important;
    }
    h1, h2, h3, h4, h5, h6, p, span, label, li, a {
      color: var(--mb-text) !important;
    }
  `;
  if (t.animType) launchAnimation(t.animType); else stopCanvasAnimation();
}

chrome.storage.sync.get(["mikeyboxTheme", "mikeyboxPatterns"], (result) => {
  if (result.mikeyboxTheme) applyTheme(result.mikeyboxTheme, result.mikeyboxPatterns !== false);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "sync" && (changes.mikeyboxTheme || changes.mikeyboxPatterns)) {
    chrome.storage.sync.get(["mikeyboxTheme", "mikeyboxPatterns"], (result) => {
      applyTheme(result.mikeyboxTheme, result.mikeyboxPatterns !== false);
    });
  }
});
