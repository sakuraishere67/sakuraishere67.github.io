const ANIMATED_THEMES = [
  { id: "deepspace", name: "Deep Space Cosmos", tag: "Spiral Galaxy, Planets & Nebula", swatch: "radial-gradient(circle at 30% 30%, #a855f7, #1e1b4b, #02040a)" },
  { id: "starfield", name: "Falling Stars", tag: "5-Point Twinkle Stars", swatch: "radial-gradient(circle, #fde047, #040712)" },
  { id: "sakura", name: "Sakura Petals", tag: "Drifting Cherry Blossoms", swatch: "linear-gradient(135deg, #f9a8d4, #f43f5e)" },
  { id: "sakuraglow", name: "Glow Sakura", tag: "Luminescent Blossoms", swatch: "linear-gradient(135deg, #ff77a9, #ffb6c1)" },
  { id: "sakurastorm", name: "Sakura Blizzard", tag: "Heavy Spring Storm", swatch: "linear-gradient(135deg, #ff69b4, #db7093)" },
  { id: "sakuranight", name: "Midnight Sakura", tag: "Yozakura Moonlit Tree", swatch: "linear-gradient(135deg, #2c163a, #ffb6c1)" },
  { id: "sakurafest", name: "Hanami Festival", tag: "Lanterns & Falling Petals", swatch: "linear-gradient(135deg, #ff4500, #ff69b4)" },
  { id: "sakuracircle", name: "Sakura Whirlpool", tag: "Vortex Blossom Orbit", swatch: "linear-gradient(135deg, #ba55d3, #ffb6c1)" },
  { id: "sakurapond", name: "Sakura Water Ripple", tag: "Petals on Shimmering Pond", swatch: "linear-gradient(135deg, #008080, #ffb6c1)" },
  { id: "sakurarain", name: "Spring Sakura Rain", tag: "Gentle Rain & Petals", swatch: "linear-gradient(135deg, #4682b4, #ffb6c1)" },
  { id: "sakuragold", name: "Golden Sakura", tag: "Imperial Golden Blossoms", swatch: "linear-gradient(135deg, #ffd700, #ff69b4)" },
  { id: "matrix", name: "Matrix Hacker", tag: "Interactive Code Rain", swatch: "#00ff41" },
  { id: "synthwave", name: "Synthwave Grid", tag: "Retro Neon Horizon", swatch: "linear-gradient(135deg, #ff2a85, #05d9e8)" },
  { id: "cyberpunk", name: "Cyberpunk Rain", tag: "Neon Drizzle & Ripples", swatch: "linear-gradient(135deg, #00f0ff, #fcee0a)" },
  { id: "fireflies", name: "Enchanted Fireflies", tag: "Cursor Glow Swarm", swatch: "linear-gradient(135deg, #facc15, #16a34a)" },
  { id: "particles", name: "Constellation Web", tag: "Mouse Node Connect", swatch: "linear-gradient(135deg, #38bdf8, #818cf8)" },
  { id: "portal", name: "Vortex Portal", tag: "Hypnotic Swirl", swatch: "linear-gradient(135deg, #a855f7, #ec4899)" },
  { id: "aurora", name: "Aurora Borealis", tag: "Northern Wave Lights", swatch: "linear-gradient(135deg, #10b981, #06b6d4)" },
  { id: "bubbles", name: "Floating Bubbles", tag: "Click to Pop", swatch: "linear-gradient(135deg, #3b82f6, #6ee7b7)" },
  { id: "laser", name: "Laser Tracking", tag: "Cursor Beam Grid", swatch: "linear-gradient(135deg, #ef4444, #f59e0b)" },
  { id: "snowfall", name: "Blizzard Snow", tag: "Wind Repel Physics", swatch: "linear-gradient(135deg, #e2e8f0, #94a3b8)" },
  { id: "plasma", name: "Plasma Orbs", tag: "Pulsing Energy Rings", swatch: "linear-gradient(135deg, #d946ef, #8b5cf6)" },
  { id: "comet", name: "Comet Shower", tag: "Blazing Meteor Trails", swatch: "linear-gradient(135deg, #fdba74, #f43f5e)" },
  { id: "matrix3d", name: "3D Binary Orbit", tag: "Rotating Matrix Ring", swatch: "linear-gradient(135deg, #00ff41, #032b0c)" },
  { id: "nebula", name: "Cosmic Nebula", tag: "Deep Space Gas Clouds", swatch: "linear-gradient(135deg, #6366f1, #ec4899)" },
  { id: "electric", name: "Electric Storm", tag: "Jagged Lightning Bolts", swatch: "linear-gradient(135deg, #38bdf8, #fef08a)" },
  { id: "neonrings", name: "Neon Pulse Rings", tag: "Expanding Shockwaves", swatch: "linear-gradient(135deg, #06b6d4, #3b82f6)" },
  { id: "fireworks", name: "Neon Fireworks", tag: "Click Burst Sparks", swatch: "linear-gradient(135deg, #f43f5e, #a855f7)" },
  { id: "goldmatrix", name: "Golden Matrix", tag: "Ancient Gold Code", swatch: "linear-gradient(135deg, #eab308, #78350f)" },
  { id: "sonar", name: "Sonar Radar", tag: "Tactical Sweep Beam", swatch: "linear-gradient(135deg, #10b981, #042f1c)" },
  { id: "warp", name: "Hyperwarp Tunnel", tag: "3D Speed Squares", swatch: "linear-gradient(135deg, #22c55e, #022c14)" },
  { id: "solar", name: "Solar Embers", tag: "Rising Lava Sparks", swatch: "linear-gradient(135deg, #ea580c, #dc2626)" },
  { id: "biolum", name: "Bio-Luminescent", tag: "Deep Sea Jelly Orbs", swatch: "linear-gradient(135deg, #14b8a6, #0f766e)" },
  { id: "quantum", name: "Quantum Lattice", tag: "Subatomic Nodes", swatch: "linear-gradient(135deg, #8b5cf6, #3b82f6)" },
  { id: "hearts", name: "Floating Hearts", tag: "Neon Love Sparks", swatch: "linear-gradient(135deg, #ec4899, #fb7185)" },
  { id: "confetti", name: "Party Confetti", tag: "Tumbling Color Ribbons", swatch: "linear-gradient(135deg, #facc15, #38bdf8)" },
  { id: "dna", name: "DNA Double Helix", tag: "Rotating Bio Strand", swatch: "linear-gradient(135deg, #06b6d4, #a855f7)" },
  { id: "hexgrid", name: "Cyber Hex Grid", tag: "Glowing Honeycomb", swatch: "linear-gradient(135deg, #3b82f6, #1d4ed8)" },
  { id: "ocean", name: "Ocean Waves", tag: "Layered Tide Motion", swatch: "linear-gradient(135deg, #0284c7, #38bdf8)" },
  { id: "equalizer", name: "Audio Equalizer", tag: "Rhythm Spectrum Bars", swatch: "linear-gradient(135deg, #10b981, #facc15)" },
  { id: "meteors", name: "Purple Meteors", tag: "Galactic Streaks", swatch: "linear-gradient(135deg, #9333ea, #c084fc)" },
  { id: "leaves", name: "Autumn Leaves", tag: "Swirling Fall Foliage", swatch: "linear-gradient(135deg, #d97706, #b45309)" },
  { id: "prism", name: "Prism Triangles", tag: "Floating Geo Shards", swatch: "linear-gradient(135deg, #f472b6, #818cf8)" },
  { id: "blackhole", name: "Event Horizon", tag: "Orbiting Accretion Disk", swatch: "linear-gradient(135deg, #f97316, #09090b)" },
  { id: "cybergrid", name: "3D Cyber Floor", tag: "Moving Tron Grid", swatch: "linear-gradient(135deg, #00f0ff, #031014)" },
  { id: "pixelrain", name: "8-Bit Pixel Rain", tag: "Retro Arcade Blocks", swatch: "linear-gradient(135deg, #4ade80, #16a34a)" },
  { id: "starwarp", name: "Hyperspace Jump", tag: "Radial Star Streaks", swatch: "linear-gradient(135deg, #ffffff, #1e3a8a)" },
  { id: "toxic", name: "Toxic Spores", tag: "Radioactive Mist", swatch: "linear-gradient(135deg, #a3e635, #14532d)" },
  { id: "bloodmoon", name: "Crimson Eclipse", tag: "Red Ash & Ember", swatch: "linear-gradient(135deg, #ef4444, #450a0a)" }
];

const THEMES = [
  { id: "blue", name: "Cobalt Blue", tag: "Blueprint Grid", swatch: "linear-gradient(135deg, #2563eb, #60a5fa)" },
  { id: "red", name: "Crimson Red", tag: "Diagonal Stripes", swatch: "linear-gradient(135deg, #dc2626, #f87171)" },
  { id: "purple", name: "Royal Purple", tag: "Polka Dots", swatch: "linear-gradient(135deg, #7c3aed, #a78bfa)" },
  { id: "green", name: "Forest Green", tag: "Circuit Grid", swatch: "linear-gradient(135deg, #16a34a, #4ade80)" },
  { id: "orange", name: "Tangerine", tag: "Chevron Zigzag", swatch: "linear-gradient(135deg, #ea580c, #fb923c)" },
  { id: "pink", name: "Hot Pink", tag: "Checkerboard", swatch: "linear-gradient(135deg, #db2777, #f472b6)" },
  { id: "yellow", name: "Solar Yellow", tag: "Honeycomb Dots", swatch: "linear-gradient(135deg, #eab308, #fde047)" },
  { id: "teal", name: "Ocean Teal", tag: "Wave Ripples", swatch: "linear-gradient(135deg, #0d9488, #2dd4bf)" },
  { id: "cyan", name: "Electric Cyan", tag: "Tech Scanlines", swatch: "linear-gradient(135deg, #0891b2, #22d3ee)" },
  { id: "indigo", name: "Deep Indigo", tag: "Starlight Dots", swatch: "linear-gradient(135deg, #4f46e5, #818cf8)" },
  { id: "brown", name: "Espresso Brown", tag: "Crosshatch Weave", swatch: "linear-gradient(135deg, #78350f, #b45309)" },
  { id: "gray", name: "Titanium Gray", tag: "Carbon Fiber", swatch: "linear-gradient(135deg, #4b5563, #9ca3af)" },
  { id: "black", name: "Obsidian Black", tag: "Stealth Diamond", swatch: "linear-gradient(135deg, #09090b, #27272a)" },
  { id: "rose", name: "Velvet Rose", tag: "Soft Polka Dots", swatch: "linear-gradient(135deg, #f43f5e, #fda4af)" },
  { id: "emerald", name: "Emerald Gem", tag: "Diamond Mesh", swatch: "linear-gradient(135deg, #059669, #34d399)" },
  { id: "amber", name: "Warm Amber", tag: "Sunburst Stripes", swatch: "linear-gradient(135deg, #d97706, #fbbf24)" },
  { id: "violet", name: "Neon Violet", tag: "Cosmic Grid", swatch: "linear-gradient(135deg, #8b5cf6, #c4b5fd)" },
  { id: "lime", name: "Electric Lime", tag: "Retro Arcade", swatch: "linear-gradient(135deg, #65a30d, #a3e635)" },
  { id: "sky", name: "Sky Azure", tag: "Cloud Polka", swatch: "linear-gradient(135deg, #0284c7, #38bdf8)" },
  { id: "fuchsia", name: "Cyber Fuchsia", tag: "Neon Grid", swatch: "linear-gradient(135deg, #c026d3, #e879f9)" },
  { id: "slate", name: "Tactical Slate", tag: "Carbon Mesh", swatch: "linear-gradient(135deg, #475569, #94a3b8)" },
  { id: "crimson", name: "Samurai Red", tag: "Slash Stripes", swatch: "linear-gradient(135deg, #991b1b, #ef4444)" },
  { id: "mint", name: "Glacier Mint", tag: "Fresh Dots", swatch: "linear-gradient(135deg, #10b981, #6ee7b7)" },
  { id: "coral", name: "Sunset Coral", tag: "Horizon Stripes", swatch: "linear-gradient(135deg, #f97316, #fda4af)" },
  { id: "lavender", name: "Soft Lavender", tag: "Pastel Dots", swatch: "linear-gradient(135deg, #9333ea, #d8b4fe)" },
  { id: "gold", name: "Royal Gold", tag: "Art Deco Zigzag", swatch: "linear-gradient(135deg, #b45309, #fcd34d)" },
  { id: "midnight", name: "Midnight Navy", tag: "Deep Space Grid", swatch: "linear-gradient(135deg, #1e1b4b, #4338ca)" },
  { id: "turquoise", name: "Lagoon", tag: "Oceanic Rings", swatch: "linear-gradient(135deg, #0f766e, #5eead4)" },
  { id: "magenta", name: "Hyper Magenta", tag: "Synth Scanlines", swatch: "linear-gradient(135deg, #a21caf, #f0abfc)" },
  { id: "cherry", name: "Cherry Blossom", tag: "Sakura Polka", swatch: "linear-gradient(135deg, #ec4899, #fbcfe8)" },
  { id: "sapphire", name: "Sapphire", tag: "Crystal Grid", swatch: "linear-gradient(135deg, #1e40af, #3b82f6)" },
  { id: "ruby", name: "Ruby Gem", tag: "Facet Weave", swatch: "linear-gradient(135deg, #9f1239, #f43f5e)" },
  { id: "jade", name: "Imperial Jade", tag: "Temple Waves", swatch: "linear-gradient(135deg, #065f46, #10b981)" },
  { id: "peach", name: "Peach Nectar", tag: "Warm Dots", swatch: "linear-gradient(135deg, #fb923c, #fed7aa)" },
  { id: "plum", name: "Dark Plum", tag: "Velvet Mesh", swatch: "linear-gradient(135deg, #581c87, #9333ea)" },
  { id: "charcoal", name: "Stealth Carbon", tag: "Dark Hex", swatch: "linear-gradient(135deg, #18181b, #3f3f46)" },
  { id: "bronze", name: "Ancient Bronze", tag: "Metallic Stripes", swatch: "linear-gradient(135deg, #713f12, #ca8a04)" },
  { id: "arctic", name: "Arctic Ice", tag: "Frost Grid", swatch: "linear-gradient(135deg, #0369a1, #7dd3fc)" },
  { id: "orchid", name: "Wild Orchid", tag: "Floral Polka", swatch: "linear-gradient(135deg, #a21caf, #f0abfc)" },
  { id: "mustard", name: "Spiced Mustard", tag: "Retro Checker", swatch: "linear-gradient(135deg, #a16207, #facc15)" },
  { id: "olive", name: "Tactical Olive", tag: "Camo Weave", swatch: "linear-gradient(135deg, #3f6212, #84cc16)" },
  { id: "maroon", name: "Deep Maroon", tag: "Royal Stripes", swatch: "linear-gradient(135deg, #7f1d1d, #b91c1c)" },
  { id: "aqua", name: "Tropical Aqua", tag: "Surf Waves", swatch: "linear-gradient(135deg, #0891b2, #67e8f9)" },
  { id: "periwinkle", name: "Periwinkle", tag: "Dreamy Dots", swatch: "linear-gradient(135deg, #4338ca, #a5b4fc)" },
  { id: "copper", name: "Burnished Copper", tag: "Circuit Lines", swatch: "linear-gradient(135deg, #9a3412, #ea580c)" },
  { id: "steel", name: "Brushed Steel", tag: "Industrial Grid", swatch: "linear-gradient(135deg, #334155, #64748b)" },
  { id: "bubblegum", name: "Bubblegum", tag: "Pop Polka", swatch: "linear-gradient(135deg, #db2777, #f9a8d4)" },
  { id: "lemon", name: "Zesty Lemon", tag: "Citrus Stripes", swatch: "linear-gradient(135deg, #ca8a04, #fef08a)" },
  { id: "seafoam", name: "Seafoam", tag: "Tide Ripples", swatch: "linear-gradient(135deg, #0f766e, #99f6e4)" },
  { id: "grape", name: "Concord Grape", tag: "Vine Dots", swatch: "linear-gradient(135deg, #6b21a8, #c084fc)" },
  { id: "rust", name: "Canyon Rust", tag: "Desert Zigzag", swatch: "linear-gradient(135deg, #7c2d12, #c2410c)" },
  { id: "ash", name: "Volcanic Ash", tag: "Smoke Weave", swatch: "linear-gradient(135deg, #27272a, #71717a)" },
  { id: "watermelon", name: "Watermelon", tag: "Summer Checker", swatch: "linear-gradient(135deg, #e11d48, #4ade80)" },
  { id: "cobalt", name: "Electric Cobalt", tag: "Laser Scan", swatch: "linear-gradient(135deg, #1d4ed8, #38bdf8)" },
  { id: "moss", name: "Woodland Moss", tag: "Forest Dots", swatch: "linear-gradient(135deg, #14532d, #22c55e)" },
  { id: "apricot", name: "Sweet Apricot", tag: "Soft Stripes", swatch: "linear-gradient(135deg, #ea580c, #fdba74)" },
  { id: "lilac", name: "Pastel Lilac", tag: "Cloud Grid", swatch: "linear-gradient(135deg, #7e22ce, #e9d5ff)" },
  { id: "onyx", name: "Pitch Onyx", tag: "Stealth Scan", swatch: "linear-gradient(135deg, #000000, #18181b)" },
  { id: "cerulean", name: "Cerulean Sky", tag: "Horizon Waves", swatch: "linear-gradient(135deg, #0284c7, #7dd3fc)" },
  { id: "scarlet", name: "Blazing Scarlet", tag: "Flame Zigzag", swatch: "linear-gradient(135deg, #b91c1c, #f87171)" }
];

let currentFilter = "all";
let searchQuery = "";
let activeThemeId = null;

const animatedGrid = document.getElementById("animated-grid");
const themeGrid = document.getElementById("theme-grid");
const animatedSection = document.getElementById("animated-section");
const regularSection = document.getElementById("regular-section");
const emptyState = document.getElementById("empty-state");
const animCount = document.getElementById("anim-count");
const regCount = document.getElementById("reg-count");
const activeThemeName = document.getElementById("active-theme-name");
const searchInput = document.getElementById("search-input");
const clearSearchBtn = document.getElementById("clear-search");
const patternToggle = document.getElementById("pattern-toggle");
const resetBtn = document.getElementById("reset-btn");

function updateActiveBanner(id) {
  if (!id) {
    activeThemeName.textContent = "Default Mikeybox";
    return;
  }
  const found = ANIMATED_THEMES.find(t => t.id === id) || THEMES.find(t => t.id === id);
  activeThemeName.textContent = found ? found.name : "Custom Theme";
}

function createThemeButton(theme) {
  const isSelected = activeThemeId === theme.id;
  const btn = document.createElement("button");
  btn.className = `theme-btn ${isSelected ? "active" : ""}`.trim();

  const swatch = document.createElement("span");
  swatch.className = "swatch";
  swatch.style.background = theme.swatch;

  const info = document.createElement("div");
  info.className = "theme-info";

  const label = document.createElement("span");
  label.className = "theme-name";
  label.textContent = theme.name;

  const tag = document.createElement("span");
  tag.className = "theme-tag";
  tag.textContent = theme.tag;

  info.appendChild(label);
  info.appendChild(tag);

  const check = document.createElement("span");
  check.className = "check-badge";
  check.textContent = "✓";

  btn.appendChild(swatch);
  btn.appendChild(info);
  btn.appendChild(check);

  btn.addEventListener("click", () => {
    activeThemeId = theme.id;
    chrome.storage.sync.set({ mikeyboxTheme: theme.id }, () => {
      updateActiveBanner(theme.id);
      render();
    });
  });

  return btn;
}

function render() {
  const q = searchQuery.trim().toLowerCase();

  const filteredAnim = ANIMATED_THEMES.filter(t =>
    t.name.toLowerCase().includes(q) || t.tag.toLowerCase().includes(q)
  );
  const filteredReg = THEMES.filter(t =>
    t.name.toLowerCase().includes(q) || t.tag.toLowerCase().includes(q)
  );

  animatedGrid.innerHTML = "";
  themeGrid.innerHTML = "";

  const showAnim = (currentFilter === "all" || currentFilter === "animated") && filteredAnim.length > 0;
  const showReg = (currentFilter === "all" || currentFilter === "regular") && filteredReg.length > 0;

  animatedSection.classList.toggle("hidden", !showAnim);
  regularSection.classList.toggle("hidden", !showReg);

  if (showAnim) {
    animCount.textContent = filteredAnim.length;
    filteredAnim.forEach(t => animatedGrid.appendChild(createThemeButton(t)));
  }

  if (showReg) {
    regCount.textContent = filteredReg.length;
    filteredReg.forEach(t => themeGrid.appendChild(createThemeButton(t)));
  }

  emptyState.classList.toggle("hidden", showAnim || showReg);
}

searchInput.addEventListener("input", (e) => {
  searchQuery = e.target.value;
  clearSearchBtn.classList.toggle("visible", searchQuery.length > 0);
  render();
});

clearSearchBtn.addEventListener("click", () => {
  searchQuery = "";
  searchInput.value = "";
  clearSearchBtn.classList.remove("visible");
  searchInput.focus();
  render();
});

document.querySelectorAll(".filter-tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".filter-tab").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    currentFilter = tab.dataset.filter;
    render();
  });
});

patternToggle.addEventListener("change", () => {
  chrome.storage.sync.set({ mikeyboxPatterns: patternToggle.checked });
});

resetBtn.addEventListener("click", () => {
  activeThemeId = null;
  chrome.storage.sync.remove("mikeyboxTheme", () => {
    updateActiveBanner(null);
    render();
  });
});

chrome.storage.sync.get(["mikeyboxTheme", "mikeyboxPatterns"], (result) => {
  patternToggle.checked = result.mikeyboxPatterns !== false;
  activeThemeId = result.mikeyboxTheme || null;
  updateActiveBanner(activeThemeId);
  render();
});
