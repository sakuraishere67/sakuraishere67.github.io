# Mikeybox Themes Studio v8.0

## What's New in v8.0
- **Expanded Sakura Collection**: Added 9 brand new animated Sakura varieties (10 total Sakura themes).
- **Total Animated Themes**: Now 50 unique interactive animated backgrounds.
