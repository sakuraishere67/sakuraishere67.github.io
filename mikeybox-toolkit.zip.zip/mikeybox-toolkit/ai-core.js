/* Mikeybox Toolkit — AI core.
   Pure helpers shared by the service worker, the in-page AI Studio and Node tests.
   No chrome.* or DOM access here. */
(function (root) {
  'use strict';

  const DEFAULT_AI_SETTINGS = {
    chatModel: 'auto',
    imageModel: 'black-forest-labs/flux-3-image-klein',
    editModel: 'black-forest-labs/flux.1-kontext-dev',
    model3d: 'microsoft/trellis',
    chatBase: 'https://integrate.api.nvidia.com/v1',
    imageBase: 'https://ai.api.nvidia.com/v1/genai',
    autoArrange: true,
    lastScanAt: 0,
    scannedModels: [],
  };

  const AUTO_MODEL = 'auto';

  const KNOWN_MODELS = [
    { id: 'deepseek-ai/deepseek-v4-pro', context_window: 1048576, supports_structured_output: true, model_type: 'llm' },
    { id: 'nvidia/nemotron-3-ultra-550b-a55b', context_window: 1048576, supports_structured_output: true, model_type: 'llm' },
    { id: 'qwen/qwen3-next-80b-a3b-instruct', context_window: 262144, supports_structured_output: true, model_type: 'llm' },
    { id: 'moonshotai/kimi-k3.1-pro', context_window: 1048576, supports_structured_output: true, model_type: 'vlm' },
    { id: 'meta/llama-3.1-70b-instruct', context_window: 131072, supports_structured_output: true, model_type: 'llm' },
    { id: 'nvidia/llama-3.3-nemotron-super-49b-v1.5', context_window: 131072, model_type: 'llm' },
    { id: 'openai/gpt-oss-120b', context_window: 131072, model_type: 'llm' },
  ];

  const MODEL_PRIORITY = [
    ['deepseek-v4-pro', 100],
    ['nemotron-3-ultra', 96],
    ['nemotron-3.5-super', 92],
    ['kimi-k3', 90],
    ['qwen3-next', 86],
    ['llama-3.1-70b', 80],
    ['llama-3.3-70b', 76],
    ['glm-5.3', 74],
    ['gpt-oss-120b', 72],
    ['mistral-large', 68],
    ['gemma-4-31b', 62],
    ['deepseek-v4-flash', 58],
    ['nemotron-3.5-lightning', 54],
    ['nemotron-3.5-bolt', 50],
  ];

  const EXCLUDE_MODEL = /(embed|rerank|guard|safety|moderation|vision-encoder|cosmos|diffusion|image|video|audio|weather|climate|biology|protein|molecular|fold|docking|rfdiffusion)/i;

  function rankModels(models) {
    const list = Array.isArray(models) && models.length ? models : KNOWN_MODELS;
    const seen = new Set();
    const ranked = [];
    for (const raw of list) {
      const id = String((raw && raw.id) || '').trim();
      if (!id || seen.has(id) || EXCLUDE_MODEL.test(id)) continue;
      seen.add(id);
      const type = String(raw.model_type || '').toLowerCase();
      if (type && !/llm|vlm|chat|text|language/.test(type)) continue;

      let score = 40;
      for (const [needle, value] of MODEL_PRIORITY) {
        if (id.toLowerCase().includes(needle)) {
          score = value;
          break;
        }
      }
      if (raw.supports_structured_output) score += 12;
      if (raw.supports_tools) score += 3;
      if (type === 'vlm') score += 8;
      const context = Number(raw.context_window) || 0;
      if (context) score += Math.min(10, Math.log10(context) * 1.4);
      if (/flash|mini|tiny|e4b|bolt/.test(id.toLowerCase())) score -= 8;

      ranked.push({
        id: id,
        score: Math.round(score),
        context: context || null,
        structured: Boolean(raw.supports_structured_output),
        vision: type === 'vlm',
        type: type || 'unknown',
      });
    }
    ranked.sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
    return ranked;
  }

  function pickBestModel(models) {
    const ranked = rankModels(models);
    return ranked.length ? ranked[0].id : '';
  }

  const IMAGE_MODELS = [
    { id: 'black-forest-labs/flux-3-image-klein', label: 'FLUX 3 Image Klein (recommended)' },
    { id: 'black-forest-labs/flux.1-schnell', label: 'FLUX.1 schnell (fast)' },
    { id: 'stabilityai/stable-diffusion-3.5-large', label: 'Stable Diffusion 3.5 Large' },
  ];

  const IMAGE_SIZES = [
    { label: 'Square 1024', width: 1024, height: 1024 },
    { label: 'Landscape 1344×768', width: 1344, height: 768 },
    { label: 'Portrait 768×1344', width: 768, height: 1344 },
  ];

  const NODE_TEMPLATE = {
    itemID: 'item_backpack',
    jsonData: '',
    stashPos: 0,
    children: [],
    stuckChildren: [],
    grabPos: [0, 0, 0],
    grabRot: [0, 0, 0, 1],
    state: 0,
    ammo: 0,
    isBlueprint: true,
    scaleModifier: 0,
    colorHue: 0,
    colorSaturation: 0,
    jellyStrength: 0,
    stashRow: 0,
    stashCol: 0,
  };

  function clampNumber(value, min, max, fallback) {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(max, Math.max(min, n));
  }

  function vec3(value, fallback) {
    if (!Array.isArray(value) || value.length < 3) return fallback.slice();
    return [
      clampNumber(value[0], -4, 4, fallback[0]),
      clampNumber(value[1], -4, 4, fallback[1]),
      clampNumber(value[2], -4, 4, fallback[2]),
    ];
  }

  function quat(value) {
    if (!Array.isArray(value) || value.length < 4) return [0, 0, 0, 1];
    const q = value.slice(0, 4).map((n) => (Number.isFinite(Number(n)) ? Number(n) : 0));
    const length = Math.hypot(q[0], q[1], q[2], q[3]);
    if (!length || !Number.isFinite(length)) return [0, 0, 0, 1];
    /* + 0 turns -0 into 0 so a mirrored quaternion never ships as "-0". */
    return q.map((n) => Math.round((n / length) * 100000) / 100000 + 0);
  }

  /* ---- Orientation -----------------------------------------------------
     rot is a quaternion [x,y,z,w]. A build only ever needs quarter turns, so
     the whole vocabulary is the twelve entries below; normalizeInvention()
     snaps every rot to that grid (and to its 24-element cube rotation group),
     because half-degree tilts are what make a build look melted. */
  const ROT = {
    identity: [0, 0, 0, 1],
    x90: [0.707107, 0, 0, 0.707107],
    x180: [1, 0, 0, 0],
    x270: [-0.707107, 0, 0, 0.707107],
    y90: [0, 0.707107, 0, 0.707107],
    y180: [0, 1, 0, 0],
    y270: [0, -0.707107, 0, 0.707107],
    z90: [0, 0, 0.707107, 0.707107],
    z180: [0, 0, 1, 0],
    z270: [0, 0, -0.707107, 0.707107],
  };

  function qMul(a, b) {
    return [
      a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
      a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
      a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
      a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2],
    ];
  }

  /* The only component sizes a quarter-turn quaternion can have. Snapping and
     mirroring run through this so an entry never carries float drift like
     0.7071074376 instead of 0.707107. */
  const QUAT_PARTS = [0, 0.5, 0.707107, 1];

  function tidyQuat(q) {
    return q.map((n) => {
      const abs = Math.abs(n);
      let best = 0;
      let diff = abs;
      for (const part of QUAT_PARTS) {
        const gap = Math.abs(abs - part);
        if (gap < diff) {
          diff = gap;
          best = part;
        }
      }
      return n < 0 && best !== 0 ? -best : best;
    });
  }

  /* q and -q describe the same rotation. Keep the w >= 0 form so snapping and
     mirroring always emit one canonical quaternion. */
  function canonicalQuat(q) {
    const out = q.slice(0, 4);
    const needFlip = out[3] < 0 || (out[3] === 0 && (
      out[0] < 0 || (out[0] === 0 && (out[1] < 0 || (out[1] === 0 && out[2] < 0)))
    ));
    if (needFlip) {
      for (let i = 0; i < 4; i += 1) out[i] = out[i] === 0 ? 0 : -out[i];
    }
    return tidyQuat(out);
  }

  function qKey(q) {
    return canonicalQuat(q.map((n) => Math.round(n * 1000) / 1000 + 0)).join(',');
  }

  /* Every rotation that maps the cube onto itself: 24 of them. */
  const AXIS_ROTS = (() => {
    const out = [];
    const seen = new Set();
    const queue = [ROT.identity];
    const turns = [ROT.x90, ROT.y90, ROT.z90];
    while (queue.length && out.length < 24) {
      const q = queue.shift();
      const key = qKey(q);
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(canonicalQuat(q));
      for (const turn of turns) queue.push(qMul(turn, q));
    }
    return out;
  })();

  function isAxisAligned(value, tolerance) {
    const q = quat(value);
    const limit = tolerance == null ? 0.98 : tolerance;
    return AXIS_ROTS.some((candidate) => Math.abs(
      q[0] * candidate[0] + q[1] * candidate[1] + q[2] * candidate[2] + q[3] * candidate[3]
    ) >= limit);
  }

  function snapRotation(value, tolerance) {
    const q = quat(value);
    let best = q;
    let bestDot = -1;
    for (const candidate of AXIS_ROTS) {
      const dot = Math.abs(q[0] * candidate[0] + q[1] * candidate[1] + q[2] * candidate[2] + q[3] * candidate[3]);
      if (dot > bestDot) {
        bestDot = dot;
        best = candidate;
      }
    }
    const limit = tolerance == null ? 0.98 : tolerance;
    return bestDot >= limit ? canonicalQuat(best) : q;
  }

  /* Mirroring a rotation across x: negate the y and z parts, keep x and w. */
  function mirrorRotation(value) {
    const q = quat(value);
    return canonicalQuat([q[0], -q[1], -q[2], q[3]]);
  }

  function defaultNode(itemID) {
    return {
      itemID: itemID,
      jsonData: '',
      stashPos: 0,
      children: [],
      stuckChildren: [],
      grabPos: [0, 0, 0],
      grabRot: [0, 0, 0, 1],
      state: 0,
      ammo: 0,
      isBlueprint: true,
      scaleModifier: 0,
      colorHue: 0,
      colorSaturation: 0,
      jellyStrength: 0,
      stashRow: 0,
      stashCol: 0,
    };
  }

  function normalizeInvention(raw, options) {
    const opts = options || {};
    const maxParts = Math.round(clampNumber(opts.maxParts, 1, 200, 40));
    const known = opts.knownIds instanceof Set ? opts.knownIds : null;
    const banned = opts.bannedIds instanceof Set ? opts.bannedIds : new Set();
    const warnings = [];
    const fallbackRoot = opts.fallbackRootId || (known && known.size ? Array.from(known)[0] : 'item_backpack');

    let payload = raw;
    if (payload && typeof payload === 'object') {
      if (payload.root && typeof payload.root === 'object') payload = payload.root;
      else if (payload.invention && typeof payload.invention === 'object') payload = payload.invention;
      else if (payload.build && typeof payload.build === 'object') payload = payload.build;
    }

    const isUsable = (id) => typeof id === 'string' && id.startsWith('item_') && (!known || known.has(id)) && !banned.has(id);

    let rootId = payload && typeof payload === 'object' ? String(payload.itemID || '') : '';
    if (!isUsable(rootId)) {
      warnings.push('The model did not return a usable root item; using ' + fallbackRoot + '.');
      rootId = isUsable(fallbackRoot) ? fallbackRoot : (known ? Array.from(known).find((id) => isUsable(id)) : 'item_backpack');
    }
    if (!rootId) throw new Error('No usable root item was generated.');

    /* A wearable build rooted on a beam is a statue standing beside the player.
       Swap in the pack the game snaps to the back; children keep their layout. */
    const forcedRoot = typeof opts.rootId === 'string' && isUsable(opts.rootId) ? opts.rootId : '';
    if (forcedRoot && !/^item_backpack/.test(rootId)) {
      warnings.push('Rooted the build on ' + forcedRoot + ' so the player can wear it.');
      rootId = forcedRoot;
    }

    let count = 0;
    const nextPositions = [];
    let ringSeed = 0;

    function build(id, depth) {
      const node = defaultNode(id);
      if (depth === 0) {
        /* A worn build sits on the pack itself; an offset would leave it
           floating in front of or above the player. */
        if (opts.wearable) {
          node.grabPos = [0, 0, 0];
          node.grabRot = [0, 0, 0, 1];
        } else {
          node.grabPos = vec3(payload && payload.grabPos, [0, 0, 0]);
          node.grabRot = snapRotation(payload && payload.grabRot);
        }
        node.scaleModifier = clampNumber(payload && payload.scaleModifier, -2, 4, 0);
      }
      count += 1;
      return node;
    }

    function takeChildren(source, depth, parentId) {
      const entries = Array.isArray(source && source.stuckChildren) ? source.stuckChildren : [];
      const out = [];
      for (const entry of entries) {
        if (count >= maxParts) {
          warnings.push('Trimmed the build at ' + maxParts + ' parts.');
          break;
        }
        const item = entry && typeof entry === 'object' ? (entry.item && typeof entry.item === 'object' ? entry.item : entry) : null;
        const id = item ? String(item.itemID || '') : '';
        if (!id) continue;
        if (!isUsable(id)) {
          if (banned.has(id)) warnings.push('Removed banned item ' + id + '.');
          else if (known && !known.has(id)) warnings.push('Removed unknown item ' + id + '.');
          continue;
        }
        const node = build(id, depth + 1);
        if (item && item.scaleModifier !== undefined) {
          node.scaleModifier = clampNumber(item.scaleModifier, -2, 4, 0);
        }
        let pos = entry && entry.pos;
        const missing = !Array.isArray(pos) || pos.every((n) => !Number(n));
        if (opts.autoArrange && missing) {
          const angle = ringSeed * 2.399;
          const radius = 0.13 + (ringSeed % 4) * 0.05;
          pos = [Math.cos(angle) * radius, 0.06 + (ringSeed % 5) * 0.07, Math.sin(angle) * radius];
          ringSeed += 1;
        }
        const parentNode = { item: node, subParentID: 0, pos: vec3(pos, [0, 0, 0]), rot: snapRotation(entry && entry.rot), posePos: [0, 0, 0], poseRot: [0, 0, 0, 1], wasDynamicStuck: false };
        node.stuckChildren = takeChildren(item, depth + 1, id);
        if (!node.stuckChildren.length) delete node.stuckChildren;
        out.push(parentNode);
      }
      return out;
    }

    const root = build(rootId, 0);
    root.stuckChildren = takeChildren(payload, 0, rootId);
    if (!root.stuckChildren.length) delete root.stuckChildren;

    const name = String((raw && (raw.name || raw.title)) || opts.fallbackName || 'AI invention').trim().slice(0, 60);
    const summary = String((raw && (raw.summary || raw.description)) || '').trim().slice(0, 600);
    if (warnings.length > 8) warnings.length = 8;
    return {
      name: name || 'AI invention',
      summary: summary,
      root: root,
      warnings: Array.from(new Set(warnings)),
      stats: { nodes: count, stuckLinks: count - 1 },
    };
  }

  function extractJson(text) {
    if (typeof text !== 'string') return null;
    let cleaned = text.trim();
    if (!cleaned) return null;
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '').trim();
    try {
      return JSON.parse(cleaned);
    } catch (err) {
      /* keep trying */
    }
    const first = cleaned.indexOf('{');
    const last = cleaned.lastIndexOf('}');
    if (first >= 0 && last > first) {
      try {
        return JSON.parse(cleaned.slice(first, last + 1));
      } catch (err) {
        /* fall through */
      }
    }
    return null;
  }

  /* ---- Prime localStorage helpers (pure) ------------------------------
     These read the editor's own keys; the toolkit never reads token or
     cookie values. */
  const TEXT_LIMIT = 200;

  function cleanText(value) {
    if (typeof value !== 'string') return '';
    const text = value.normalize ? value.normalize('NFKC') : value;
    return text.trim().replace(/\s+/g, ' ').slice(0, TEXT_LIMIT);
  }

  /* mikeybox_recent_player_names is a JSON array of names, newest first. */
  function playerNamesFrom(raw) {
    let list = raw;
    if (typeof raw === 'string') {
      try {
        list = JSON.parse(raw);
      } catch (err) {
        return [];
      }
    }
    if (!Array.isArray(list)) return [];
    const seen = new Set();
    const names = [];
    for (const entry of list) {
      const name = cleanText(typeof entry === 'string' ? entry : entry && entry.name);
      if (!name || name.length > 32) continue;
      const key = name.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      names.push(name);
      if (names.length === 8) break;
    }
    return names;
  }

  function latestPlayerName(raw) {
    const names = playerNamesFrom(raw);
    return names.length ? names[0] : '';
  }

  /* One plain-object summary for the profile card and the copy button. */
  function dossierFrom(values) {
    const v = values || {};
    const names = playerNamesFrom(v.recentPlayerNames);
    const site = v.site || {};
    const versions = v.versions || {};
    /* Streamer mode: the dossier keeps its shape but never carries the name,
       the recovery session or the build signature. */
    const streamer = Boolean(v.streamer);
    return {
      toolkit: 'Mikeybox Toolkit · ' + (streamer ? 'MBX-TKL/2 · PRIME-••••••' : (v.signature || 'unlicensed build')),
      generatedAt: v.now || Date.now(),
      site: {
        host: cleanText(v.host),
        mode: cleanText(site.mode) || 'unknown',
        banner: cleanText(site.banner),
        gameVersion: cleanText(versions.site && versions.site.gameVersion),
        buildId: cleanText(versions.site && versions.site.buildId),
        padPlayers: versions.padHost && Number.isFinite(Number(versions.padHost.players)) ? Number(versions.padHost.players) : null,
      },
      player: {
        inGameName: streamer ? (names[0] ? 'Player' : '') : (names[0] || ''),
        recentNames: streamer ? [] : names,
        platform: cleanText(v.platform) || 'quest',
        editorLayout: cleanText(v.layout),
        toolTab: cleanText(v.toolTab),
        handTracking: cleanText(v.handTracking),
        recoverySession: streamer ? '' : cleanText(v.recoverySession),
      },
      streamerHidden: streamer || undefined,
      ai: v.ai || null,
    };
  }

  function catalogLines(items, limit) {
    const max = limit || 300;
    return (items || []).slice(0, max).map((item) => {
      const category = item.category ? ' [' + item.category + ']' : '';
      return item.id + ' — ' + (item.name || item.id) + category;
    }).join('\n');
  }

  /* ---- Build knowledge (from the editor's live catalog + build policy) ----
     items.json only gives ids, names and categories, so this table records what
     those real ids are good for. planFor() drops anything the live catalog does
     not allow, so a renamed or removed item can never reach the model. */
  const PART_ROLES = {
    structure: ['item_steel_beam', 'item_truss', 'item_truss_small', 'item_metal_rod', 'item_metal_rod_small', 'item_metal_plate', 'item_metal_plate_small', 'item_plate_round', 'item_cube_frame', 'item_wood_pallet', 'item_plank'],
    panels: ['item_metal_plate', 'item_metal_plate_small', 'item_plate_round', 'item_wood_pallet', 'item_plank'],
    hull: ['item_module_hull_1', 'item_module_hull_2', 'item_module_hull_3', 'item_wood_pallet', 'item_plank', 'item_metal_plate'],
    wings: ['item_steampunk_wings', 'item_plank', 'item_metal_plate', 'item_truss'],
    wheels: ['item_steampunk_gear_wheels', 'item_steampunk_gear_big', 'item_steampunk_gear_small', 'item_metal_ball'],
    thrust: ['item_box_fan', 'item_war_fan', 'item_steampunk_smokestack', 'item_steampunk_coils_big'],
    seat: ['item_joystick', 'item_remote_controller', 'item_backrooms_chair', 'item_cyberpunk_barstool', 'item_mannequin_torso'],
    light: ['item_flashlight', 'item_steampunk_lamp', 'item_steampunk_lightbulb', 'item_film_light'],
    limbs: ['item_robot_arm_left', 'item_robot_arm_right', 'item_mannequin_leg_left', 'item_mannequin_leg_right', 'item_robot_head', 'item_mannequin_head'],
    /* Goop blobs: a couple of scaled footballs swell into one rounded body. */
    shell: ['item_football', 'item_mannequin_torso', 'item_metal_ball'],
    detail: ['item_rope', 'item_cyberpunk_pipe', 'item_cyberpunk_pipe_curved', 'item_cyberpunk_neontube', 'item_cyberpunk_neon_sign', 'item_metal_rod_curved'],
  };

  /* Gears spawn lying flat, so a wheel still at identity is a hubcap on the
     floor. Metal balls are omitted: a sphere reads the same at any angle. */
  const GEAR_WHEELS = new Set(['item_steampunk_gear_wheels', 'item_steampunk_gear_big', 'item_steampunk_gear_small']);

  const STRUCTURAL_IDS = new Set([].concat(
    PART_ROLES.structure,
    PART_ROLES.panels,
    PART_ROLES.hull,
    PART_ROLES.wings,
    PART_ROLES.limbs,
    PART_ROLES.shell
  ));

  /* Each brief is a recipe, not a vibe: coordinates, counts and which real
     items do the job. The model follows it far better than "make it look good". */
  const ARCHETYPES = [
    {
      id: 'plane',
      label: 'aircraft',
      keywords: ['plane', 'bomber', 'aircraft', 'airplane', 'aeroplane', 'jet', 'glider', 'fighter', 'aviation', 'flight', 'flying', 'airship', 'zeppelin', 'helicopter'],
      minParts: 16,
      targetParts: 26,
      symmetric: true,
      palette: ['structure', 'hull', 'wings', 'thrust', 'seat', 'light', 'detail'],
      brief: [
        'Silhouette: a long fuselage along z, nose at -z, tail at +z.',
        'Fuselage: 5-6 hull or panel nodes at [0,0,-1.8], [0,0,-1.1], [0,0,-0.4], [0,0,0.3], [0,0,1.0], [0,0,1.7]. Use a steel_beam as the spine root.',
        'Wings: mirrored pairs at z about -0.2. Each side gets 2-3 panels at x = ±0.55, ±1.15, ±1.75, same y, stepping back in z by about 0.12 per step. Wingspan must be wider than the fuselage is long.',
        'Engines: box_fan or war_fan at x = ±0.85, y = -0.28, z = -0.15. If the fan spawns facing up, tip it forward with rot [0.7071,0,0,0.7071] on both engines.',
        'Tail: vertical fin (plank) at [0,0.55,1.7]; mirrored stabilisers at x = ±0.55, z = 1.6, rot mirrored as [x,-y,-z,w].',
        'Cockpit: joystick or backrooms_chair at [0,0.32,-0.5]; a flashlight at [0,0.1,-1.75] reads as a nose light.',
        'Every wing panel must attach to the previous panel or the fuselage - loose planks are not wings.',
      ],
    },
    {
      id: 'ground',
      label: 'ground vehicle',
      keywords: ['car', 'truck', 'tank', 'kart', 'bike', 'motorcycle', 'bus', 'van', 'vehicle', 'wheels', 'racer', 'tractor', 'buggy', 'jeep', 'train'],
      minParts: 12,
      targetParts: 20,
      symmetric: true,
      palette: ['structure', 'wheels', 'panels', 'seat', 'light', 'thrust'],
      brief: [
        'Chassis: three steel_beam or truss nodes along z at [0,0.05,-1.0], [0,0.05,0], [0,0.05,1.0]; the middle one is the root.',
        'Wheels: four steampunk_gear_wheels at x = ±0.85, y = -0.05, z = ±0.9. Left side rot [0,0,0.7071,0.7071], right side its mirror [0,0,-0.7071,0.7071], so the gears stand upright and face outward; never leave a wheel at identity.',
        'Body: 2-4 panels above the chassis at y 0.25-0.45 for the floor, hood and rear deck. Lay planks flat (a plank that stands on end is a wall, not a deck).',
        'Cabin: backrooms_chair or joystick at [0,0.5,0.2]; a wheelhandle can read as the steering wheel.',
        'Lights: flashlight pair at x = ±0.45, y = 0.3, z = -1.05.',
        'Armour (tank): metal_plate side skirts mirrored at x = ±0.95, plus a turret of 2 plates and a metal_rod barrel at y 0.75. The turret is a small stack, not a fence: keep every skirt within 0.3 of the body in x.',
      ],
    },
    {
      id: 'boat',
      label: 'watercraft',
      keywords: ['boat', 'ship', 'raft', 'submarine', 'vessel', 'sail', 'pirate', 'ferry', 'canoe', 'yacht', 'fishing boat'],
      minParts: 12,
      targetParts: 22,
      symmetric: true,
      palette: ['hull', 'panels', 'wings', 'seat', 'light', 'detail'],
      brief: [
        'Hull: 5 module_hull or wood_pallet nodes along z at y = -0.25, from z -1.6 to 1.6, narrowed at the bow (x = ±0.3) and wide amidships (x = ±0.9 for side pieces).',
        'Deck: 3-4 plank panels at y = 0.2 spanning the hull, mirrored side rails at x = ±0.95. Planks lie flat; stand one up only for a rail.',
        'Mast and sail: metal_rod vertical at [0,1.0,0.2] with a plank or steampunk_wings sail at [0,1.35,0.25].',
        'Cabin: backrooms_chair at [0,0.55,-0.4]; a wheelhandle at [0,0.8,-0.9] if it is a fishing boat.',
        'Rudder: metal_plate at [0,0,1.75]; lantern at [0,0.75,-1.4] for a bow light.',
      ],
    },
    {
      id: 'drone',
      label: 'drone',
      keywords: ['drone', 'quadcopter', 'quad', 'copter', 'uav', 'rotorcraft'],
      minParts: 10,
      targetParts: 16,
      symmetric: true,
      palette: ['structure', 'thrust', 'panels', 'light', 'detail'],
      brief: [
        'Core: cube_frame at the origin as root, with a crate or metal_plate on top as the battery (y 0.18).',
        'Arms: metal_rod or truss_small from the core to x = ±0.8 and z = ±0.8 (diagonal arms read better than a plus), mirrored rotations.',
        'Rotors: one box_fan at each arm end, all at y = 0.12, x = ±0.8, z = ±0.8, facing up (identity rot; one 90° turn only if the fan spawns sideways).',
        'Camera: flashlight at [0,-0.15,-0.35] pointing down-forward; add a second plate as a gimbal if parts allow.',
        'Landing skids: two metal_rod_small at x = ±0.35, y = -0.3, z = ±0.3.',
      ],
    },
    {
      id: 'suit',
      label: 'wearable suit',
      keywords: ['suit', 'wear', 'wearing', 'wearable', 'cosplay', 'costume', 'armor', 'armour', 'exosuit', 'outfit', 'egg suit', 'on the player', 'player can wear', 'power armor', 'powerarmor'],
      minParts: 10,
      targetParts: 20,
      symmetric: true,
      wearable: true,
      palette: ['shell', 'limbs', 'panels', 'detail', 'light', 'structure'],
      brief: [
        'Root: item_backpack_small_base - the small base the game snaps to the player\'s back. Every child is measured from that pack, so the pack is the origin (0,0,0), not the floor.',
        'Body envelope: keep every part inside |x| <= 0.42, |z| <= 0.3 and y between -0.5 and 0.75. Anything higher floats over the player\'s head; anything wider hangs in the air beside them.',
        'Shell: 4-6 item_football blobs over the torso at [0,-0.04,0.02], [0,0.2,0], [0,0.36,0.04] and [±0.16,0.16,0]. scaleModifier 0.3-0.6 on each so they merge into one egg instead of reading as loose balls.',
        'Head: mannequin_head or robot_head at [0,0.62,0.04] with scaleModifier 0.05-0.2, a football or plate behind it as a helmet, and a flashlight on each side at x ±0.17, y 0.62 for eyes.',
        'Arms: robot_arm_left at [-0.3,0.3,0.02], robot_arm_right at [0.3,0.3,0.02]. Left rot [0,0,0.7071,0.7071], right rot [0,0,-0.7071,0.7071] so both hang outward; a football on each hand makes a rounded fist.',
        'Legs: mannequin_leg_left and mannequin_leg_right at x ±0.12, y -0.34 when the suit covers the whole body; skip them for a torso-only suit.',
        'Details: a cyberpunk_pipe or rope down the spine, coils or a smokestack on the pack side (+z), all small parts at scaleModifier 0.',
        'This is worn, not built next to the player: no tower, no fence of planks, no turret, no legs standing on the ground. Roughly 0.8 m across the shoulders, 0.75 m tall, and every part attached to the pack.',
      ],
    },
    {
      id: 'robot',
      label: 'robot',
      keywords: ['robot', 'mech', 'android', 'golem', 'walker', 'humanoid'],
      minParts: 14,
      targetParts: 24,
      symmetric: true,
      palette: ['structure', 'panels', 'limbs', 'light', 'detail', 'thrust'],
      brief: [
        'Torso: 2-3 metal_plate or wood_pallet panels stacked at y 1.0-1.4; the lower torso is the root.',
        'Head: robot_head or mannequin_head at [0,1.75,0]; add a light on each side at x = ±0.18.',
        'Arms: robot_arm_left at x = -0.65, robot_arm_right at x = +0.65, shoulders at y 1.45. Mirror them exactly.',
        'Legs: mannequin_leg_left and mannequin_leg_right at x = ±0.25, y 0.55, feet at y 0.1.',
        'Details: steampunk_smokestack on the back, tesla coils or neon tubes at the shoulders for a mech look.',
        'Keep the silhouette upright: height greater than width, all limbs attached to the torso.',
      ],
    },
    {
      id: 'building',
      label: 'structure',
      keywords: ['house', 'base', 'fort', 'castle', 'tower', 'cabin', 'shelter', 'building', 'shop', 'bunker', 'pirate base'],
      minParts: 16,
      targetParts: 30,
      symmetric: false,
      palette: ['panels', 'structure', 'light', 'seat', 'detail'],
      brief: [
        'Floor: 4 metal_plate or plank panels at y = 0 forming a square from x,z -0.9 to 0.9.',
        'Walls: 2 panels per side at y = 0.5 and 1.0, leaving a doorway gap on one side.',
        'Roof: 3-4 castle_roof_topper or metal_plate panels at y = 1.5, slightly overhanging.',
        'Door: castle_door or halloween_door at the gap; a lamp beside it at y 1.2.',
        'Interior: a chair, a lantern and a crate so the build is not just a shell.',
      ],
    },
    {
      id: 'weapon',
      label: 'weapon',
      keywords: ['gun', 'cannon', 'turret', 'weapon', 'launcher', 'sniper', 'rifle', 'cannon', 'mortar', 'crossbow'],
      minParts: 6,
      targetParts: 12,
      symmetric: false,
      palette: ['structure', 'panels', 'detail', 'light', 'thrust'],
      brief: [
        'Barrel: metal_rod or steel_beam along -z, with 1-2 pipe or metal_rod_small rings around it.',
        'Body: metal_plate box behind the barrel; a wheelhandle or pipe reads as the grip.',
        'Mount: truss or cube_frame under the body so it can sit on a vehicle or a tripod.',
        'Sights: a metal_rod_small scope on top plus a small light.',
        'Keep it compact: a handheld weapon spans under 1.5 m, a turret up to 2.5 m with a wider base.',
      ],
    },
  ];

  const GENERIC_PLAN = {
    id: 'generic',
    label: 'invention',
    keywords: [],
    minParts: 8,
    targetParts: 16,
    symmetric: false,
    palette: ['structure', 'panels', 'detail', 'light', 'seat'],
    brief: [
      'Start from one sturdy central body, then add parts that each do a job: structure, a surface, a control, a detail.',
      'Keep parts touching: 0.15-0.4 apart, spread on all three axes so it reads from every angle.',
      'Vary the item IDs so the build is not one repeated plank.',
    ],
  };

  function planFor(prompt, options) {
    const opts = options || {};
    const text = String(prompt || '').toLowerCase();
    const known = opts.knownIds instanceof Set ? opts.knownIds : null;
    const maxParts = Math.round(clampNumber(opts.maxParts, 3, 120, 30));
    let best = GENERIC_PLAN;
    let bestScore = 0;
    for (const archetype of ARCHETYPES) {
      const hits = archetype.keywords.reduce((total, word) => (text.includes(word) ? total + 1 : total), 0);
      if (hits > bestScore) {
        bestScore = hits;
        best = archetype;
      }
    }
    const minParts = Math.min(maxParts, best.minParts);
    const targetParts = Math.min(maxParts, Math.max(minParts, best.targetParts));
    const allowed = (id) => !known || known.has(id);
    const recommended = [];
    const seen = new Set();
    /* Honour what the prompt actually names: "box fans and wood" should put
       box_fan and wood_pallet at the top, not somewhere past the cut-off. */
    const words = text.split(/[^a-z0-9]+/).filter((word) => word.length > 3).map((word) => word.replace(/s$/, ''));
    for (const role of best.palette) {
      for (const id of PART_ROLES[role] || []) {
        if (seen.has(id) || !allowed(id)) continue;
        const token = id.replace('item_', '');
        if (words.some((word) => token.includes(word))) {
          seen.add(id);
          recommended.push(id);
        }
      }
    }
    /* Round-robin the roles so a short list still holds a frame part, a wing,
       an engine and a seat instead of 18 variants of the same panel. */
    const queues = best.palette.map((role) => (PART_ROLES[role] || []).slice());
    let added = true;
    while (added && recommended.length < 18) {
      added = false;
      for (const queue of queues) {
        while (queue.length) {
          const id = queue.shift();
          if (seen.has(id) || !allowed(id)) continue;
          seen.add(id);
          recommended.push(id);
          added = true;
          break;
        }
        if (recommended.length >= 18) break;
      }
    }
    const rootId = best.wearable
      ? ['item_backpack_small_base', 'item_backpack'].find((id) => allowed(id)) || ''
      : '';
    return {
      id: best.id,
      label: best.label,
      brief: best.brief.join('\n'),
      minParts: minParts,
      targetParts: targetParts,
      symmetric: Boolean(best.symmetric),
      wearable: Boolean(best.wearable),
      rootId: rootId,
      recommended: recommended.slice(0, 18),
    };
  }

  /* A compact, real invention in the exact output shape. It teaches mirrored
     wheels, nested attachments and the coordinate convention in one example
     for ~1k tokens, instead of another paragraph of rules. */
  function fewShotInvention() {
    const attach = (id, pos, rot) => ({
      item: defaultNode(id),
      subParentID: 0,
      pos: pos,
      rot: rot || [0, 0, 0, 1],
      posePos: [0, 0, 0],
      poseRot: [0, 0, 0, 1],
      wasDynamicStuck: false,
    });
    const root = defaultNode('item_steel_beam');
    const spine = attach('item_steel_beam', [0, 0, 0.9]);
    spine.item.stuckChildren = [
      attach('item_metal_plate', [0, 0.16, 1.1]),
      attach('item_flashlight', [0, 0.18, 1.75]),
      attach('item_steampunk_smokestack', [0, 0.4, 1.2]),
      attach('item_backrooms_chair', [0, 0.3, 0.55]),
    ];
    root.stuckChildren = [
      attach('item_steel_beam', [0, 0, -0.9]),
      spine,
      attach('item_steampunk_gear_wheels', [-0.55, -0.05, -0.2], [0, 0, 0.7071, 0.7071]),
      attach('item_steampunk_gear_wheels', [0.55, -0.05, -0.2], [0, 0, -0.7071, 0.7071]),
      attach('item_joystick', [0, 0.4, -0.35]),
      attach('item_metal_rod', [0, 0.1, -1.5]),
    ];
    return { name: 'Hover bike', summary: 'Two-beam spine, mirrored geared wheels and a rider seat.', root: root };
  }

  /* The wearable example. Same schema as fewShotInvention, but every number is
     the pack envelope: torso on the origin, head 0.62 up, arms at +/-0.3. */
  function fewShotSuit() {
    const attach = (id, pos, rot, scale) => {
      const item = defaultNode(id);
      if (scale !== undefined) item.scaleModifier = scale;
      return {
        item: item,
        subParentID: 0,
        pos: pos,
        rot: rot || [0, 0, 0, 1],
        posePos: [0, 0, 0],
        poseRot: [0, 0, 0, 1],
        wasDynamicStuck: false,
      };
    };
    const root = defaultNode('item_backpack_small_base');
    root.stuckChildren = [
      attach('item_football', [0, -0.04, 0.02], null, 0.55),
      attach('item_football', [-0.16, 0.16, 0], null, 0.35),
      attach('item_football', [0.16, 0.16, 0], null, 0.35),
      attach('item_football', [0, 0.38, 0.04], null, 0.3),
      attach('item_mannequin_head', [0, 0.62, 0.04], null, 0.1),
      attach('item_robot_arm_left', [-0.3, 0.3, 0.02], [0, 0, 0.7071, 0.7071]),
      attach('item_robot_arm_right', [0.3, 0.3, 0.02], [0, 0, -0.7071, 0.7071]),
      attach('item_mannequin_leg_left', [-0.12, -0.34, 0]),
      attach('item_mannequin_leg_right', [0.12, -0.34, 0]),
      attach('item_cyberpunk_pipe', [0, 0.34, -0.14]),
      attach('item_steampunk_coils_big', [0, 0.44, -0.16]),
      attach('item_flashlight', [-0.17, 0.62, 0.1]),
      attach('item_flashlight', [0.17, 0.62, 0.1]),
    ];
    return {
      name: 'Egg suit',
      summary: 'A rounded goop shell over the small backpack base, with mirrored arms, stubby legs and an eye light pair.',
      root: root,
    };
  }

  function flattenWithPositions(root) {
    const nodes = [];
    const walk = (node, parent, depth, rot) => {
      if (!node || typeof node !== 'object' || !node.itemID) return;
      nodes.push({ id: node.itemID, abs: parent, depth: depth, rot: rot || [0, 0, 0, 1] });
      const kids = Array.isArray(node.stuckChildren) ? node.stuckChildren : [];
      for (const entry of kids) {
        const item = entry && entry.item && typeof entry.item === 'object' ? entry.item : entry;
        if (!item || !item.itemID) continue;
        const rel = Array.isArray(entry.pos) ? entry.pos : [0, 0, 0];
        const relRot = entry && Array.isArray(entry.rot) ? entry.rot : [0, 0, 0, 1];
        walk(item, [
          parent[0] + (Number(rel[0]) || 0),
          parent[1] + (Number(rel[1]) || 0),
          parent[2] + (Number(rel[2]) || 0),
        ], depth + 1, relRot);
      }
    };
    walk(root, [0, 0, 0], 0, [0, 0, 0, 1]);
    return nodes;
  }

  /* Deterministic review of what came back. It cannot judge beauty, but it can
     catch the failure that produced a 7-part "bomber": too few parts, no
     mirrored pairs, no structural parts, a cramped pile, one repeated item. */
  function scoreInvention(invention, plan, options) {
    const planInfo = plan || GENERIC_PLAN;
    const nodes = flattenWithPositions(invention && invention.root);
    const issues = [];
    if (!nodes.length) return { score: 0, issues: ['The build is empty.'], stats: { parts: 0, mirroredPairs: 0, span: 0, length: 0, height: 0, structural: 0 } };

    const xs = nodes.map((n) => n.abs[0]);
    const ys = nodes.map((n) => n.abs[1]);
    const zs = nodes.map((n) => n.abs[2]);
    const span = Math.max.apply(null, xs) - Math.min.apply(null, xs);
    const height = Math.max.apply(null, ys) - Math.min.apply(null, ys);
    const length = Math.max.apply(null, zs) - Math.min.apply(null, zs);
    const counts = new Map();
    let structural = 0;
    for (const node of nodes) {
      counts.set(node.id, (counts.get(node.id) || 0) + 1);
      if (STRUCTURAL_IDS.has(node.id)) structural += 1;
    }
    let mirroredPairs = 0;
    let rotationMismatch = 0;
    for (const node of nodes) {
      if (node.abs[0] <= 0.15) continue;
      const partner = nodes.find((other) => other !== node
        && Math.abs(other.abs[0] + node.abs[0]) < 0.14
        && Math.abs(other.abs[1] - node.abs[1]) < 0.2
        && Math.abs(other.abs[2] - node.abs[2]) < 0.2);
      if (partner) mirroredPairs += 1;
      /* A mirrored part needs the mirrored rotation: [x,y,z,w] -> [x,-y,-z,w].
         Sending the same rot to both sides flips the mesh on one of them. */
      if (partner && partner.id === node.id) {
        const own = quat(node.rot);
        if (Math.hypot(own[0], own[1], own[2]) >= 0.001) {
          const want = mirrorRotation(own);
          const got = quat(partner.rot);
          const dot = Math.abs(want[0] * got[0] + want[1] * got[1] + want[2] * got[2] + want[3] * got[3]);
          if (dot < 0.96) rotationMismatch += 1;
        }
      }
    }
    let tilted = 0;
    let atRest = 0;
    for (const node of nodes) {
      const own = quat(node.rot);
      if (Math.hypot(own[0], own[1], own[2]) < 0.001) {
        atRest += 1;
        continue;
      }
      if (!isAxisAligned(own)) tilted += 1;
    }
    const wheels = nodes.filter((node) => GEAR_WHEELS.has(node.id));
    const flatWheels = wheels.filter((node) => Math.hypot(
      quat(node.rot)[0], quat(node.rot)[1], quat(node.rot)[2]
    ) < 0.001).length;

    let penalty = 0;
    if (nodes.length < planInfo.minParts) {
      const short = planInfo.minParts - nodes.length;
      issues.push('Only ' + nodes.length + ' parts - a ' + planInfo.label + ' needs about ' + planInfo.minParts + ' (add ' + short + ').');
      penalty += Math.min(30, 10 + short * 2);
    }
    if (planInfo.symmetric && mirroredPairs < 2) {
      issues.push('No mirrored pairs - wings, wheels or arms must be mirrored across x.');
      penalty += 22;
    }
    if (planInfo.id === 'plane' && span <= length) {
      issues.push('Wingspan (' + span.toFixed(2) + ' m) is not wider than the fuselage is long (' + length.toFixed(2) + ' m).');
      penalty += 18;
    }
    if (planInfo.id === 'robot' && height < span) {
      issues.push('The robot is wider than it is tall.');
      penalty += 12;
    }
    if (planInfo.id === 'ground' && length > 0.3 && height > length * 1.15) {
      issues.push('The body is taller than it is long (' + height.toFixed(2) + ' m vs ' + length.toFixed(2) + ' m) - a vehicle needs a long chassis.');
      penalty += 10;
    }
    if (tilted) {
      issues.push(tilted + ' part' + (tilted === 1 ? ' is' : 's are') + ' tilted off the 90° grid - snap every rot to the orientation table.');
      penalty += Math.min(14, 4 + tilted * 2);
    }
    if (wheels.length && flatWheels === wheels.length) {
      issues.push('Every wheel is at identity - gear wheels spawn lying flat, so each one needs a 90° roll to stand upright.');
      penalty += 14;
    }
    if (planInfo.wearable) {
      const rootId = (invention && invention.root && invention.root.itemID) || '';
      const grab = (invention && invention.root && Array.isArray(invention.root.grabPos)) ? invention.root.grabPos : [0, 0, 0];
      const offset = Math.hypot(Number(grab[0]) || 0, Number(grab[1]) || 0, Number(grab[2]) || 0);
      const highest = Math.max.apply(null, ys);
      const lowest = Math.min.apply(null, ys);
      const reach = Math.max.apply(null, xs.concat(zs).map((n) => Math.abs(n)));
      if (!/^item_backpack/.test(rootId)) {
        issues.push('Root is ' + (rootId || 'unknown') + ' - a worn build has to root on a backpack base, or it stands beside the player instead of on them.');
        penalty += 25;
      }
      if (offset > 0.3) {
        issues.push('The build is offset ' + offset.toFixed(2) + ' m from its own root - a suit has to sit on the pack.');
        penalty += 12;
      }
      if (highest > 0.9 || lowest < -0.65 || reach > 0.5) {
        issues.push('The suit spills out of the body envelope (top ' + highest.toFixed(2) + ' m, reach ' + reach.toFixed(2) + ' m) - it will hang around the player, not fit them.');
        penalty += 20;
      }
    }
    if ((planInfo.id === 'ground' || planInfo.id === 'plane') && nodes.length >= 6 && atRest === nodes.length) {
      issues.push('Nothing is rotated - planks stand on end and wheels lie down. Turn the deck, wheels and wings with the orientation table.');
      penalty += 18;
    }
    if (rotationMismatch) {
      issues.push(rotationMismatch + ' mirrored pair' + (rotationMismatch === 1 ? ' uses' : 's use') + ' the same rot instead of the mirrored rot ([x,-y,-z,w]).');
      penalty += Math.min(10, 3 * rotationMismatch);
    }
    if (structural === 0 && nodes.length > 4) {
      issues.push('No frame or panel parts - the build is only props.');
      penalty += 16;
    }
    const top = Math.max.apply(null, Array.from(counts.values()));
    if (nodes.length > 6 && top / nodes.length > 0.55) {
      const worst = Array.from(counts.entries()).sort((a, b) => b[1] - a[1])[0];
      issues.push('Too repetitive: ' + worst[0] + ' is ' + worst[1] + ' of ' + nodes.length + ' parts.');
      penalty += 12;
    }
    if (!planInfo.wearable && nodes.length > 5 && span < 0.9 && length < 0.9 && height < 0.9) {
      issues.push('Everything is crammed into a ' + span.toFixed(2) + ' m box - spread it out.');
      penalty += 12;
    }
    if (nodes.length > planInfo.targetParts + 12) {
      issues.push('Overbuilt: ' + nodes.length + ' parts for a design that needs about ' + planInfo.targetParts + '.');
      penalty += 8;
    }

    return {
      score: Math.max(10, Math.min(100, 100 - penalty)),
      issues: issues,
      stats: {
        parts: nodes.length,
        mirroredPairs: mirroredPairs,
        span: Math.round(span * 100) / 100,
        length: Math.round(length * 100) / 100,
        height: Math.round(height * 100) / 100,
        structural: structural,
        tilted: tilted,
        rotationMismatch: rotationMismatch,
        flatWheels: flatWheels,
      },
    };
  }

  function improveMessages(payload) {
    const p = payload || {};
    const plan = p.plan || GENERIC_PLAN;
    const issues = Array.isArray(p.issues) ? p.issues : [];
    const invention = p.invention && p.invention.root ? p.invention.root : p.invention;
    const ids = (Array.isArray(p.items) ? p.items : []).map((item) => item && item.id).filter(Boolean);
    return [
      {
        role: 'system',
        content: [
          'You improve an existing Animal Company invention for the Mikeybox Goop Editor.',
          'Return the complete corrected invention as strict JSON with the same shape: {"name","summary","root":<ITEM>}. No markdown, no commentary.',
          'Keep every part that already works, fix every listed problem, and use only allowed item IDs. Never invent IDs and never use banned items.',
          'pos is metres relative to the parent: +x right, +y up, -z front. rot is a unit quaternion [x,y,z,w].',
          'Only quarter turns: identity, +-90° about x/y/z, or 180°. A mirrored pair uses rot [x,-y,-z,w] of its partner, never the same rot on both sides.',
          plan.wearable
            ? 'The player wears this build: keep the item_backpack_small_base root and fit every part inside the body envelope (|x| <= 0.42, |z| <= 0.3, y -0.5..0.75). Do not make it taller or wider.'
            : '',
        ].filter(Boolean).join('\n'),
      },
      {
        role: 'user',
        content: [
          'Problems found by the build checker:',
          issues.map((issue) => '- ' + issue).join('\n') || '- Make the build read more clearly as the requested object.',
          '',
          'Design brief:',
          plan.brief,
          '',
          'Aim for about ' + plan.targetParts + ' parts (at least ' + plan.minParts + ').',
          '',
          'Current build JSON:',
          JSON.stringify(invention).slice(0, 14000),
          '',
          'Allowed item IDs:',
          ids.join(', '),
          '',
          'Return the improved JSON now.',
        ].join('\n'),
      },
    ];
  }

  const SYSTEM_PROMPT = [
    'You are Goop Architect, a senior builder of Animal Company inventions for the Mikeybox Goop Editor.',
    'You think in three dimensions and build recognisable machines, not piles of planks. Return one complete invention as strict JSON.',
    '',
    'Coordinates (each attachment is relative to its parent, in metres):',
    '- +x is the build\'s right, +y is up, -z is the front/nose (so +z is the rear).',
    '- Keep every pos inside -3.8..3.8. Neighbours usually sit 0.15-0.6 apart; vehicles span about 2-4 m.',
    '- rot is a unit quaternion [x,y,z,w]. Only quarter turns are ever needed; a 30° tilt makes a build look melted.',
    '',
    'Orientation (the whole rotation vocabulary - use these exact values):',
    '- [0,0,0,1] as the item spawns.',
    '- [0.7071,0,0,0.7071] +90° about x: the part\'s up becomes +z (back); [-0.7071,0,0,0.7071] is -90° about x.',
    '- [0,0,0.7071,0.7071] +90° about z: its +x becomes +y, which stands a lying part up or lays a standing part down; [0,0,-0.7071,0.7071] is the -90° version.',
    '- [0,0.7071,0,0.7071] +90° about y: its +z becomes +x, a quarter turn on the spot.',
    '- [1,0,0,0], [0,1,0,0] and [0,0,1,0] are the three 180° turns.',
    '- Mirroring a part across x: pos.x flips sign and rot becomes [x,-y,-z,w]. Writing the same rot on both sides is the classic mirrored-part bug.',
    '- Decide the pose first (flat deck, upright wall, wheel facing sideways, barrel along -z), then write exactly one entry above. Never a decimal angle.',
    '',
    'Wearable builds (the player puts it on):',
    '- Root on item_backpack_small_base. The game snaps that pack to the player\'s back, and every child is measured from the pack, so the pack is the origin - not the floor.',
    '- Stay inside the body envelope: |x| <= 0.42, |z| <= 0.3, y between -0.5 and 0.75, grabPos [0,0,0]. A stack that grows upward stands next to the player; it is not worn.',
    '- Make the body from 3-6 item_football blobs with scaleModifier 0.3-0.6 so they read as one rounded shell; head at y about 0.62; robot_arm_left and robot_arm_right at x -0.3 and +0.3 with mirrored rot.',
    '',
    'JSON shape (no markdown, no commentary):',
    '{"name":"short build name","summary":"one or two sentences","root":<ITEM>}',
    '',
    'ITEM node (exact keys, all required):',
    '{"itemID":"item_...","jsonData":"","stashPos":0,"children":[],"stuckChildren":[<ATTACHMENT>],"grabPos":[0,0,0],"grabRot":[0,0,0,1],"state":0,"ammo":0,"isBlueprint":true,"scaleModifier":0,"colorHue":0,"colorSaturation":0,"jellyStrength":0,"stashRow":0,"stashCol":0}',
    '',
    'ATTACHMENT (one Goop connection):',
    '{"item":<ITEM>,"subParentID":0,"pos":[x,y,z],"rot":[x,y,z,w],"posePos":[0,0,0],"poseRot":[0,0,0,1],"wasDynamicStuck":false}',
    '',
    'Rules:',
    '- Use ONLY item IDs from the allowed catalog. Never invent IDs.',
    '- Never use a banned item. If the prompt asks for one, substitute a sensible allowed item.',
    '- Root is the item that spawns: something sturdy and spawnable (steel_beam, wood_pallet, cube_frame, joystick, backpack). A build the player wears always roots on item_backpack_small_base.',
    '- Every other part hangs off a stuckChildren entry; nest a part under the part it sits on. Always leave children: [].',
    '- Follow the design brief: it names the silhouette, the part counts and the real items for each job. A bomber with no wings is a failure even if the JSON is valid.',
    '- Use different parts for different jobs: structure (steel_beam, truss, metal_plate, wood_pallet, plank), propulsion (box_fan, war_fan), wheels (steampunk_gear_wheels), seating (joystick, backrooms_chair), light (flashlight, steampunk_lamp).',
    '- Mirror aircraft wings, vehicle wheels and robot arms: same id, equal |x|, matching y and z, and rot [x,-y,-z,w] of its partner.',
    '- Wheels and rotors are never left at identity in a vehicle or drone: give each one the quarter turn that makes it stand and face outward.',
    '- Hit the brief\'s part target instead of the smallest build that parses. Do not repeat one item for more than half the build.',
    '- Add personality with colorHue 0-360, colorSaturation 0-1, scaleModifier -0.4..0.6 and small jellyStrength values.',
    '- Keep the whole reply under 12,000 characters and return JSON only.',
    '',
    'Before answering, check: root present and allowed, every part allowed, mirrored pairs match, the silhouette matches the brief, and no part is buried inside another.',
  ].join('\n');

  function buildMessages(payload) {
    const p = payload || {};
    const items = Array.isArray(p.items) ? p.items : [];
    const banned = Array.isArray(p.banned) ? p.banned : [];
    const prompt = String(p.prompt || '').slice(0, 2000);
    const maxParts = Math.round(clampNumber(p.maxParts, 3, 120, 30));
    const known = new Set(items.map((item) => item && item.id).filter(Boolean));
    const plan = planFor(prompt, { maxParts: maxParts, knownIds: known });
    const byId = new Map(items.map((item) => [item.id, item]));
    const recommended = plan.recommended.map((id) => {
      const item = byId.get(id);
      return item ? id + ' — ' + (item.name || id) + (item.category ? ' [' + item.category + ']' : '') : id;
    });
    const user = [
      'Build request: ' + (prompt || 'A useful survival invention.'),
      '',
      'Design brief (' + plan.label + '):',
      plan.brief,
      '',
      'Parts budget: aim for about ' + plan.targetParts + ' parts, never fewer than ' + plan.minParts + ' for this design.',
      'Recommended parts (all allowed):',
      recommended.join('\n') || 'use the catalog below',
      '',
      'Worked example of the exact JSON shape, the coordinate convention and mirrored wheels (copy the structure, not the subject):',
      JSON.stringify(plan.wearable ? fewShotSuit() : fewShotInvention()),
      '',
      'Maximum nodes: ' + maxParts,
      'Banned items: ' + (banned.length ? banned.join(', ') : 'none'),
      'Categories: ' + (Array.isArray(p.categories) ? p.categories.join(', ') : 'unknown'),
      '',
      'Allowed catalog (id — name [category]):',
      catalogLines(items, 1000),
      '',
      'Return the JSON object now.',
    ].join('\n');
    return [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user', content: user },
    ];
  }

  /* Each ITEM node costs roughly 150-250 tokens, so a 30-part build needs far
     more than 4096 or the JSON gets cut off mid-object. */
  function maxTokensFor(maxParts) {
    const parts = Math.round(clampNumber(maxParts, 3, 120, 30));
    return Math.min(8192, Math.max(2048, 900 + parts * 240));
  }

  /* top_p is pinned per model on NVIDIA (kimi-k3.1-pro fixes it at 0.95 and
     rejects anything else), so it is never sent; the model's own default wins.
     stream: true keeps the connection alive while a reasoning model thinks. */
  function buildChatBody(payload, model, structured) {
    const p = payload || {};
    return {
      model: model,
      messages: buildMessages(p),
      temperature: 0.35,
      max_tokens: maxTokensFor(p.maxParts),
      stream: true,
      ...(structured ? { response_format: { type: 'json_object' } } : {}),
    };
  }

  function imageSize(size) {
    const found = IMAGE_SIZES.find((entry) => entry.label === size);
    return found || IMAGE_SIZES[0];
  }

  const api = {
    DEFAULT_AI_SETTINGS,
    KNOWN_MODELS,
    IMAGE_MODELS,
    IMAGE_SIZES,
    SYSTEM_PROMPT,
    PART_ROLES,
    ARCHETYPES,
    planFor,
    fewShotInvention,
    fewShotSuit,
    scoreInvention,
    improveMessages,
    NODE_TEMPLATE,
    AUTO_MODEL,
    rankModels,
    pickBestModel,
    extractJson,
    normalizeInvention,
    buildMessages,
    maxTokensFor,
    buildChatBody,
    playerNamesFrom,
    latestPlayerName,
    dossierFrom,
    defaultNode,
    imageSize,
    clampNumber,
    ROT,
    AXIS_ROTS,
    qMul,
    snapRotation,
    isAxisAligned,
    mirrorRotation,
  };

  root.MBXAICore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
