/* Mikeybox Toolkit — service worker.
   Owns the NVIDIA API key (chrome.storage.local, never synced) and every
   cross-origin call, because content scripts are subject to the page's CORS. */
importScripts('ai-core.js');

const CORE = self.MBXAICore;
const CHAT_DEFAULT = 'https://integrate.api.nvidia.com/v1';
const IMAGE_DEFAULT = 'https://ai.api.nvidia.com/v1/genai';
const MAX_IMAGE_CHARS = 14 * 1024 * 1024;

function cleanBase(value, fallback) {
  const base = typeof value === 'string' && value.trim() ? value.trim() : fallback;
  return base.replace(/\/+$/, '');
}

async function loadConfig() {
  let stored = {};
  try {
    stored = await chrome.storage.local.get(['mbxAiKey', 'mbxAiSettings']);
  } catch (err) {
    stored = {};
  }
  const settings = Object.assign({}, CORE.DEFAULT_AI_SETTINGS, stored.mbxAiSettings || {});
  /* One-time move from a pinned model to Auto, so existing installs pick up
     automatic ranking (and the stall fallback) without a manual switch. */
  if (!settings.autoModelMigrated) {
    settings.chatModel = CORE.AUTO_MODEL;
    settings.autoModelMigrated = true;
    try {
      await chrome.storage.local.set({ mbxAiSettings: settings });
    } catch (err) {
      /* storage unavailable: the in-memory setting still applies */
    }
  }
  return {
    key: typeof stored.mbxAiKey === 'string' ? stored.mbxAiKey.trim() : '',
    settings: settings,
    chatBase: cleanBase(settings.chatBase, CHAT_DEFAULT),
    imageBase: cleanBase(settings.imageBase, IMAGE_DEFAULT),
  };
}

async function saveConfig(patch) {
  const current = await loadConfig();
  const settings = Object.assign({}, current.settings, patch || {});
  await chrome.storage.local.set({ mbxAiSettings: settings });
  return settings;
}

function apiError(status, data, text) {
  let detail = '';
  if (data) {
    if (typeof data.detail === 'string') detail = data.detail;
    else if (Array.isArray(data.detail)) detail = data.detail.map((d) => d && (d.msg || d.message || JSON.stringify(d))).join('; ');
    else if (data.error && typeof data.error === 'string') detail = data.error;
    else if (data.error && data.error.message) detail = data.error.message;
    else if (typeof data.message === 'string') detail = data.message;
    else if (typeof data.title === 'string') detail = data.title;
  }
  if (!detail && text) detail = String(text).slice(0, 400);
  let hint = '';
  if (status === 401 || status === 403) hint = ' Check the nvapi- key on build.nvidia.com/settings.';
  else if (status === 429) hint = ' The free tier allows about 40 requests per minute; wait and retry.';
  else if (status === 404) hint = ' That model or endpoint is not available on this account.';
  else if (status === 402) hint = ' This endpoint may not be included in the free tier.';
  const message = 'NVIDIA ' + status + (detail ? ': ' + detail : '') + hint;
  const error = new Error(message);
  error.status = status;
  return error;
}

async function apiPost(url, key, body, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs || 120000);
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + key,
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const text = await response.text();
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch (err) {
      data = null;
    }
    if (!response.ok) throw apiError(response.status, data, text);
    if (!data) throw new Error('The NVIDIA endpoint returned an empty response.');
    return data;
  } catch (err) {
    if (err && err.name === 'AbortError') {
      throw new Error('The request timed out after ' + Math.round((timeoutMs || 120000) / 1000) + 's.');
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

function contentOf(response) {
  const choice = response && Array.isArray(response.choices) ? response.choices[0] : null;
  const message = choice && choice.message ? choice.message : null;
  if (!message) return '';
  if (typeof message.content === 'string' && message.content.trim()) return message.content;
  if (Array.isArray(message.content)) {
    const joined = message.content.map((part) => (typeof part === 'string' ? part : part && part.text ? part.text : '')).join('\n');
    if (joined.trim()) return joined;
  }
  if (typeof message.reasoning_content === 'string' && message.reasoning_content.includes('{')) return message.reasoning_content;
  if (typeof response.output_text === 'string') return response.output_text;
  return '';
}

async function scanModels(options) {
  const pickBest = !options || options.pick !== false;
  const config = await loadConfig();
  if (!config.key) return { ok: false, error: 'Add your NVIDIA API key first.' };
  const url = config.chatBase + '/models';
  let response;
  try {
    response = await fetch(url, {
      headers: { Authorization: 'Bearer ' + config.key, Accept: 'application/json' },
    });
  } catch (err) {
    return { ok: false, error: 'Could not reach NVIDIA: ' + (err.message || 'network error') };
  }
  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch (err) {
    data = null;
  }
  let rawModels = data && Array.isArray(data.data) ? data.data : (Array.isArray(data) ? data : []);
  let scanError = '';
  const rejected = response.status === 401 || response.status === 403;
  if (!response.ok) {
    scanError = apiError(response.status, data, text).message;
    rawModels = [];
  }
  /* A key without model-list access still gets a usable, ranked shortlist. */
  if (!rawModels.length) {
    rawModels = CORE.KNOWN_MODELS;
    if (!scanError) scanError = 'This key did not list any models; using the built-in shortlist.';
  }
  const ranked = CORE.rankModels(rawModels);
  const models = ranked.slice(0, 24);
  const recommended = models.length ? models[0].id : '';
  const patch = { scannedModels: models, lastScanAt: Date.now() };
  /* Auto mode keeps ranking on every build and must not be pinned by a scan;
     an explicit scan only replaces a model the user picked manually. */
  const autoMode = !config.settings.chatModel || config.settings.chatModel === CORE.AUTO_MODEL;
  if (recommended && !autoMode && pickBest) patch.chatModel = recommended;
  await saveConfig(patch);
  return {
    ok: true,
    models: models,
    recommended: recommended,
    rawCount: rawModels.length,
    selected: patch.chatModel || (autoMode ? recommended : config.settings.chatModel),
    usedFallback: Boolean(scanError),
    warning: scanError,
    rejected: rejected,
  };
}

/* A slow reasoning model can take minutes, so chat completions are streamed:
   the call survives as long as tokens keep arriving and only gives up when the
   endpoint goes quiet. Chrome kills a busy worker at 5 minutes, so 4.5 min is
   the hard ceiling here. */
const STREAM_IDLE_MS = 90000;
const STREAM_TOTAL_MS = 270000;

async function apiStream(url, key, body) {
  const controller = new AbortController();
  let idleTimer = null;
  let idleHit = false;
  let totalHit = false;
  const bump = () => {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      idleHit = true;
      controller.abort();
    }, STREAM_IDLE_MS);
  };
  const totalTimer = setTimeout(() => {
    totalHit = true;
    controller.abort();
  }, STREAM_TOTAL_MS);
  bump();
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + key,
        'Content-Type': 'application/json',
        Accept: 'text/event-stream',
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    if (!response.ok) {
      const text = await response.text();
      let data = null;
      try {
        data = text ? JSON.parse(text) : null;
      } catch (err) {
        data = null;
      }
      throw apiError(response.status, data, text);
    }
    const contentType = response.headers.get('content-type') || '';
    /* Some deployments ignore stream:true and answer with one JSON body. */
    if (!/event-stream/i.test(contentType)) {
      const text = await response.text();
      let data = null;
      try {
        data = text ? JSON.parse(text) : null;
      } catch (err) {
        data = null;
      }
      if (!data) throw new Error('The NVIDIA endpoint returned an empty response.');
      return data;
    }
    if (!response.body || typeof response.body.getReader !== 'function') {
      throw new Error('This browser could not stream the NVIDIA response.');
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let content = '';
    let reasoning = '';
    let model = body.model || '';
    let finished = false;
    const consume = (raw) => {
      const data = raw.trim();
      if (!data) return false;
      if (data === '[DONE]') return true;
      let event = null;
      try {
        event = JSON.parse(data);
      } catch (err) {
        return false;
      }
      if (event && typeof event.model === 'string') model = event.model;
      const choice = event && Array.isArray(event.choices) ? event.choices[0] : null;
      const delta = choice && (choice.delta || choice.message);
      if (!delta) return false;
      if (typeof delta.content === 'string') content += delta.content;
      else if (Array.isArray(delta.content)) {
        content += delta.content.map((part) => (typeof part === 'string' ? part : part && part.text ? part.text : '')).join('');
      }
      if (typeof delta.reasoning_content === 'string') reasoning += delta.reasoning_content;
      else if (typeof delta.reasoning === 'string') reasoning += delta.reasoning;
      return false;
    };
    const takeLines = () => {
      let newline = buffer.indexOf('\n');
      while (newline >= 0) {
        const line = buffer.slice(0, newline).trim();
        buffer = buffer.slice(newline + 1);
        newline = buffer.indexOf('\n');
        if (!line || line.startsWith(':') || !line.startsWith('data:')) continue;
        if (consume(line.slice(5))) {
          finished = true;
          return;
        }
      }
    };
    while (!finished) {
      const chunk = await reader.read();
      if (chunk.done) break;
      bump();
      buffer += decoder.decode(chunk.value, { stream: true });
      takeLines();
    }
    /* A last event without a trailing newline still counts. */
    if (!finished) {
      buffer += decoder.decode();
      const tail = buffer.trim();
      if (tail.startsWith('data:')) consume(tail.slice(5));
    }
    try {
      await reader.cancel();
    } catch (err) {
      /* the stream already closed */
    }
    if (!content.trim() && !reasoning.trim()) throw new Error('The model streamed no content.');
    const message = { role: 'assistant', content: content };
    /* Thinking models can put the answer in reasoning_content; contentOf reads it. */
    if (!content.trim()) message.reasoning_content = reasoning;
    return { model: model, choices: [{ message: message }] };
  } catch (err) {
    if (err && (err.name === 'AbortError' || controller.signal.aborted)) {
      if (idleHit) throw new Error('NVIDIA stopped sending tokens for ' + Math.round(STREAM_IDLE_MS / 1000) + 's, so the build was cancelled. Try again or pick a faster model.');
      if (totalHit) throw new Error('The build was still running after ' + Math.round(STREAM_TOTAL_MS / 1000) + 's and was cancelled. Lower Max parts or pick a faster model.');
    }
    throw err;
  } finally {
    clearTimeout(idleTimer);
    clearTimeout(totalTimer);
  }
}

function chatRequest(url, key, body) {
  if (body && body.stream === false) return apiPost(url, key, body, STREAM_TOTAL_MS);
  return apiStream(url, key, body);
}

/* NVIDIA pins sampling parameters per model — kimi-k3.1-pro fixes top_p at 0.95
   and answers a 400 for anything else — and some models refuse a large
   max_tokens or streaming. Drop/repair just the named knob and retry, instead
   of failing the whole build on one unsupported field. */
function adjustRejectedParams(body, err) {
  if (!err || (err.status !== 400 && err.status !== 422)) return null;
  const detail = String(err.message || '');
  const next = Object.assign({}, body);
  let changed = false;
  if (/(fixed|not supported|unsupported|received|must be|outside|range|only accepts)/i.test(detail)) {
    for (const key of ['top_p', 'top_k', 'temperature']) {
      if (next[key] !== undefined && new RegExp(key, 'i').test(detail)) {
        delete next[key];
        changed = true;
      }
    }
  }
  if (next.max_tokens !== undefined && /max_tokens|max_completion_tokens/i.test(detail)) {
    const limit = Number((detail.match(/max_tokens[^\d]{0,40}(\d+)/i) || [])[1]);
    const target = Number.isFinite(limit) && limit > 0 ? Math.min(next.max_tokens, limit) : Math.floor(next.max_tokens / 2);
    if (target >= 512 && target < next.max_tokens) {
      next.max_tokens = target;
      changed = true;
    }
  }
  if (next.stream === true && /\bstream\b/i.test(detail) && /(not supported|unsupported|must be|invalid)/i.test(detail)) {
    next.stream = false;
    changed = true;
  }
  return changed ? next : null;
}

async function chat(config, body) {
  const url = config.chatBase + '/chat/completions';
  let next = body;
  for (let attempt = 0; ; attempt += 1) {
    try {
      return await chatRequest(url, config.key, next);
    } catch (err) {
      const adjusted = attempt < 2 ? adjustRejectedParams(next, err) : null;
      if (!adjusted) throw err;
      next = adjusted;
    }
  }
}

function isStallError(err) {
  return Boolean(err) && /stopped sending tokens|still running after|timed out after/i.test(String(err.message || ''));
}

async function chatOnce(config, payload, model) {
  try {
    return { response: await chat(config, CORE.buildChatBody(payload, model, true)), structured: true };
  } catch (err) {
    if ((err.status === 400 || err.status === 422) && /response_format|json_schema|json_object|schema/i.test(err.message || '')) {
      return { response: await chat(config, CORE.buildChatBody(payload, model, false)), structured: false };
    }
    throw err;
  }
}

async function generateBuild(payload) {
  const startedAt = Date.now();
  const config = await loadConfig();
  if (!config.key) return { ok: false, error: 'Add your NVIDIA API key first (extension popup → AI).' };
  const knownIds = new Set((payload.items || []).map((item) => item && item.id).filter(Boolean));
  const bannedIds = new Set((payload.banned || []).filter(Boolean));
  const scanned = Array.isArray(config.settings.scannedModels) ? config.settings.scannedModels : [];
  const pool = scanned.length ? scanned : CORE.KNOWN_MODELS;
  const ranked = CORE.rankModels(pool).map((entry) => entry.id);
  const wanted = String(payload.model || config.settings.chatModel || '').trim();
  /* 'auto' (the default) means: rank the models this key can see and take the
     best one for a JSON build. */
  const first = wanted && wanted !== CORE.AUTO_MODEL ? wanted : (ranked[0] || CORE.pickBestModel(pool));
  const candidates = [];
  for (const id of [first].concat(ranked, CORE.KNOWN_MODELS.map((entry) => entry.id))) {
    if (id && !candidates.includes(id)) candidates.push(id);
  }
  if (!candidates.length) return { ok: false, error: 'No NVIDIA chat model is available for this key.' };
  if (!knownIds.size) return { ok: false, error: 'The editor item catalog was not loaded.' };

  let model = '';
  let response = null;
  let structured = true;
  const tried = [];
  let lastError = null;
  for (const candidate of candidates.slice(0, 3)) {
    /* A stalled model already spent its window, so only move on while another
       generation still fits inside the worker's five-minute lifetime. */
    if (tried.length && Date.now() - startedAt > 90000) break;
    tried.push(candidate);
    try {
      const attempt = await chatOnce(config, payload, candidate);
      response = attempt.response;
      structured = attempt.structured;
      model = candidate;
      break;
    } catch (err) {
      lastError = err;
      if (!isStallError(err) && err.status !== 404) break;
    }
  }
  if (!response || !model) {
    return { ok: false, error: (lastError && lastError.message) || 'The model did not answer.', tried: tried };
  }

  let text = contentOf(response);
  let parsed = CORE.extractJson(text);
  if (!parsed) {
    /* A repair round is another full generation and the worker cannot outlive
       5 minutes of continuous work; skip it when the first call was already slow. */
    if (Date.now() - startedAt > 150000) {
      return { ok: false, error: 'The model used its full time budget without returning valid JSON. Lower Max parts or pick a faster model.' };
    }
    const repairMessages = [
      { role: 'system', content: 'You repair invalid model output into strict JSON. Reply with one JSON object and nothing else. Keep the same schema: {"name","summary","root":<ITEM>} using the previously allowed item IDs.' },
      { role: 'user', content: 'Invalid output to repair:\n' + String(text).slice(0, 9000) + '\n\nAllowed item IDs:\n' + (payload.items || []).map((i) => i.id).join(', ') + '\nBanned: ' + (payload.banned || []).join(', ') },
    ];
    try {
      const repaired = await chat(config, { model: model, messages: repairMessages, max_tokens: 4096, stream: true });
      text = contentOf(repaired);
      parsed = CORE.extractJson(text);
    } catch (err) {
      /* fall through to the error below */
    }
  }
  if (!parsed) {
    return { ok: false, error: 'The model did not return valid JSON. Try a different model or a simpler prompt.' };
  }

  try {
    /* The plan decides whether this is a wearable, and a wearable has to sit on
       the backpack base - so the plan's root is passed into normalization. */
    const plan = CORE.planFor(payload.prompt, { maxParts: payload.maxParts, knownIds: knownIds });
    const normalizeOptions = {
      knownIds: knownIds,
      bannedIds: bannedIds,
      maxParts: payload.maxParts,
      autoArrange: payload.autoArrange !== false,
      fallbackRootId: plan.rootId || payload.fallbackRootId || 'item_backpack',
      fallbackName: 'AI build',
      rootId: plan.rootId,
      wearable: plan.wearable,
    };
    let invention = CORE.normalizeInvention(parsed, normalizeOptions);
    let quality = CORE.scoreInvention(invention, plan);
    let improved = false;
    /* One self-critique round. The checker only fires on shape problems it can
       actually name (too few parts, no mirrored pairs, cramped pile), and only
       while there is still time inside the worker's lifetime. */
    if (quality.score < 70 && quality.issues.length && Date.now() - startedAt < 150000) {
      try {
        const second = await chat(config, {
          model: model,
          messages: CORE.improveMessages({
            plan: plan,
            issues: quality.issues,
            invention: { name: invention.name, summary: invention.summary, root: invention.root },
            items: payload.items,
          }),
          max_tokens: CORE.maxTokensFor(payload.maxParts),
          temperature: 0.4,
          stream: true,
        });
        const retryJson = CORE.extractJson(contentOf(second));
        if (retryJson) {
          const retry = CORE.normalizeInvention(retryJson, normalizeOptions);
          const retryQuality = CORE.scoreInvention(retry, plan);
          if (retryQuality.score > quality.score) {
            invention = retry;
            quality = retryQuality;
            improved = true;
          }
        }
      } catch (err) {
        /* keep the first build; the note below stays honest about it */
      }
    }
    invention.quality = {
      score: quality.score,
      issues: quality.issues.slice(0, 4),
      stats: quality.stats,
      plan: plan.label,
      target: plan.targetParts,
      improved: improved,
    };
    return {
      ok: true,
      invention: invention,
      model: model,
      structured: structured,
      tried: tried,
      quality: invention.quality,
      note: [
        tried.length > 1 ? 'auto-switched from ' + tried[0] + ' to ' + model : '',
        improved ? 'rebuilt after a shape check' : '',
      ].filter(Boolean).join(' · '),
    };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

function imageDataUrl(data) {
  const artifact = data && Array.isArray(data.artifacts) ? data.artifacts[0] : null;
  let base64 = '';
  if (artifact && typeof artifact.base64 === 'string') base64 = artifact.base64;
  else if (Array.isArray(data && data.data) && data.data[0] && typeof data.data[0].b64_json === 'string') base64 = data.data[0].b64_json;
  else if (typeof data.image === 'string') {
    if (/^data:image\//.test(data.image)) return data.image;
    base64 = data.image;
  } else if (typeof data.b64_json === 'string') base64 = data.b64_json;
  if (!base64) return '';
  let mime = 'image/jpeg';
  if (base64.startsWith('iVBOR')) mime = 'image/png';
  else if (base64.startsWith('UklGR')) mime = 'image/webp';
  return 'data:' + mime + ';base64,' + base64;
}

async function generateImage(payload) {
  const config = await loadConfig();
  if (!config.key) return { ok: false, error: 'Add your NVIDIA API key first.' };
  const model = String(payload.model || config.settings.imageModel || CORE.IMAGE_MODELS[0].id);
  const size = CORE.imageSize(payload.size);
  const prompt = String(payload.prompt || '').slice(0, 1800);
  if (!prompt) return { ok: false, error: 'Describe the image first.' };
  const body = {
    prompt: prompt,
    width: size.width,
    height: size.height,
    steps: 32,
    cfg_scale: 3.5,
    samples: 1,
  };
  try {
    const data = await apiPost(config.imageBase + '/' + model, config.key, body, 180000);
    const dataUrl = imageDataUrl(data);
    if (!dataUrl) return { ok: false, error: 'The image endpoint returned no image. Check the model name in Advanced settings.' };
    return { ok: true, dataUrl: dataUrl, model: model, width: size.width, height: size.height };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function editImage(payload) {
  const config = await loadConfig();
  if (!config.key) return { ok: false, error: 'Add your NVIDIA API key first.' };
  const image = String(payload.image || '');
  if (!image || image.length > MAX_IMAGE_CHARS) return { ok: false, error: 'Choose an image under about 10 MB.' };
  const model = String(payload.model || config.settings.editModel);
  const prompt = String(payload.prompt || '').slice(0, 1200);
  if (!prompt) return { ok: false, error: 'Describe the change first.' };
  try {
    const data = await apiPost(config.imageBase + '/' + model, config.key, {
      prompt: prompt,
      image: image,
      aspect_ratio: 'match_input_image',
      steps: 30,
      cfg_scale: 3.5,
    }, 180000);
    const dataUrl = imageDataUrl(data);
    if (!dataUrl) return { ok: false, error: 'The edit endpoint returned no image.' };
    return { ok: true, dataUrl: dataUrl, model: model };
  } catch (err) {
    return {
      ok: false,
      error: err.message,
      hint: 'NVIDIA\'s hosted preview only accepts its own demo images. Point Advanced → image base at a self-hosted NIM for real image edits.',
    };
  }
}

async function generate3d(payload) {
  const config = await loadConfig();
  if (!config.key) return { ok: false, error: 'Add your NVIDIA API key first.' };
  const model = String(payload.model || config.settings.model3d);
  const mode = payload.image ? 'image' : 'text';
  const body = {
    mode: mode,
    output_format: 'glb',
    no_texture: false,
    slat_cfg_scale: 3,
    ss_cfg_scale: 7.5,
    slat_sampling_steps: 25,
    ss_sampling_steps: 25,
  };
  if (mode === 'image') {
    if (String(payload.image).length > MAX_IMAGE_CHARS) return { ok: false, error: 'Choose an image under about 10 MB.' };
    body.image = payload.image;
  } else {
    body.prompt = String(payload.prompt || '').slice(0, 1200);
    if (!body.prompt) return { ok: false, error: 'Describe the model first.' };
  }
  try {
    const data = await apiPost(config.imageBase + '/' + model, config.key, body, 300000);
    const artifact = data && Array.isArray(data.artifacts) ? data.artifacts[0] : null;
    const base64 = artifact && (artifact.base64 || artifact.glb) ? (artifact.base64 || artifact.glb) : (data.base64 || '');
    if (!base64) return { ok: false, error: 'The 3D endpoint returned no model data.' };
    return { ok: true, base64: base64, mime: 'model/gltf-binary', model: model };
  } catch (err) {
    return {
      ok: false,
      error: err.message,
      hint: 'TRELLIS is listed as a downloadable NIM on NVIDIA\'s catalog, not a free hosted endpoint. Set Advanced → image base to your own TRELLIS NIM to use this.',
    };
  }
}

async function handleMessage(message) {
  switch (message.type) {
    case 'mbx-open-options':
      await chrome.runtime.openOptionsPage();
      return { ok: true };
    case 'mbx-ai-status': {
      const config = await loadConfig();
      return { ok: true, keyConfigured: Boolean(config.key), settings: config.settings };
    }
    case 'mbx-ai-set-key': {
      const key = String(message.key || '').trim();
      if (!key) return { ok: false, error: 'Paste a key first.' };
      if (!/^nvapi-[A-Za-z0-9_-]{20,}$/.test(key)) {
        return { ok: false, error: 'That does not look like an NVIDIA key. Keys start with nvapi-.' };
      }
      await chrome.storage.local.set({ mbxAiKey: key });
      let scan;
      try {
        scan = await scanModels({ pick: true });
      } catch (err) {
        scan = { ok: false, error: err.message || 'Model scan failed.' };
      }
      return { ok: true, keyConfigured: true, scan: scan };
    }
    case 'mbx-ai-clear-key':
      await chrome.storage.local.remove('mbxAiKey');
      return { ok: true, keyConfigured: false };
    case 'mbx-ai-scan':
      return scanModels({ pick: true });
    case 'mbx-ai-save-settings':
      await saveConfig(message.settings || {});
      return { ok: true };
    case 'mbx-ai-build':
      return generateBuild(message.payload || {});
    case 'mbx-ai-image':
      return generateImage(message.payload || {});
    case 'mbx-ai-image-edit':
      return editImage(message.payload || {});
    case 'mbx-ai-3d':
      return generate3d(message.payload || {});
    default:
      return { ok: false, error: 'Unknown request.' };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || sender.id !== chrome.runtime.id) return undefined;
  handleMessage(message)
    .then((result) => sendResponse(result))
    .catch((err) => sendResponse({ ok: false, error: err.message || 'Unexpected error.' }));
  return true;
});
