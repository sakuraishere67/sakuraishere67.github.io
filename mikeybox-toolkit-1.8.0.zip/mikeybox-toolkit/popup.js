/* Mikeybox Toolkit — popup / options page logic. */
(function () {
  'use strict';

  const MBX = window.MBX;
  if (!MBX) return;

  const FILTERS = ['All', 'Default', 'Dark', 'Neon', 'Light', 'Nature', 'Custom'];
  const rangeSyncs = [];

  let settings = Object.assign({}, MBX.DEFAULT_SETTINGS);
  let customThemes = [];
  let customCss = '';
  let currentFilter = 'All';
  let saveTimer = 0;
  let cssTimer = 0;
  let statusTimer = 0;
  let applyingCustom = false;

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  const hasExtensionStorage = (() => {
    try {
      return Boolean(chrome && chrome.storage && chrome.storage.sync);
    } catch (err) {
      return false;
    }
  })();

  const hasExtensionRuntime = (() => {
    try {
      return Boolean(chrome && chrome.runtime && chrome.runtime.sendMessage);
    } catch (err) {
      return false;
    }
  })();

  /* ---------------------------------------------------------------- */
  /* Storage (chrome.storage.sync, with a localStorage fallback so the
     UI can also be opened as a plain page for development).          */
  /* ---------------------------------------------------------------- */

  function getStore(keys, callback) {
    if (hasExtensionStorage) {
      chrome.storage.sync.get(keys, (res) => callback(res || {}));
      return;
    }
    let data = {};
    try {
      data = JSON.parse(localStorage.getItem('mbx-popup-store') || '{}') || {};
    } catch (err) {
      data = {};
    }
    const out = {};
    keys.forEach((key) => { out[key] = data[key]; });
    window.setTimeout(() => callback(out), 0);
  }

  function setStore(object, callback) {
    if (hasExtensionStorage) {
      chrome.storage.sync.set(object, () => {
        const failed = Boolean(chrome.runtime && chrome.runtime.lastError);
        if (callback) callback(failed);
      });
      return;
    }
    let data = {};
    try {
      data = JSON.parse(localStorage.getItem('mbx-popup-store') || '{}') || {};
    } catch (err) {
      data = {};
    }
    Object.assign(data, object);
    try {
      localStorage.setItem('mbx-popup-store', JSON.stringify(data));
    } catch (err) {
      if (callback) callback(true);
      return;
    }
    window.setTimeout(() => callback && callback(false), 0);
  }

  /* ---------------------------------------------------------------- */
  /* Helpers                                                          */
  /* ---------------------------------------------------------------- */

  function mergeSettings(raw) {
    const merged = Object.assign({}, MBX.DEFAULT_SETTINGS, raw || {});
    merged.customColors = Object.assign({}, MBX.DEFAULT_COLORS, (raw && raw.customColors) || {});
    for (const key of Object.keys(MBX.DEFAULT_COLORS)) {
      merged.customColors[key] = MBX.normalizeHex(merged.customColors[key]) || MBX.DEFAULT_COLORS[key];
    }
    merged.accentOverride = MBX.normalizeHex(merged.accentOverride) || '';
    return merged;
  }

  function sanitizeTheme(raw, index) {
    if (!raw || typeof raw !== 'object') return null;
    const colors = {};
    for (const key of Object.keys(MBX.DEFAULT_COLORS)) {
      colors[key] = MBX.normalizeHex(raw.colors && raw.colors[key]) || MBX.DEFAULT_COLORS[key];
    }
    const name = typeof raw.name === 'string' && raw.name.trim()
      ? raw.name.trim().slice(0, 28)
      : 'Imported ' + (index + 1);
    let id = typeof raw.id === 'string' && /^[a-z0-9][a-z0-9-]{0,39}$/i.test(raw.id) ? raw.id : '';
    if (!id) id = 'user-' + Date.now().toString(36) + '-' + index;
    return { id: id, name: name, group: 'Custom', colors: colors };
  }

  function sanitizeThemes(list) {
    const seen = new Set();
    const out = [];
    (Array.isArray(list) ? list : []).forEach((raw, index) => {
      const theme = sanitizeTheme(raw, index);
      if (!theme) return;
      let id = theme.id;
      while (seen.has(id)) id = id + '-2';
      theme.id = id;
      seen.add(id);
      out.push(theme);
    });
    return out;
  }

  function themeColors(theme) {
    if (theme.id === MBX.CUSTOM_ID) {
      return Object.assign({}, MBX.DEFAULT_COLORS, settings.customColors);
    }
    return theme.colors;
  }

  function swatchCss(colors) {
    return 'linear-gradient(135deg, ' + colors.bg + ' 0 38%, ' + colors.panel2 + ' 38% 68%, ' + colors.accent + ' 68% 100%)';
  }

  function showStatus(text, isError) {
    const el = $('#status');
    if (!el) return;
    el.textContent = text;
    el.style.color = isError ? 'var(--bad)' : 'var(--good)';
    el.classList.add('show');
    window.clearTimeout(statusTimer);
    statusTimer = window.setTimeout(() => el.classList.remove('show'), 1800);
  }

  /* ---------------------------------------------------------------- */
  /* Boot                                                             */
  /* ---------------------------------------------------------------- */

  function init() {
    buildFilters();
    buildFonts();
    buildWallpapers();
    buildColorFields();
    bindTabs();
    bindAccent();
    bindRanges();
    bindControls();
    bindCustomSection();
    bindFooter();
    bindPageActions();
    loadState();
  }

  function loadState() {
    getStore(['settings', 'customThemes', 'customCss'], (res) => {
      settings = mergeSettings(res.settings);
      customThemes = sanitizeThemes(res.customThemes);
      customCss = typeof res.customCss === 'string' ? res.customCss : '';
      renderAll();
    });
  }

  function renderAll() {
    $('#enabled').checked = settings.enabled;
    renderThemes();
    renderAccent();
    renderControls();
    renderCustom();
    renderSavedThemes();
    $('#custom-css').value = customCss;
    updateCssCount();
    refreshExport();
    applyPopupAccent();
  }

  /* ---------------------------------------------------------------- */
  /* Tabs                                                             */
  /* ---------------------------------------------------------------- */

  function bindTabs() {
    $$('.tab').forEach((tab) => {
      tab.addEventListener('click', () => selectTab(tab.dataset.tab));
    });
  }

  function selectTab(name) {
    $$('.tab').forEach((tab) => {
      const on = tab.dataset.tab === name;
      tab.classList.toggle('is-active', on);
      tab.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    $$('.tab-panel').forEach((panel) => {
      const on = panel.id === 'tab-' + name;
      panel.classList.toggle('is-active', on);
      panel.hidden = !on;
    });
    if (name === 'custom') {
      refreshExport();
      renderCustom();
    }
  }

  /* ---------------------------------------------------------------- */
  /* Themes                                                           */
  /* ---------------------------------------------------------------- */

  function buildFilters() {
    const wrap = $('#theme-filters');
    wrap.textContent = '';
    FILTERS.forEach((label) => {
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'chip' + (label === currentFilter ? ' is-active' : '');
      chip.textContent = label;
      chip.setAttribute('aria-pressed', label === currentFilter ? 'true' : 'false');
      chip.addEventListener('click', () => {
        currentFilter = label;
        $$('.chip', wrap).forEach((other) => {
          const on = other.textContent === label;
          other.classList.toggle('is-active', on);
          other.setAttribute('aria-pressed', on ? 'true' : 'false');
        });
        renderThemes();
      });
      wrap.appendChild(chip);
    });
  }

  function renderThemes() {
    const grid = $('#theme-grid');
    if (!grid) return;
    grid.textContent = '';
    const options = MBX.themeOptions(customThemes);
    const visible = currentFilter === 'All' ? options : options.filter((theme) => theme.group === currentFilter);

    visible.forEach((theme) => {
      const colors = themeColors(theme);
      const card = document.createElement('button');
      card.type = 'button';
      card.className = 'theme-card';
      card.dataset.id = theme.id;
      card.title = theme.name + ' — ' + theme.group;
      card.setAttribute('aria-pressed', 'false');

      const swatch = document.createElement('span');
      swatch.className = 'theme-swatch';
      swatch.style.background = swatchCss(colors);

      const name = document.createElement('span');
      name.className = 'theme-name';
      name.textContent = theme.name;

      card.appendChild(swatch);
      card.appendChild(name);
      card.addEventListener('click', () => setTheme(theme.id));
      grid.appendChild(card);
    });

    if (!visible.length) {
      const empty = document.createElement('p');
      empty.className = 'note';
      empty.textContent = 'No themes in this group yet. Save one from the Custom tab.';
      grid.appendChild(empty);
    }

    renderThemeSelection();
  }

  function renderThemeSelection() {
    const options = MBX.themeOptions(customThemes);
    const current = options.find((theme) => theme.id === settings.themeId) || options[0];
    $$('.theme-card').forEach((card) => {
      const on = card.dataset.id === settings.themeId;
      card.classList.toggle('is-active', on);
      card.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    const count = $('#theme-count');
    if (count) {
      count.textContent = options.length + ' themes · using ' + (current ? current.name : '—');
    }
  }

  function setTheme(id) {
    settings.themeId = id;
    renderThemeSelection();
    renderAccent();
    applyPopupAccent();
    saveSettings();
  }


  function bindAccent() {
    const input = $('#accent-color');
    input.addEventListener('input', () => {
      settings.accentOverride = MBX.normalizeHex(input.value) || '';
      applyPopupAccent();
      renderThemeSelection();
      saveSettings();
    });
    $('#accent-reset').addEventListener('click', () => {
      settings.accentOverride = '';
      renderAccent();
      applyPopupAccent();
      saveSettings();
    });
    $('#random-theme').addEventListener('click', () => {
      const options = MBX.themeOptions(customThemes);
      const pick = options[Math.floor(Math.random() * options.length)];
      if (pick) {
        setTheme(pick.id);
        showStatus('Applied ' + pick.name);
      }
    });
  }

  function renderAccent() {
    const colors = MBX.resolveTheme(settings, customThemes).colors;
    const input = $('#accent-color');
    if (input) input.value = colors.accent;
    applyPopupAccent();
  }

  function applyPopupAccent() {
    const colors = MBX.resolveTheme(settings, customThemes).colors;
    document.documentElement.style.setProperty('--accent', colors.accent || '#6fc2ff');
  }

  /* ---------------------------------------------------------------- */
  /* Tweaks                                                           */
  /* ---------------------------------------------------------------- */

  function buildFonts() {
    const select = $('#font');
    select.textContent = '';
    MBX.FONTS.forEach((font) => {
      const option = document.createElement('option');
      option.value = font.id;
      option.textContent = font.label;
      select.appendChild(option);
    });
  }

  function buildWallpapers() {
    const select = $('#wallpaper');
    select.textContent = '';
    MBX.WALLPAPERS.forEach((wallpaper) => {
      const option = document.createElement('option');
      option.value = wallpaper.id;
      option.textContent = wallpaper.label;
      select.appendChild(option);
    });
  }

  function bindRanges() {
    const defs = [
      ['panel-opacity', 'panelOpacity', (v) => v + '%'],
      ['blur', 'blur', (v) => v + 'px'],
      ['radius', 'radius', (v) => v + 'px'],
      ['text-size', 'textSize', (v) => v + 'px'],
      ['thumb-size', 'thumbSize', (v) => v + 'px'],
    ];
    defs.forEach(([id, key, format]) => {
      const input = document.getElementById(id);
      const output = document.getElementById(id + '-out');
      input.addEventListener('input', () => {
        const value = Number(input.value);
        settings[key] = value;
        if (output) output.textContent = format(value);
        saveSettings();
      });
      rangeSyncs.push({ input: input, output: output, key: key, format: format });
    });
  }

  function bindControls() {
    $('#font').addEventListener('change', (event) => {
      settings.font = event.target.value;
      saveSettings();
    });
    $('#wallpaper').addEventListener('change', (event) => {
      settings.wallpaper = event.target.value;
      $('#wallpaper-url-row').hidden = settings.wallpaper !== 'custom';
      saveSettings();
    });
    $('#wallpaper-url').addEventListener('input', (event) => {
      settings.wallpaperUrl = event.target.value.trim();
      saveSettings(400);
    });
    $$('[data-setting]').forEach((input) => {
      input.addEventListener('change', () => {
        settings[input.dataset.setting] = input.checked;
        if (input.dataset.setting === 'enabled') {
          $('#enabled').checked = input.checked;
        }
        saveSettings();
      });
    });
    $('#enabled').addEventListener('change', (event) => {
      settings.enabled = event.target.checked;
      const mirror = $('[data-setting="enabled"]');
      if (mirror) mirror.checked = event.target.checked;
      saveSettings(0);
    });
    $('#reset-all').addEventListener('click', () => {
      const keepTheme = settings.themeId;
      const keepCustom = settings.customColors;
      const keepAccent = settings.accentOverride;
      settings = Object.assign({}, MBX.DEFAULT_SETTINGS, {
        themeId: keepTheme,
        customColors: keepCustom,
        accentOverride: keepAccent,
      });
      setStore({ settings: settings }, (failed) => {
        showStatus(failed ? 'Could not save' : 'Tweaks reset', failed);
      });
      renderControls();
      renderAccent();
    });
  }

  function renderControls() {
    rangeSyncs.forEach(({ input, output, key, format }) => {
      const value = settings[key];
      input.value = String(value);
      if (output) output.textContent = format(value);
    });
    const font = $('#font');
    if (font) font.value = settings.font;
    const wallpaper = $('#wallpaper');
    if (wallpaper) wallpaper.value = settings.wallpaper;
    const url = $('#wallpaper-url');
    if (url) url.value = settings.wallpaperUrl;
    const urlRow = $('#wallpaper-url-row');
    if (urlRow) urlRow.hidden = settings.wallpaper !== 'custom';
    $$('[data-setting]').forEach((input) => {
      input.checked = Boolean(settings[input.dataset.setting]);
    });
    const enabled = $('#enabled');
    if (enabled) enabled.checked = Boolean(settings.enabled);
  }

  /* ---------------------------------------------------------------- */
  /* Custom palette                                                   */
  /* ---------------------------------------------------------------- */

  function buildColorFields() {
    const wrap = $('#custom-colors');
    wrap.textContent = '';
    MBX.COLOR_FIELDS.forEach((field) => {
      const outer = document.createElement('div');
      outer.className = 'color-field';

      const label = document.createElement('label');
      label.textContent = field.label;
      label.htmlFor = 'cc-color-' + field.key;
      label.title = field.hint;

      const row = document.createElement('div');
      row.className = 'color-inputs';

      const color = document.createElement('input');
      color.type = 'color';
      color.id = 'cc-color-' + field.key;
      color.dataset.color = field.key;

      const hex = document.createElement('input');
      hex.type = 'text';
      hex.maxLength = 7;
      hex.spellcheck = false;
      hex.dataset.hex = field.key;
      hex.setAttribute('aria-label', field.label + ' hex colour');

      color.addEventListener('input', () => setCustomColor(field.key, color.value, 'color'));
      hex.addEventListener('input', () => {
        const value = MBX.normalizeHex(hex.value);
        if (value) setCustomColor(field.key, value, 'hex');
      });
      hex.addEventListener('blur', () => {
        hex.value = settings.customColors[field.key];
      });

      row.appendChild(color);
      row.appendChild(hex);
      outer.appendChild(label);
      outer.appendChild(row);
      wrap.appendChild(outer);
    });
  }

  function setCustomColor(key, value, source) {
    const hex = MBX.normalizeHex(value);
    if (!hex) return;
    if (applyingCustom) return;
    settings.customColors[key] = hex;
    settings.themeId = MBX.CUSTOM_ID;
    if (source === 'color') {
      const pair = document.querySelector('[data-hex="' + key + '"]');
      if (pair) pair.value = hex;
    } else if (source === 'hex') {
      const pair = document.querySelector('[data-color="' + key + '"]');
      if (pair) pair.value = hex;
    }
    renderCustomPreview();
    renderThemeSelection();
    renderAccent();
    refreshExport();
    saveSettings(300);
  }

  function renderCustom() {
    applyingCustom = true;
    MBX.COLOR_FIELDS.forEach((field) => {
      const color = document.querySelector('[data-color="' + field.key + '"]');
      const hex = document.querySelector('[data-hex="' + field.key + '"]');
      if (color) color.value = settings.customColors[field.key];
      if (hex) hex.value = settings.customColors[field.key];
    });
    applyingCustom = false;
    renderCustomPreview();
  }

  function renderCustomPreview() {
    const preview = $('#custom-preview');
    if (!preview) return;
    const c = settings.customColors;
    preview.style.background = 'linear-gradient(90deg, ' +
      c.bg + ' 0 12%, ' + c.panel + ' 12% 26%, ' + c.panel2 + ' 26% 40%, ' +
      c.line + ' 40% 52%, ' + c.text + ' 52% 64%, ' + c.muted + ' 64% 76%, ' +
      c.accent + ' 76% 88%, ' + c.good + ' 88% 94%, ' + c.bad + ' 94% 100%)';
  }

  function bindCustomSection() {
    $('#use-custom').addEventListener('click', () => {
      settings.themeId = MBX.CUSTOM_ID;
      renderThemeSelection();
      renderAccent();
      saveSettings();
      showStatus('Custom theme applied');
    });

    $('#save-theme').addEventListener('click', () => {
      const nameInput = $('#custom-name');
      const name = (nameInput.value || '').trim().slice(0, 28) || 'My theme';
      const id = 'user-' + Date.now().toString(36);
      customThemes = customThemes.concat([{
        id: id,
        name: name,
        group: 'Custom',
        colors: Object.assign({}, settings.customColors),
      }]);
      settings.themeId = id;
      nameInput.value = '';
      setStore({ settings: settings, customThemes: customThemes }, (failed) => {
        if (failed) {
          showStatus('Could not save theme', true);
          return;
        }
        renderThemes();
        renderSavedThemes();
        renderThemeSelection();
        renderAccent();
        refreshExport();
        showStatus('Theme saved');
      });
    });

    $('#copy-export').addEventListener('click', copyExport);
    $('#import-btn').addEventListener('click', importExport);

    const cssEl = $('#custom-css');
    cssEl.maxLength = 6000;
    cssEl.addEventListener('input', () => {
      updateCssCount();
      window.clearTimeout(cssTimer);
      cssTimer = window.setTimeout(saveCss, 500);
    });
    $('#clear-css').addEventListener('click', () => {
      cssEl.value = '';
      updateCssCount();
      saveCss();
    });
  }

  function renderSavedThemes() {
    const wrap = $('#saved-themes');
    if (!wrap) return;
    wrap.textContent = '';
    if (!customThemes.length) {
      const empty = document.createElement('div');
      empty.className = 'saved-empty';
      empty.textContent = 'No saved themes yet — build a palette above and press Save.';
      wrap.appendChild(empty);
      return;
    }
    customThemes.forEach((theme) => {
      const row = document.createElement('div');
      row.className = 'saved-theme';
      row.title = 'Click to apply ' + theme.name;

      const swatch = document.createElement('span');
      swatch.className = 'saved-swatch';
      swatch.style.background = swatchCss(theme.colors);

      const name = document.createElement('span');
      name.className = 'saved-name';
      name.textContent = theme.name;

      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'saved-del';
      del.textContent = 'Delete';
      del.setAttribute('aria-label', 'Delete ' + theme.name);

      row.addEventListener('click', (event) => {
        if (event.target.closest('.saved-del')) return;
        setTheme(theme.id);
      });
      del.addEventListener('click', () => deleteTheme(theme.id));

      row.appendChild(swatch);
      row.appendChild(name);
      row.appendChild(del);
      wrap.appendChild(row);
    });
  }

  function deleteTheme(id) {
    customThemes = customThemes.filter((theme) => theme.id !== id);
    if (settings.themeId === id) settings.themeId = MBX.CUSTOM_ID;
    setStore({ settings: settings, customThemes: customThemes }, (failed) => {
      if (failed) {
        showStatus('Could not delete', true);
        return;
      }
      renderThemes();
      renderSavedThemes();
      renderThemeSelection();
      renderAccent();
      refreshExport();
      showStatus('Theme deleted');
    });
  }

  function refreshExport() {
    const box = $('#export-box');
    if (!box || document.activeElement === box) return;
    box.value = JSON.stringify({
      app: 'mikeybox-toolkit',
      version: 1,
      colors: settings.customColors,
      themes: customThemes,
    }, null, 2);
  }

  function copyExport() {
    const box = $('#export-box');
    if (!box) return;
    const text = box.value;
    const done = () => showStatus('Copied JSON');
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done).catch(fallback);
    } else {
      fallback();
    }
    function fallback() {
      box.focus();
      box.select();
      let ok = false;
      try {
        ok = document.execCommand('copy');
      } catch (err) {
        ok = false;
      }
      showStatus(ok ? 'Copied JSON' : 'Copy failed', !ok);
    }
  }

  function importExport() {
    const box = $('#export-box');
    let parsed;
    try {
      parsed = JSON.parse(box.value);
    } catch (err) {
      showStatus('That is not valid JSON', true);
      return;
    }
    const incomingThemes = Array.isArray(parsed) ? parsed : (Array.isArray(parsed.themes) ? parsed.themes : []);
    const incomingColors = parsed && !Array.isArray(parsed) && parsed.colors ? parsed.colors : null;

    let importedCount = 0;
    const known = new Set(customThemes.map((theme) => theme.id));
    sanitizeThemes(incomingThemes).forEach((theme) => {
      let id = theme.id;
      while (known.has(id)) id = id + '-2';
      theme.id = id;
      known.add(id);
      customThemes.push(theme);
      importedCount += 1;
    });

    if (incomingColors && typeof incomingColors === 'object') {
      for (const key of Object.keys(MBX.DEFAULT_COLORS)) {
        const hex = MBX.normalizeHex(incomingColors[key]);
        if (hex) settings.customColors[key] = hex;
      }
      settings.themeId = MBX.CUSTOM_ID;
    }

    if (!importedCount && !incomingColors) {
      showStatus('Nothing to import', true);
      return;
    }

    setStore({ settings: settings, customThemes: customThemes }, (failed) => {
      if (failed) {
        showStatus('Could not import', true);
        return;
      }
      renderThemes();
      renderSavedThemes();
      renderCustom();
      renderThemeSelection();
      renderAccent();
      refreshExport();
      showStatus('Imported' + (importedCount ? ' ' + importedCount + ' theme' + (importedCount === 1 ? '' : 's') : ''));
    });
  }

  function updateCssCount() {
    const cssEl = $('#custom-css');
    const count = $('#css-count');
    if (!cssEl || !count) return;
    count.textContent = cssEl.value.length + ' / 6000 characters';
  }

  function saveCss() {
    customCss = $('#custom-css').value;
    setStore({ customCss: customCss }, (failed) => {
      showStatus(failed ? 'CSS could not be saved' : 'CSS saved', failed);
    });
  }

  /* ---------------------------------------------------------------- */
  /* AI Studio shortcut                                               */
  /* ---------------------------------------------------------------- */

  function openStudio() {
    if (!hasExtensionRuntime) {
      window.open('https://prime.mikeybox.ai/', '_blank', 'noopener');
      return;
    }
    try {
      chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
        const tab = tabs && tabs[0];
        if (!tab || !tab.id) {
          window.open('https://prime.mikeybox.ai/', '_blank', 'noopener');
          return;
        }
        chrome.tabs.sendMessage(tab.id, { type: 'mbx-open-studio' }, () => {
          if (chrome.runtime.lastError) {
            window.open('https://prime.mikeybox.ai/', '_blank', 'noopener');
            showStatus('Open the editor and press Alt+Shift+A', true);
          } else {
            window.close();
          }
        });
      });
    } catch (err) {
      window.open('https://prime.mikeybox.ai/', '_blank', 'noopener');
    }
  }

  /* ---------------------------------------------------------------- */
  /* Settings saving                                                  */
  /* ---------------------------------------------------------------- */

  function saveSettings(delay) {
    window.clearTimeout(saveTimer);
    saveTimer = window.setTimeout(() => {
      setStore({ settings: settings }, (failed) => {
        showStatus(failed ? 'Could not save' : 'Saved', failed);
      });
    }, delay === undefined ? 220 : delay);
  }

  /* ---------------------------------------------------------------- */
  /* Editor page actions                                              */
  /* ---------------------------------------------------------------- */

  function setPageStatus(text, isError) {
    const node = $('#page-action-status');
    if (!node) return;
    node.textContent = text || '';
    node.style.color = isError ? 'var(--bad, #ff8d8d)' : '';
  }

  function copyPageText(text, label) {
    if (!navigator.clipboard || !navigator.clipboard.writeText) {
      setPageStatus('Clipboard unavailable in this browser.', true);
      return;
    }
    navigator.clipboard.writeText(text || '')
      .then(() => setPageStatus(label + ' copied.', false))
      .catch(() => setPageStatus('Copy failed.', true));
  }

  /* The popup cannot click the editor's own buttons or read its page storage,
     so each action is relayed to the content script in the active tab. */
  function runPageAction(action, label) {
    if (!hasExtensionRuntime) {
      setPageStatus('Preview only — install the extension.', true);
      return;
    }
    try {
      chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
        const tab = tabs && tabs[0];
        if (!tab || !tab.id) {
          setPageStatus('Open a Prime or Fab editor tab first.', true);
          return;
        }
        chrome.tabs.sendMessage(tab.id, { type: 'mbx-page-action', action: action }, (response) => {
          if (chrome.runtime.lastError || !response) {
            setPageStatus('No editor on this tab — open Prime or Fab, then try again.', true);
            return;
          }
          if (!response.ok) {
            setPageStatus(response.error || 'That did not work.', true);
            return;
          }
          if (action === 'send') {
            setPageStatus(response.text || 'Send dialog opened.', false);
            return;
          }
          copyPageText(response.text, label);
        });
      });
    } catch (err) {
      setPageStatus('No editor on this tab — open Prime or Fab, then try again.', true);
    }
  }

  function bindPageActions() {
    const send = $('#page-send');
    if (send) send.addEventListener('click', () => runPageAction('send', 'Send dialog'));
    const name = $('#page-copy-name');
    if (name) name.addEventListener('click', () => runPageAction('username', 'Username'));
    const dossier = $('#page-copy-dossier');
    if (dossier) dossier.addEventListener('click', () => runPageAction('dossier', 'Dossier'));
  }

  /* ---------------------------------------------------------------- */
  /* Footer                                                           */
  /* ---------------------------------------------------------------- */

  function bindFooter() {
    try {
      const manifest = chrome.runtime.getManifest();
      if (manifest && manifest.version) $('#version').textContent = manifest.version;
    } catch (err) {
      /* plain page preview */
    }

    $('#open-studio').addEventListener('click', openStudio);

    $('#open-editor').addEventListener('click', () => {
      window.open('https://prime.mikeybox.ai/', '_blank', 'noopener');
    });

    const full = $('#open-full');
    const isFullPage = window.innerWidth > 560;
    if (hasExtensionStorage && chrome.runtime && chrome.runtime.openOptionsPage && !isFullPage) {
      full.addEventListener('click', () => chrome.runtime.openOptionsPage());
    } else {
      full.hidden = true;
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();
